<?php
include_once 'app/Connection.inc.php';
include_once 'app/Habitaciones/HabitacionRepo.inc.php';
include_once 'app/ControlSesion.inc.php';

if (ControlSesion::SesionStarted() && $_SESSION['SessionType'] == 0) {
    header('Location: Main/Habitaciones/Habitaciones.php', true, 301);
    exit();
}
$tittle = "Inicio";
include_once 'plantillas/declaracion.inc.php';
include_once 'plantillas/navbar.inc.php';
if (isset($_GET['s'])) {
    echo "<div class='alert alert-success' role='alert' style='text-align: center'> ¡Se ha registrado tu reservación! </div>";
}
include_once 'plantillas/cierre.inc.php';
?>

<nav class="navbar-default navbar-static" style='background-color: whitesmoke;' >
    <div class="container" style= 'padding-top:50px'>
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>
        <div id="navbar2" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="#">Sitios de hospedaje</a></li>
                <li><a href="Main/Actividades/ActividadesCliente.php">Actividades de recreación</a></li>

            </ul>
        </div>
    </div>
</nav>

<div class="container" >
    <div class="panel-default" style="background-color: white;border-radius: 10px">
        <div class="panel-body">
            <form role="form" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
                <div class='row'>
                    <div class='col-md-3'>

                        <div class="form-group " id="Ubicacion">
                            <label >¿A donde vas?</label>
                            <input class="form-control" name="Ubicacion" id="Ubicacion" type="text"  />
                        </div>

                    </div>       
                    <div class="col-md-2">
                        <div class="form-group">
                            <label >Entrada</label>
                            <div class='input-group date' id='datetimepicker6'>
                                <input name="fechaIngreso" type='text' class="form-control" />
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class='col-md-2'>
                        <div class="form-group">
                            <label >Salida</label>
                            <div class='input-group date' id='datetimepicker7'>                          
                                <input name="fechaSalida" type='text' class="form-control" />
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                        <script type="text/javascript">
                            $(function () {
                                $('#datetimepicker6').datetimepicker({
                                    minDate: moment(),
                                    format: 'YYYY/DD/MM'
                                });
                                $('#datetimepicker7').datetimepicker({
                                    useCurrent: false,
                                    format: 'YYYY/DD/MM'
                                });
                                $("#datetimepicker6").on("dp.change", function (e) {
                                    $('#datetimepicker7').data("DateTimePicker").minDate(e.date);
                                });
                                $("#datetimepicker7").on("dp.change", function (e) {
                                    $('#datetimepicker6').data("DateTimePicker").maxDate(e.date);
                                });
                            });
                        </script>                  
                    </div>  
                    <div class='col-md-3'>
                        <div class="form-group" id="hospedaje">
                            <label >¿Que buscas?</label>
                            <select class="form-control" name="tipoHos" >
                                <option value="Hotel">Hotel</option>
                                <option value="Hostal">Hostal</option>
                                <option value="Casa">Casa</option>
                                <option value="Departamento">Departamento</option>
                                <option value="Cuarto compartido">Cuarto compartido</option>
                                <option value="Cabaña">Cabaña</option>                        
                            </select>

                        </div>
                    </div>
                    <div class="col-md-2"><br>
                        <button type="submit"  name="send" class="btn btn-default btn-primary" style="background-color:#76448A;border-color: #76448A;float: right;margin-right: 10px" >
                            <span class="glyphicon glyphicon-search"></span>
                            Buscar
                        </button>                      
                    </div>            
                </div>    
            </form>
        </div>
    </div>
</div>
<br>
<div class="container" >

    <?php
    Connection::openConnection();
    $result = HabitacionRepo::getHabitaciones(Connection::getConnection());
    if (isset($_POST['send'])) {
        $result = HabitacionRepo::getHabitacionesByFilter(Connection::getConnection(), $_POST['Ubicacion'], $_POST['fechaIngreso'], $_POST['fechaSalida'], $_POST['tipoHos']);
    }
    if (!empty($result)) {
        foreach ($result as $valor) {

            include_once 'app/Direccion/DireccionRepo.inc.php';
            include_once 'app/Empresa/EmpresaRepo.inc.php';
            $infoTipo = HabitacionRepo::getInfoTipo(Connection::getConnection(), $valor->getTipo());
            $target = HabitacionRepo::getMiniatura(Connection::getConnection(), $valor->getTipo(), $infoTipo[0]['ID_Hospedaje']);
            $target = $target[0]['imagen'];
            $Empresa = EmpresaRepo::getEmpresaByID(Connection::getConnection(), $valor->getID_Hospedaje());
            $Direccion = DireccionRepo::getDireccionByID(Connection::getConnection(), $Empresa->getID_Direccion());
            ?>
            <div class="panel-default"  style="background-color: white; border-radius: 10px;">
                <div class="panel-body">
                    <div class="row" style="margin-top: 0px">  
                        <div class="col-md-3" >
                            <?php echo "<img src='" . $target . "' id = 'imagen2' name = 'imagen2' style = 'border-radius: 10px;  height: 200px;' />"; ?>
                        </div>
                        <div class="col-md-9" >
                            <div class="row">
                                <div class="col-md-3">
                                    <label>Numero:</label><?php echo " " . $valor->getNumero() ?>
                                </div>
                                <div class="col-md-3">
                                    <label>Tipo:</label><?php echo " " . $valor->getTipo() ?>
                                </div>
                                <div class="col-md-6">
                                    <label>Ubicacion:</label><?php //echo " " . $Direccion->getProvincia() . "," . $Direccion->getCanton() . "," . $Direccion->getDistrito(); ?>
                                </div>
                            </div>
                            <hr>
                            <div class="row">  
                                <div class="col-md-12">
                                    <label>Descripcion:</label><br> <?php echo "&nbsp&nbsp&nbsp&nbsp" . $infoTipo[0]['Descripcion']; ?>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <?php $path = "\PY2\Main\Habitaciones\VistaHabitacion.inc.php?ID=" . $valor->getNumero() . "&h=" . $valor->getID_Hospedaje(); ?>
                                <a class="btn btn-primary" <?php echo "href=" . $path; ?> style="float: right;margin-right: 10px;background-color: #76448A;border-color: #76448A ">Más Detalles</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <br>
            <?php
        }
    }
    Connection::closeConnection();
    ?>  


</div>
<br>
<br>
<br>
<script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
</script>

