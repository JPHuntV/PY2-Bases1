<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/Habitaciones/HabitacionRepo.inc.php';
include_once '../../app/Reservacion/ReservacionRepo.inc.php';
include_once '../../app/Habitaciones/Habitacion.inc.php';
include_once '../../app/Habitaciones/RegisterHabitacionVal.inc.php';
$tittle = "Habitaciones";
include_once '../../app/ControlSesion.inc.php';
if (!ControlSesion::SesionStarted() || $_SESSION['SessionType'] === 1) {
    header('Location:  \PY2\index.php', true, 301);
    exit();
}
if (isset($_POST['sendHab'])) {


    Connection::openConnection();
    $validador = new RegisterHabitacionVal($_POST['Numero'], Connection::getConnection());
    if ($validador->validAccount()) {
        $Habitacion = new Habitacion($_SESSION['ID'], $_POST['Numero'], $_POST['Tipo'], $_POST['Estado']);
        $valor = HabitacionRepo::InsertHabitacion(Connection::getConnection(), $Habitacion);
    }

    Connection::closeConnection();
    /* if ($valor) {
      header('Location: ../../index.php', true, 301);
      exit(); */
}

include_once '../../plantillas/declaracion.inc.php';

include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
?>

<div class="container" style='background-color: whitesmoke; margin-top:50px'>
    <div class="row">
        <div class="col-md-10">
            <nav class="navbar-default navbar-static" style="background-color: whitesmoke" >
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">despliega la barra</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>  
                    </button>
                </div>
                <div id="navbar2" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li><a href="../../Main/Habitaciones/Habitaciones.php">Habitaciones</a></li>
                        <li><a  href="../../Main/Habitaciones/HabitacionesTipo.php">Tipos</a></li> 
                        <li><a href="#">Clientes</a></li>
                        <li><a href="#">Reservaciones</a></li>
                        <li><a href="#">Facturación</a></li>
                        <li><a href="../../Main/Actividades/ActividadesEmpresa.php">Actividades de recreación</a></li>
                    </ul> 
                </div>
            </nav>
        </div>
    </div>
    <div class="row">
        <form autocomplete="off" role="form" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
            <div class="col-md-3" >


                <div class="form-group" id="Clave">                 
                    <input name="Numero" type="number" placeholder="Numero de reservacion"  class="form-control" >
                </div>               


            </div>
            <div class="col-md-1">
                <button class="btn  bg-primary"  style="float: right" type="submit" name="send">Reservar</button>    
            </div>
        </form>
    </div>

</div>


<div class="container">
    <?php
    Connection::openConnection();
    $result = ReservacionRepo::getReservaciones(Connection::getConnection());
    if (isset($_POST['send'])) {
        $result = ReservacionRepo::getReservacionByID(Connection::getConnection(), $_POST['Numero']);
    }
    if (!empty($result)) {
        foreach ($result as $valor) {
            $Habitacion = HabitacionRepo::getHabitacionByNumber(Connection::getConnection(), $valor->getID_Habitacion(), $_SESSION['ID']);
            $target = HabitacionRepo::getMiniatura(Connection::getConnection(), $Habitacion[0]['Tipo'], $_SESSION['ID']);
            $target = $target[0]['imagen'];
            $infoTipo = HabitacionRepo::getInfoTipo(Connection::getConnection(), $Habitacion[0]['Tipo']);
            ?>
            <br>
            <div class="panel-default" style="background-color: white;">
                <div class="panel-body" >
                    <div class="row">
                        <div class="col-md-3" >

                            <?php echo "<img src='../../" . $target . "' id = 'imagen2' name = 'imagen2' style = 'padding:0; width: 200px; height: 200px;' />" ?>
                        </div>
                        <div class="col-md-3">
                            <div class="row">
                                N° Reservacion:<?php echo $valor->getID_Reservacion(); ?>
                            </div>
                            <div class="row">
                                N° Habitacion:<?php echo $valor->getID_Habitacion() ?>
                            </div>
                            <div class="row">
                                Tipo de habitación:<?php echo $Habitacion[0]['Tipo'] ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="row">
                                Identificacion del cliente: <?php echo $valor->getIdentificacionCliente() ?>
                            </div> 
                            <div class="row">
                                Cantidad de personas: <?php echo $valor->getCantPersonas() ?>
                            </div>
                            <div class="row">
                                Posee vahiculo: <?php
                                if ($valor->getHasCar()) {
                                    echo "si";
                                } else {
                                    echo "No";
                                }
                                ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="row">
                                Llegada: <?php echo $valor->getFechaIngreso() ?>
                            </div>

                            <div class="row">
                                Salida: <?php echo $valor->getFechaSalida() ?>
                            </div>

                            <?php $path = "VistaHabitacionE.inc.php?ID=" . $valor->getID_Habitacion(); ?>
                            <a class="btn btn-primary" <?php echo "href=" . $path; ?>>Más Detalles</a>

                            <?php $path = "VistaHabitacionE.inc.php?ID=" . $valor->getID_Habitacion(); ?>
                            <a class="btn btn-primary" <?php echo "href=" . $path; ?>>Más Detalles</a>
                        </div>
                    </div>
                </div>
            </div>

            <?php
        }
    }
    Connection::closeConnection();
    ?>     
</div>


<script type="text/javascript">

    function PreviewImage($boton, $imagen) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById($boton).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById($imagen).src = oFREvent.target.result;
        };
    }
    ;

</script>
