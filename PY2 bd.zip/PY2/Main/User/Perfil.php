<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/ControlSesion.inc.php';
include_once '../../app/User/UserRepo.inc.php';
include_once '../../app/Direccion/DireccionRepo.inc.php';
if (ControlSesion::SesionStarted() && $_SESSION['SessionType'] == 0) {
    header('Location: Main/Habitaciones/Habitaciones.php', true, 301);
    exit();
}
$tittle = "Inicio";
Connection::OpenConnection();
$User = UserRepo::getUserByID(Connection::getConnection(), $_SESSION['ID']);
$Direccion = DireccionRepo::getDireccionByID(Connection::getConnection(), $User->getID_Direccion());
Connection::CloseConnection();
include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
?>

<div class="container">
    <br>
    <br>
    <a href="../../index.php">Inicio</a>
    <div class="panel panel-default">
        <div class="panel panel-heading">
            <h3>Perfil de usuario</h3>
        </div>
        <div class="panel panel-body">
            <div class="row">
                <div class="col-md-4">
                    <label>Usuario:</label>    
                </div>
                <div class="col-md-6">
                    <?php echo "&nbsp&nbsp&nbsp&nbsp" . $User->getUsuario(); ?>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-4">
                    <label>Nombre:</label>
                </div>
                <div class="col-md-6">
                    <?php echo "&nbsp&nbsp&nbsp&nbsp" . $User->getNombre() . " " . $User->getApellido1() . " " . $User->getApellido2(); ?>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-4">
                    <label>Fecha de nacimiento: </label>
                </div>
                <div class="col-md-6">
                    <?php echo "&nbsp&nbsp&nbsp&nbsp" . $User->getFechaNacimento(); ?>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-4">
                    <label>Número de telefono:</label>
                </div>
                <div class="col-md-6">
                    <?php echo "&nbsp&nbsp&nbsp&nbsp".$User->getTelefono(); ?>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-4">
                    <label>Correo:</label>
                </div>
                <div class="col-md-6">
                    <?php echo "&nbsp&nbsp&nbsp&nbsp".$User->getCorreo(); ?>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-4">
                    <label>Identificación: </label>
                </div>
                <div class="col-md-4">
                    <?php echo "&nbsp&nbsp&nbsp&nbsp" . $User->getTipoId(); ?>
                </div>
                <div class="col-md-4">
                    <?php echo "&nbsp&nbsp&nbsp&nbsp" . $User->getNumeroId(); ?>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-4">
                    <label>Pais de residencia:</label>
                </div>
                <div class="col-md-6">
                    <?php echo "&nbsp&nbsp&nbsp&nbsp" . $User->getPaisResidencia(); ?>
                </div>
            </div>
            <hr>
            <?php if ($User->getPaisResidencia() == "Costa Rica") { ?>
                <div class="row">
                    <div class="col-md-4">
                        <label>Direccion:</label>
                    </div>
                    <div class="col-md-6">
                        <?php echo "&nbsp&nbsp&nbsp&nbsp" . $Direccion->getProvincia() . ", " . $Direccion->getCanton() . ", " . $Direccion->getDistrito(); ?>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>