<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/ControlSesion.inc.php';
include_once '../../app/Direccion/DireccionRepo.inc.php';
if (ControlSesion::SesionStarted() && $_SESSION['SessionType'] == 1) {
    header('Location: \PY2\index.php', true, 301);
    exit();
}
Connection::openConnection();
$tittle = "Configuracion de perfil";
$Empresa = EmpresaRepo::getEmpresaByID(Connection::getConnection());
$Direccion = DireccionRepo::getDireccionByID(Connection::getConnection(), $Empresa->getID_Direccion());
Connection::closeConnection();
include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';

if (ControlSesion::SesionStarted()) {
    if ($_SESSION['SessionType'] === 1) {
        header('Location: \PY2\index.php', true, 301);
        exit();
    }else{
        header('Location: ../Habitaciones/Habitaciones.php', true, 301);
        exit();
    }
}
if (isset($_POST['send'])) {
    Connection::openConnection();
    $validador = new AccountValidator($_POST['nombre'], $_POST['nacimiento'], $_POST['telefono'], $_POST['Correo'], $_POST['clave1'], $_POST['clave2'],Connection::getConnection());
    Connection::closeConnection();
    if ($validador->validAccount()) {
         
        //echo 'Todo correcto';
        header('Location: RegisterInfoUser.php?nombre=' . $validador->getNombre() . '&fecha=' . $validador->getNacimiento() . '&telefono=' . $validador->getTelefono()
                . '&correo=' . $validador->getCorreo() . '&pss=' . password_hash($validador->getClave(),PASSWORD_DEFAULT), true, 301);
        exit();
    }
}
if (isset($_POST['send'])) {

    if ($_POST['selectPais'] === "cr") {
        $PaisResidencia = "Costa Rica";
        $Direccion = new Direccion($_POST['Provincia'], $_POST['Canton'], $_POST['Distrito'], "", "");
    } else {
        $PaisResidencia = $_POST['otroPais'];
        $Direccion = "x";
    }
    $User = new User("x", $_GET['nombre'], $_GET['fecha'], $_GET['telefono'], $_GET['correo'], $_GET['pss'], $_POST['Nombre'], $_POST['Apellido1'], $_POST['Apellido2'], $_POST['tipoId'], $_POST['numId'], $PaisResidencia);

    Connection::openConnection();
    $valor = UserRepo::InsertUser(Connection::getConnection(), $User, $Direccion);
    Connection::closeConnection();
    if ($valor) {
        header('Location:\PY2\Main\User\LoginUser.php', true, 301);
        exit();
    }

}
Connection::closeConnection();

?>

<div class="container" style="margin-top: 50px">
    <div class="panel panel-default" style="background-color: white;">
        <div class="panel panel-heading">
            <a href="../Habitaciones/Habitaciones.php">Volver</a>
            <h2>Configuración de perfil</h2>
        </div>
        <div class="panel panel-body">
            <form autocomplete="off" role="form" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
                <h3>Información general</h3>
                <div class="row">
                    <div class="col-md-2">
                        <label style='margin-left: 10%'>Nombre</label>
                    </div>
                    <div class="col-md-6">
                        <?php
                        echo $Empresa->getNombre()
                        ?>                              
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <label style='margin-left: 10%'>Cedula juridica</label>
                    </div>
                    <div class="col-md-6">
                        <?php echo $Empresa->getCed_Jur(); ?>                              
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <label style='margin-left: 10%'>Tipo</label>
                    </div>
                    <div class="col-md-6">
                        <?php echo $Empresa->getTipo(); ?>                           
                    </div>
                </div>
                <hr>
                <h3> Servicios</h3>
                <div class="row">
                    <div class="col-md-2">
                        <input <?php
                        if ($Empresa->getHasPool()) {
                            echo 'checked';
                        }
                        ?> type="checkbox"  id="hasPool" name="hasPool" >
                        <label for="hasPool"> Piscina</label>
                    </div>
                    <div class="col-md-2">
                        <input <?php
                        if ($Empresa->getHasWiFi()) {
                            echo 'checked';
                        }
                        ?> type="checkbox" id="hasWifi" name="hasWifi" >
                        <label for="hasWifi"> WiFi</label>
                    </div>
                    <div class="col-md-2">
                        <input <?php
                        if ($Empresa->getHasRest()) {
                            echo 'checked';
                        }
                        ?> type="checkbox" id="hasRest" name="hasRest" >
                        <label for="hasRest"> Restaurante</label>
                    </div>
                    <div class="col-md-2">
                        <input <?php
                        if ($Empresa->getHasBar()) {
                            echo 'checked';
                        }
                        ?> type="checkbox" id="hasBar" name="hasBar" >
                        <label for="hasBar"> Bar</label>
                    </div>
                    <div class="col-md-2">
                        <input <?php
                        if ($Empresa->getHasRanch()) {
                            echo 'checked';
                        }
                        ?> type="checkbox" id="hasRanch" name="hasRanch" >
                        <label for="hasRanch"> Ranchos</label>
                    </div>
                </div>
                <div class="row" >
                    <div class="col-md-2">
                        <label style='margin-left: 3%'>Otros servicios</label>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group" id="sevicios">                       
                            <input  name="hasOtros" id="hasOtros" type="text" 
                            <?php
                            echo "value='" . $Empresa->getHasOtros() . "'";
                            ?> class="form-control" disabled>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <a  class="btn btn-primary" onclick="enable('hasOtros')" style="float:right">Editar</a>
                    </div>
                </div>
                <hr>
                <h3>Ubicación</h3>
                <div class="row">
                    <div class="col-md-2">
                        <label style='margin-left: 10%'>Provincia</label>
                    </div>
                    <div class="col-md-6">
                        <?php echo $Direccion->getProvincia(); ?>                           
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <label style='margin-left: 10%'>Cantón</label>
                    </div>
                    <div class="col-md-6">
                        <?php echo $Direccion->getCanton(); ?>                           
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <label style='margin-left: 10%'>Distrito</label>
                    </div>
                    <div class="col-md-6">
                        <?php echo $Direccion->getDistrito(); ?>                                
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <label style='margin-left: 10%'>Barrio</label>
                    </div>
                    <div class="col-md-6">
                        <?php echo $Direccion->getBarrio(); ?>                                 
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <label style='margin-left: 10%'>Señas</label>
                    </div>
                    <div class="col-md-6">
                        <?php echo $Direccion->getSenias(); ?>                   
                    </div>
                </div>
                <div class="row">
                    <style>
                        #map {
                            height: 300px; 
                            width: 100%;  
                        </style>            
                        <div id="map"></div>
                        <script>
                            function initMap() {
                                var valLat = <?php echo $Empresa->getLatitud(); ?>;
                                var valLon = <?php echo $Empresa->getLongitud(); ?>;
                                var uluru = {lat: valLat, lng: valLon};
                                var map = new google.maps.Map(
                                        document.getElementById('map'), {zoom: 15, center: uluru});
                                var marker = new google.maps.Marker({position: uluru, map: map});
                            }
                        </script>              
                        <script async defer
                                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBJsDLaIChZoMPlQVWT-Eh-sc1aZ6m5OCQ&callback=initMap">
                        </script>                          
                    </div>
                    <h3>Información de contacto</h3>
                    <div class="row">
                        <div class="col-md-2">
                            <label style='margin-left: 10%'>N.Telefónico 1</label>
                            </div>
                            <div class="col-md-6">
                                <?php echo $Empresa->getTelefono1(); ?>                         
                            </div>
                        </div>               
                        <div class="row">
                            <div class="col-md-2">
                                <label style='margin-left: 10%'>N.Telefonico 2</label>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group"  >
                                    <?php echo $Empresa->getTelefono2(); ?>
                                    <input name="numero2" id="numero2" type="number"
                                    <?php
                                    if (null !== $Empresa->getTelefono2()) {
                                        echo "value='" . $Empresa->getTelefono2() . "'";
                                    } else {
                                        echo "placeholder='No se registró un segundo numero de teléfono'";
                                    }
                                    ?> class="form-control" disabled>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <a class="btn btn-primary" onclick="enable('numero2');" style="float:right">Editar</a>
                            </div>
                        </div>               
                        <div class="row">
                            <div class="col-md-2">
                                <label style='margin-left: 10%'>Correo</label>
                            </div>
                            <div class="col-md-6">
                                <?php echo $Empresa->getCorreo(); ?>      
                            </div>
                        </div>               
                        <div class="row">
                            <div class="col-md-2">
                                <label style='margin-left: 10%'>URL Sitio web</label>
                            </div>
                            <div class="col-md-6">
                                <input name="SitioWeb" id="SitioWeb" type="url"
                                <?php
                                if ("" !== $Empresa->getURL_pag()) {
                                    echo "value='" . $Empresa->getURL_pag() . "'";
                                } else {
                                    echo "placeholder='No se registró pagina web'";
                                }
                                ?> class="form-control" disabled >
                            </div>
                            <div class="col-md-4">
                                <a class="btn btn-primary" onclick="enable('SitioWeb');" style="float:right">Editar</a>
                            </div>
                        </div>               
                        <h4>RedesSociales</h4>
                        <div class="row">
                            <div class="col-md-2">
                                <label style='margin-left: 10%'>Facebook</label>
                            </div>
                            <div class="col-md-6">
                                <input name="Facebook" id="Facebook" type="url"
                                <?php
                                if ("" !== $Empresa->getFacebook()) {
                                    echo "value='" . $Empresa->getFacebook() . "'";
                                } else {
                                    echo "placeholder='No se registró un perfil de Facebook'";
                                }
                                ?> class="form-control" disabled>                           
                            </div>
                            <div class="col-md-4">
                                <a class="btn btn-primary" onclick="enable('Facebook');" style="float:right">Editar</a>
                            </div>
                        </div>               
                        <div class="row">
                            <div class="col-md-2">
                                <label style='margin-left: 10%'>Instagram</label>
                            </div>
                            <div class="col-md-6">
                                <input name="Instagram" id="Instagram" type="url"
                                <?php
                                if ("" !== $Empresa->getInstagram()) {
                                    echo "value='" . $Empresa->getInstagram() . "'";
                                } else {
                                    echo "placeholder='No se registró un perfil de Instagram'";
                                }
                                ?> class="form-control" disabled>                           
                            </div>
                            <div class="col-md-4">
                                <a class="btn btn-primary"  onclick="enable('Instagram');" style="float:right">Editar</a>
                            </div>
                        </div>               
                        <div class="row">
                            <div class="col-md-2">
                                <label style='margin-left: 10%'>Twitter</label>
                            </div>
                            <div class="col-md-6">
                                <input name="Twitter" id="Twitter" type="url"
                                <?php
                                if ("" !== $Empresa->getTwitter()) {
                                    echo "value='" . $Empresa->getTwitter() . "'";
                                } else {
                                    echo "placeholder='No se registró un perfil de Twitter'";
                                }
                                ?> class="form-control" disabled>                           
                            </div>
                            <div class="col-md-4">
                                <a class="btn btn-primary" onclick="enable('Twitter');" style="float:right">Editar</a>
                            </div>
                        </div>               
                        <div class="row">
                            <div class="col-md-2">
                                <label style='margin-left: 10%'>Youtube</label>
                            </div>
                            <div class="col-md-6">
                                <input name="YouTube" id="YouTube" type="url"
                                <?php
                                if ("" !== $Empresa->getYoutube()) {
                                    echo "value='" . $Empresa->getYoutube() . "'";
                                } else {
                                    echo "placeholder='No se registró canala de YouTube'";
                                }
                                ?> class="form-control" disabled>                           
                            </div>
                            <div class="col-md-4">
                                <a class="btn btn-primary" onclick="enable('YouTube');" style="float:right">Editar</a>
                            </div>
                        </div>               
                        <div class="row">
                            <div class="col-md-2">
                                <label style='margin-left: 10%'>Airbnb</label>
                            </div>
                            <div class="col-md-6">
                                <input name="Airbnb" id="Airbnb" type="url"
                                <?php
                                if ("" !== $Empresa->getAirbnb()) {
                                    echo "value='" . $Empresa->getAirbnb() . "'";
                                } else {
                                    echo "placeholder='No se registró un perfil de Airbnb'";
                                }
                                ?> class="form-control" disabled>                          
                            </div>
                            <div class="col-md-4">
                                <a class="btn btn-primary" onclick="enable('Airbnb');" style="float:right">Editar</a>
                            </div>
                        </div>
                        <hr>
                       
                        <button  onclick="enableAll()" type="submit" name="send" class="btn btn-primary" style="float: right" >
                            Guardar cambios
                        </button> 
                    </form>

                </div>
            </div>

        </div>
        <script>
            function disable() {
                document.getElementById("name").disabled = true;
            }
            function enable($element) {
                document.getElementById($element).disabled = false;
            }
            function enableAll(){
                document.getElementById('numero2').disabled=false;
                document.getElementById('SitioWeb').disabled=false;
                document.getElementById('Facebook').disabled=false;
                document.getElementById('Twitter').disabled=false;
                document.getElementById('YouTube').disabled=false;
                document.getElementById('Airbnb').disabled=false;
                document.getElementById('Instagram').disabled=false;
                document.getElementById('hasOtros').disabled=false;
            }
        </script>
