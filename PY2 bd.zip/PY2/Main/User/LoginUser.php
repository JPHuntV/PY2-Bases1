<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/User/UserRepo.inc.php';
include_once '../../app/User/LoginUserVal.inc.php';
include_once '../../app/ControlSesion.inc.php';

if (ControlSesion::SesionStarted()) {
    if ($_SESSION['SessionType'] === 1) {
        header('Location: \PY2\index.php', true, 301);
        exit();
    } else {
        header('Location: \PY2\Main\Habitaciones\Habitaciones.php', true, 301);
        exit();
    }
}
if (isset($_POST['send'])) {
    Connection::openConnection();
    $validador = new LoginUserVal($_POST['Correo'], $_POST['Clave'], Connection::getConnection());
    if ($validador->getError() === '' && !is_null($validador->getUser())) {
        ControlSesion::StartSesion($validador->getUser()->getID_Usuario(), $validador->getUser()->getUsuario(), $validador->getUser()->getCorreo(), 1);
        if (isset($_GET['ID']) && !empty($_GET['ID']) && isset($_GET['h']) && !empty($_GET['h'])) {
            header('Location: \PY2\Main\Reservaciones\Reservacion.php?ID=' . $_GET['ID'] . '&h='. $_GET['h'], true, 301);
        } else if(isset($_GET['ID']) && !empty($_GET['ID']) && isset($_GET['a']) && !empty($_GET['a'])){
             header('Location: \PY2\Main\Actividades\VistaActividadesC.php?ID=' . $_GET['ID'] , true, 301);
        }else {
            header('Location:\PY2\index.php', true, 301);
           
        }
         exit();
        Connection::closeConnection();
    }
}
$tittle = "Iniciar sesión";
include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';
if(isset($_GET['ID'])){
     echo "<div class='alert alert-warning' role='alert' style='text-align: center'> ¡Porfavor inicia sesión para continuar! </div>";
}
include_once '../../plantillas/cierre.inc.php';
?>


<div class='container'>
    <div class='row' style="margin-top: 20px">
        <div class='col-md-6 col-md-offset-3'>
            <div class="panel panel-default" >
                <div class="panel-heading text-center" style="background-color: white">
                    <h1 class="panel-title w-100 font-weight-bold" style="font-size: 28px ">Iniciar Sesión</h1>
                </div>

                <form autocomplete="off" role="form" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
                    <div class="modal-body" style="justify-content: center">
                        <?php
                        if (isset($_POST['send'])) {
                            $validador->showError();
                        }
                        ?>
                        <div class="form-group" id="Correo">
                            <label style='margin-left: 10%'>Correo</label>
                            <input name="Correo" type="email" class="form-control" style='margin-left: 10%; width: 80%' 
                            <?php
                            if (isset($_POST['send']) && isset($_POST['Correo']) && !empty($_POST['Correo'])) {
                                echo 'value= "' . $_POST['Correo'] . '"';
                            }
                            ?>required autofocus>
                        </div>
                        <div class="form-group" id="Clave">
                            <label style='margin-left: 10%'>Contraseña</label>
                            <input name="Clave" type="password" class="form-control" style='margin-left: 10%; width: 80%' required>
                        </div>

                    </div>
                    <div class="modal-footer" style="text-align: left" >
                        <button  type="submit" name="send" class="btn btn-block btn-primary" style='margin-left: 10%; width: 80%; background-color: #540094;border-color: #540094; margin-top: 20px'>
                            Inciar sesión
                        </button><br>    
                        <a href="RegisterInfoCuenta.php" style='margin-left: 10%' >¿No tienes una cuenta? Registrate</a>  
                        <br>
                        <a href="#" style='margin-left: 10%' >¿Olvidaste tu contraseña?</a>  

                    </div>
                </form>

            </div>  
        </div>
    </div>

</div>