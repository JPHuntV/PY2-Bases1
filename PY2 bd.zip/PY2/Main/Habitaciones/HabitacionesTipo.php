<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/Habitaciones/HabitacionRepo.inc.php';
include_once '../../app/Habitaciones/Habitacion.inc.php';
include_once '../../app/Habitaciones/RegisterHabitacionVal.inc.php';
$tittle = "Habitaciones";
include_once '../../app/ControlSesion.inc.php';
if (!ControlSesion::SesionStarted() || $_SESSION['SessionType'] === 1) {
    header('Location:  \PY2\index.php', true, 301);
    exit();
}
if (isset($_POST['sendHab'])) {


    Connection::openConnection();
    $validador = new RegisterHabitacionVal($_POST['Numero'], Connection::getConnection());
    if ($validador->validAccount()) {
        $Habitacion = new Habitacion($_SESSION['ID'], $_POST['Numero'], $_POST['Tipo'], $_POST['Estado']);
        $valor = HabitacionRepo::InsertHabitacion(Connection::getConnection(), $Habitacion);
    }

    Connection::closeConnection();
    /* if ($valor) {
      header('Location: ../../index.php', true, 301);
      exit(); */
}

include_once '../../plantillas/declaracion.inc.php';

include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
?>


<nav class="navbar-default navbar-static" style="background-color: whitesmoke" >
    <div class="container" style='background-color: whitesmoke; margin-top:50px'>
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>
        <div id="navbar2" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="Habitaciones.php">Habitaciones</a></li>
                <li><a href="#">Tipos</a></li>
                <li><a href="#">Clientes</a></li>
                <li><a href="../../Main/Reservaciones/Reservaciones.php">Reservaciones</a></li>
                <li><a href="#">Facturación</a></li>
                <li><a href="../../Main/Actividades/ActividadesEmpresa.php">Actividades de recreación</a></</li>
            </ul>
            <ul class="nav navbar-right">
                <li>
                    <a  href="RegisterHabitaciontipo.php">
                        <span class="glyphicon glyphicon-plus-sign"></span>
                        Registrar tipos
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container">

    <div class="panel-default" >
        <?php
        Connection::openConnection();
        $result = HabitacionRepo::getTipos(Connection::getConnection(), false);
        if (!empty($result)) {
            foreach ($result as $valor) {
                $target = HabitacionRepo::getMiniatura(Connection::getConnection(), $valor->getNombre(), $_SESSION['ID']);
                $target = $target[0]['imagen'];
                ?>
                <br>       
                <div class="panel-body" style="background-color:white" >
                    <div class="row">
                        <div class="col-md-3" >
                            <?php echo "<img src='../../" . $target . "' id = 'imagen2' name = 'imagen2' style = 'padding:0; width: 200px; height: 200px;' />" ?>
                        </div>
                        <div class="col-md-6" >
                            <div class="row">
                                <span><h3>Tipo: <?php echo $valor->getNombre() ?></h3></span>
                            </div>
                            <div class="row">
                                <?php
                                if ($valor->getHasWiFi()) {
                                    echo "<i class = 'fa fa-wifi fa-2x' aria-hidden = 'true'></i>:Wifi";
                                }
                                if ($valor->gethasAC()) {
                                    echo "<i class = 'fa fa-snowflake-o fa-2x' aria-hidden = 'true'></i>:Aire acondicionado";
                                }
                                if ($valor->getHasHotWater()) {
                                    echo "<i class = 'fa fa-thermometer-three-quarters fa-2x' aria-hidden = 'true'></i>:Agua caliente";
                                }
                                if ($valor->getHasFan()) {
                                    echo "<i class = 'fa fa-dot-circle-o fa-2x' aria-hidden = 'true'></i>:Ventilador";
                                }
                                ?>
                            </div>
                            <div class="row">                           
                                <span>Descripcion:<br>&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $valor->getDescripcion() ?></span>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <?php $path = "\PY2\Main\Habitaciones\ConfiguracionHabitacionTipo.php?ID=" . $valor->getNombre() . "&h=" . $_SESSION['ID']; ?>
                            <a class="btn btn-primary" <?php echo "href=" . $path; ?>>Más Detalles</a>
                        </div>
                        <?php //$path = "VistaHabitacionE.inc.php?ID=" . $valor->getNumero(); ?>                           
                    </div>
                </div>
                <?php
            }
        }
        Connection::closeConnection();
        ?> 
    </div>    
</div>

<script type="text/javascript">

    function PreviewImage($boton, $imagen) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById($boton).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById($imagen).src = oFREvent.target.result;
        };
    }
    ;

</script>
