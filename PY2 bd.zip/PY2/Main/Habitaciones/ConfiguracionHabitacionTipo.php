<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/Habitaciones/HabitacionRepo.inc.php';
include_once '../../app/Habitaciones/Habitacion.inc.php';
include_once '../../app/Habitaciones/RegisterHabitacionVal.inc.php';
$tittle = "Habitaciones";
session_start();
include_once '../../app/ControlSesion.inc.php'; /*
  if (!ControlSesion::SesionStarted() || $_SESSION['SessionType'] === 1) {
  header('Location:  \PY2\index.php', true, 301);
  exit();
  } */
Connection::openConnection();
$Tipo = HabitacionRepo::getInfoTipo(Connection::getConnection(), $_GET['ID']);
Connection::closeConnection();

if (isset($_POST['send'])) {
    Connection::openConnection();
    if (isset($_POST['hasAC'])) {
        $hasAC = 1;
    } else {
        $hasAC = 0;
    }
    if (isset($_POST['hasWifi'])) {
        $hasWifi = 1;
    } else {
        $hasWifi = 0;
    }
    if (isset($_POST['hasHotWater'])) {
        $hasHotWater = 1;
    } else {
        $hasHotWater = 0;
    }
    if (isset($_POST['hasFan'])) {
        $hasFan = 1;
    } else {
        $hasFan = 0;
    }
    $target = HabitacionRepo::getImagenes(Connection::getConnection(), $Tipo[0]['Nombre'], $Tipo[0]['ID_Hospedaje']);

    $image1T = $_FILES['uploadImage1']['name'];
    $image1 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_1" . basename($image1T);
    $target1 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_1";

    $image2T = $_FILES['uploadImage2']['name'];
    $image2 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_2" . basename($image2T);
    $target2 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_2";

    $image3T = $_FILES['uploadImage3']['name'];
    $image3 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_3" . basename($image3T);
    $target3 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_3";

    $image4T = $_FILES['uploadImage4']['name'];
    $image4 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_4" . basename($image4T);
    $target4 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_4";


    if ($image1T == "") {
        $target1 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_1";
        $image1 = $target[0];
    }
    if ($image2T == "") {

        $target2 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_2";
        $image2 = $target[1];
    }
    if ($image3T == "") {

        $target3 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_3";
        $image3 = $target[2];
    }
    if ($image4T == "") {

        $target4 = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_4";
        $image4 = $target[3];
    }

    $targetMT = HabitacionRepo::getMiniatura(Connection::getConnection(), $Tipo[0]['Nombre'], $_SESSION['ID']);
    $imageMT = $_FILES['uploadImageM']['name'];
    $imageM = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_M" . basename($imageMT);
    $targetM = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_M";
    //$target = HabitacionRepo::getMiniatura(Connection::getConnection(), $Tipo[0]['Nombre'], $_SESSION['ID']);
    if ($imageMT == "") {
        $targetM = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_M";
        $imageM = $targetMT[0]['imagen'];
    }
    echo "<br>";
    echo $target1;
    echo "<br>";
    echo $image1;

    echo "<br>";
    echo $target2;
    echo "<br>";
    echo $image2;

    echo "<br>";
    echo $target3;
    echo "<br>";
    echo $image3;

    echo "<br>";
    echo $target4;
    echo "<br>";
    echo $image4;

    echo "<br>";
    echo $targetM;
    echo "<br>";
    echo $imageM;
    $TipoHab = new TipoHabitacion($_SESSION['ID'], $Tipo[0]['Nombre'], $_POST['Descripcion'], $_POST['Precio'], $hasAC, $hasWifi, $hasHotWater, $hasFan, $_POST['Comodidades'], $image1, $image2, $image3, $image4, $imageM);
    $valor = HabitacionRepo::UpdateTipoHab(Connection::getConnection(), $TipoHab, $target1, $target2, $target3, $target4, $targetM);

    if ($valor) {
        $target1 = "../../img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_1" . basename($image1T);

        $target2 = "../../img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_2" . basename($image2T);

        $target3 = "../../img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_3" . basename($image3T);

        $target4 = "../../img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_4" . basename($image4T);

        $targetM = "../../img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $Tipo[0]['Nombre'] . "_M" . basename($imageMT);

        if (file_exists("../../" . $image1)) {
            unlink("../../" . $image1);
        }
        move_uploaded_file($_FILES['uploadImage1']['tmp_name'], $target1);
        if (file_exists("../../" . $image2)) {
            unlink("../../" . $image2);
        }
        move_uploaded_file($_FILES['uploadImage2']['tmp_name'], $target2);
        if (file_exists("../../" . $image3)) {
            unlink("../../" . $image3);
        }
        move_uploaded_file($_FILES['uploadImage3']['tmp_name'], $target3);
        if (file_exists("../../" . $image4)) {
            unlink("../../" . $image4);
        }
        move_uploaded_file($_FILES['uploadImage4']['tmp_name'], $target4);
        if (file_exists("../../".$targetMT[0]['imagen'])) {
            unlink("../../".$targetMT[0]['imagen']);
        }
        move_uploaded_file($_FILES['uploadImageM']['tmp_name'], $targetM);
        // header('Location: Habitaciones.php', true, 301);
        //exit();
    } else {
        echo "fail";
    }

    Connection::closeConnection();
}
include_once '../../plantillas/declaracion.inc.php';

include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
?>


<nav class="navbar-default navbar-static" >
    <div class="container-fluid" style='background-color: white;
         margin-top:50px'>
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>
        <div id="navbar2" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="HabitacionesTipo.php"><span class="glyphicon glyphicon-chevron-left"></span>Volver</a></li>
                <li><a href="#">Registrar habitacion</a></li>

            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <div class="panel panel-default">          
        <form autocomplete="off" role="form" enctype="multipart/form-data" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
            <div class="panel panel-body">
                <h3>Información general</h3>
                <div class="row" >                   
                    <div class="col-md-4" style="text-align: center">
                        <?php
                        Connection::openConnection();
                        $target = HabitacionRepo::getMiniatura(Connection::getConnection(), $Tipo[0]['Nombre'], $_SESSION['ID']);
                        $target = $target[0]['imagen'];
                        Connection::closeConnection();
                        ?>
                        <img <?php echo"src='../../" . $target . "'"; ?> id="imagenM" name="imagenM" style="width: 250px; height: 250px; " />
                        <input  class="btn btn-primary" id="uploadImageM" name="uploadImageM" type="file"  onchange="PreviewImage('uploadImageM', 'imagenM');" />
                        <?php
                        /*  if (isset($_POST['send'])) {
                          $validador->showErrorMiniatura();
                          } */
                        ?>
                    </div>
                    <div class="col-md-6" >
                        <div class="row">
                            Nombre: <?php echo $Tipo[0]['Nombre']; ?>
                        </div>

                        <div class="row">
                            <div class="form-group" >
                                <label >Descripción</label>  
                                <textarea class="form-control" id="Descripcion" name="Descripcion" maxlength="200" style=' width: 100%;
                                          resize: none;
                                          ' rows="5" cols="100"><?php
                                              if ("" !== $Tipo[0]['Descripcion']) {
                                                  echo $Tipo[0]['Descripcion'];
                                              } else {
                                                  echo "placeholder='No se registró un segundo numero de teléfono'";
                                              }
                                              ?>
                                </textarea> 
                            </div> 
                        </div>
                    </div><br><br>

                </div>                                   

                <h3>Comodidades</h3>
                <div class="row" >
                    <input  <?php
                    if ($Tipo[0]['hasAC']) {
                        echo 'checked';
                    }
                    ?>type="checkbox" id="hasAC" name="hasAC" >
                    <label for="hasAC">A/C</label>
                    <input  <?php
                    if ($Tipo[0]['hasWifi']) {
                        echo 'checked';
                    }
                    ?>  type="checkbox" id="hasWifi" name="hasWifi" >
                    <label for="hasWifi"> WiFi</label>


                    <input  <?php
                    if ($Tipo[0]['hasHotWater']) {
                        echo 'checked';
                    }
                    ?> type="checkbox" id="hasHotWater" name="hasHotWater" >
                    <label for="hasHotWater"> Agua caliente</label>

                    <input  <?php
                    if ($Tipo[0]['hasFan']) {
                        echo 'checked';
                    }
                    ?> type="checkbox" id="hasFan" name="hasFan" >
                    <label for="hasFan">Ventilador</label>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Otras</label> 
                            <textarea  class="form-control" id="Comodidades" name="Comodidades" maxlength="200" style=' width: 100%;
                                       resize: none;
                                       ' rows="5" cols="100"><?php
                                           if ("" !== $Tipo[0]['Comodidades']) {
                                               echo $Tipo[0]['Comodidades'];
                                           } else {
                                               echo "placeholder='No se registró un segundo numero de teléfono'";
                                           }
                                           ?></textarea>    
                        </div>
                    </div>
                </div>
                <div class="row" >

                    <?php
                    Connection::openConnection();
                    $target = HabitacionRepo::getImagenes(Connection::getConnection(), $Tipo[0]['Nombre'], $Tipo[0]['ID_Hospedaje']);
                    Connection::closeConnection();
                    ?>
                    <div class="col-md-3" >
                        <img <?php echo "src='../../" . $target[0] . "' "; ?> id="imagen1" name="imagen1" style="width: 200px; height: 200px;"/>
                        <input  id="uploadImage1" name="uploadImage1" type="file"  onchange="PreviewImage('uploadImage1', 'imagen1');" />

                    </div>
                    <div class="col-md-3">
                        <img <?php echo "src='../../" . $target[1] . "' "; ?> id="imagen2" name="imagen2" style="width: 200px; height: 200px;" />
                        <input id="uploadImage2" name="uploadImage2" type="file"  onchange="PreviewImage('uploadImage2', 'imagen2');" />

                    </div>
                    <div class="col-md-3">                           
                        <img <?php echo "src='../../" . $target[2] . "' "; ?> id="imagen3" name="imagen3" style="width: 200px; height: 200px;" />
                        <input  id="uploadImage3" name="uploadImage3" type="file"  onchange="PreviewImage('uploadImage3', 'imagen3');" />

                    </div>
                    <div class="col-md-3">                          
                        <img <?php echo "src='../../" . $target[3] . "' "; ?> id="imagen4" name="imagen4" style="width: 200px; height: 200px;" />
                        <input id="uploadImage4" name="uploadImage4" type="file" onchange="PreviewImage('uploadImage4', 'imagen4');" />

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group" id="precio">


                        </div>
                        <div class="form-group" id="precio">
                            <label style='margin-left: 10%'>Precio</label>
                            <input name="Precio" type="number" <?php echo "value='" . $Tipo[0]['Precio'] . "'";
                    ?> class="form-control" style='margin-left: 10%;
                                   width: 80%' required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <button class="btn btn-block bg-primary" type="submit" name="send" style='margin-left: 10%;
                                width: 80%'>Registrar habitación</button>
                    </div>
                </div>
        </form>
    </div> 
</div>

<script type="text/javascript">

    function PreviewImage($boton, $imagen) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById($boton).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById($imagen).src = oFREvent.target.result;
        };
    }
    ;

</script>
</div>
<script>
    function disable() {
        document.getElementById("name").disabled = true;
    }
    function enable($element) {
        document.getElementById($element).disabled = false;
    }
    function enableAll() {
        document.getElementById('numero2').disabled = false;
        document.getElementById('SitioWeb').disabled = false;
        document.getElementById('Facebook').disabled = false;
        document.getElementById('Twitter').disabled = false;
        document.getElementById('YouTube').disabled = false;
        document.getElementById('Airbnb').disabled = false;
        document.getElementById('Instagram').disabled = false;
        document.getElementById('hasOtros').disabled = false;
    }
</script>

