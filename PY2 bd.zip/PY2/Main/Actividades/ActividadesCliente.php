<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/Actividad/ActividadRepo.inc.php';
include_once '../../app/ControlSesion.inc.php';
if (ControlSesion::SesionStarted() && $_SESSION['SessionType'] == 0) {
    header('Location: Main/Habitaciones/Habitaciones.php', true, 301);
    exit();
}
$tittle = "Inicio";
include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';
if(isset($_GET['s'])){ 
     echo "<div class='alert alert-success' role='alert' style='text-align: center'> ¡Se ha registrado tu contrato! </div>";
}
include_once '../../plantillas/cierre.inc.php';
?>

<nav class="navbar-default navbar-static" style='background-color: whitesmoke;' >
    <div class="container" style= 'padding-top:50px'>
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>
        <div id="navbar2" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="../../index.php">Sitios de hospedaje</a></li>
                <li><a href="#">Actividades de recreación</a></li>

            </ul>
        </div>
    </div>
</nav>

<div class="container" >
    <div class="panel-default" style="background-color: white;">
        <div class="panel-body">
            <form autocomplete="off" role="form" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
                <div class='row'>
                    <div class='col-md-3'>

                        <div class="form-group" id="Ubicacion">
                            <label >¿A donde vas?</label>
                            <input name="Ubicacion" id="Ubicacion" type="text" />
                        </div>

                    </div>       
                   
                    <div class='col-md-3'>
                        <div class="form-group" id="hospedaje">
                            <label >¿Que buscas?</label>
                            <select class="form-control" name="tipo" >
                                <option value="Todos">Todos</option>
                                <option value="Tour en Bote">Tour en Bote</option>
                                <option value="Tour en lancha">Tour en lancha</option>
                                <option value="Tour en catamarán">Tour en catamarán</option>
                                <option value="Kayak">Kayak</option>
                                <option value="Transporte">Transporte</option>                        
                            </select>

                        </div>
                    </div>
                    <div class="col-md-2"><br>
                        <button type="submit"  name="send" class="btn btn-default btn-primary" >
                            <span class="glyphicon glyphicon-search"></span>
                            Buscar
                        </button>                      
                    </div>            
                </div>    
            </form>
        </div>
    </div>
</div>
<br>
<div class="container" >
    <div class="panel-default" style="background-color: whitesmoke">
        <?php
        Connection::openConnection();
        $result = ActividadRepo::getActividades(Connection::getConnection());
        if (isset($_POST['send'])) {
            $result = ActividadRepo::getActividadesByFilter(Connection::getConnection(), $_POST['Ubicacion'], $_POST['tipo']);
        }
        if (!empty($result)) {
            foreach ($result as $valor) {
                $Tipos = ActividadRepo::getTipos(Connection::getConnection(), $valor->getID_Actividad());
                //$target = ActividadRepo::getMiniatura(Connection::getConnection(), $valor->getTipo(), $infoTipo[0]['ID_Hospedaje']);
                //$target = $target[0]['imagen'];
                ?>
                <div class="panel-body" style="background-color: white;">
                    <div class="row">
                        <div class="col-md-9" >
                            <div class="row">
                                Tipo:<?php
                                foreach ($Tipos as $tipo) {
                                    echo $tipo['Nombre'];
                                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                                }
                                ?>
                            </div>
                            <div class="row">
                                Empresa:<?php echo $valor->getEmpresa(); ?>
                            </div>
                            <div class="row">
                                Descripción:<?php echo $valor->getDescripcion(); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="row">
                                Precio:<?php echo $valor->getPrecio(); ?>
                            </div>
                            <div class="row">

                                <?php $path = "\PY2\Main\Actividades\VistaActividadesC.php?ID=" . $valor->getID_Actividad(); ?>
                                <a class="btn btn-primary" <?php echo "href=" . $path; ?> >Más Detalles</a>
                            </div>
                        </div>

                    </div>
                </div>
                <br>
                <?php
            }
        }
        Connection::closeConnection();
        ?>  

    </div>

    <br>
    <br>
    <br>
    <script>
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>

