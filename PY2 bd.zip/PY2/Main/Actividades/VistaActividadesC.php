<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/Actividad/ActividadRepo.inc.php';
include_once '../../app/Direccion/DireccionRepo.inc.php';
include_once '../../app/Actividad/Contrato.inc.php';
include_once '../../app/User/UserRepo.inc.php';
include_once '../../app/ControlSesion.inc.php';

if (ControlSesion::SesionStarted() && $_SESSION['SessionType'] == 0) {
    header('Location: \PY2\index.php', true, 301);
    exit();
}
Connection::openConnection();
$ID_Actividad = $_GET['ID'];
$Actividad = ActividadRepo::getActividadByID(Connection::getConnection(), $ID_Actividad);
$Direccion = DireccionRepo::getDireccionByID(Connection::getConnection(), $Actividad->getID_Direccion());
$Tipos = ActividadRepo::getTipos(Connection::getConnection(), $ID_Actividad);

if (ControlSesion::SesionStarted() && $_SESSION['SessionType'] == 1) {
    $Usuario = UserRepo::getUserByID(connection::getConnection(), $_SESSION['ID']);
}
Connection::closeConnection();
if (isset($_POST['pay'])) {
    Connection::openConnection();
    $Contrato = new Contrato("", $ID_Actividad, $_POST['Nombre'], $_POST['Correo'], $_POST['Telefono'], $_POST['Tarjeta'], $_POST['Fecha']);
    $ID = ActividadRepo::InsertContrato(Connection::getConnection(), $Contrato);
    if ($ID) {
        header('Location: \PY2\Main\Actividades\ActividadesCliente.php?s=True', true, 301);
        exit();
    }

    Connection::closeConnection();
}

$tittle = "Inicio";
include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
?>



<nav class="navbar-default navbar-static" style="background-color: whitesmoke" >
    <div class="container" style='background-color: whitesmoke; margin-top:50px'>
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>
        <div id="navbar2" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="../../Main/Actividades/ActividadesCliente.php">Actividades de recreación</a></</li>
                <li><a href="#">Actividad</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container" >
    <div class="panel panel-default">
        <div class="panel panel-heading">
            <h3>Informacion de la actividad</h3>
        </div>
        <div class="panel panel-body">
            <div class="row">
                <label>Tipo de actividad</label>
                <br>
                <?php
                foreach ($Tipos as $tipo) {
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    echo $tipo['Nombre'];
                }
                ?>
            </div>
            <hr>
            <div class="row">
                <label>Descripcion de la actividad</label>
                <br>
                <?php
                echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                echo $Actividad->getDescripcion();
                ?>
            </div>
            <hr>
            <h4>Información de la empresa</h4>
            <div class="row">
                <div class="col-md-6">
                    <label>Nombre: </label><?php echo " " . $Actividad->getEmpresa(); ?>
                </div>
                <div class="col-md-6">
                    <label>Correo: </label><?php echo " " . $Actividad->getCorreo(); ?>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-md-6">
                    <label>Número de teléfono: </label><?php echo " " . $Actividad->getTelefono(); ?>
                </div>
                <div class="col-md-6">
                    <label>Persona a contactar: </label><?php echo " " . $Actividad->getContacto(); ?>
                </div>
            </div>
            <br>
            <h5><label>Dirección</label></h5>
            <div class="row">
                <div class="col-md-4">
                    <label>Provincia:</label><?php echo $Direccion->getProvincia(); ?>
                </div>
                <div class="col-md-4">
                    <label>Cantón:</label><?php echo $Direccion->getCanton(); ?>

                </div>
                <div class="col-md-4">
                    <label>Distrito:</label><?php echo $Direccion->getDistrito(); ?>                   
                </div>
            </div>
            <div class="row">
                <label>Señas:</label><?php echo " " . $Direccion->getSenias(); ?>
            </div>
            <hr>
            <div class="row">
                <label>Precio:</label><?php echo " " . $Actividad->getPrecio() ?>
                <?php
                if (ControlSesion::SesionStarted() && $_SESSION['SessionType'] === 1) {
                    $path = "#";
                } else {
                    $path = "\PY2\Main\User\LoginUser.php?ID=" . $ID_Actividad . "&a=" . true;
                }
                ?>
                <a class="btn btn-primary" <?php echo "href=" . $path; ?> style="float: right"
                <?php
                if (ControlSesion::SesionStarted() && $_SESSION['SessionType'] === 1) {
                    echo "data-toggle='modal' data-target='#myModal'";
                }
                ?> >Contratar servicio</a>
                <!--button style="float: right" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                    Launch demo modal
                </button-->
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Modal title</h4>
            </div>
            <div class="modal-body">
                <form autocomplete="off" role="form" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
                    <div class="modal-split">           
                        <label>Empresa: </label><?php echo $Actividad->getEmpresa(); ?>

                        <div class="row">
                            <label>Tipo de actividad</label>
                            <br>
                            <?php
                            foreach ($Tipos as $tipo) {
                                echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                                echo $tipo['Nombre'];
                            }
                            ?>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <label style='margin-left: 10%' >Fecha solictitada</label>
                                <div class='input-group date' id='Fecha'  style='margin-left: 10%; width: 80%'>
                                    <input type='text' class="form-control"  name="Fecha" />
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>

                                <script type="text/javascript">
                                    $(function () {
                                        var today = new Date();
                                        // var lastDate = new Date(today.getFullYear());
                                        var firstDate = new Date(today.getFullYear());
                                        $('#Fecha').datetimepicker({
                                            format: 'YYYY/DD/MM',
                                            minDate: firstDate
                                        });
                                    });
                                </script>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <label style='margin-left: 10%' >Nombre</label>
                                <input type="text" class="form-control" name="Nombre" <?php echo "value='" . $Usuario->getNombre() . "'" ?>
                                       style='margin-left: 10%; width: 80%' >
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group">
                                <label style='margin-left: 10%' >Correo</label>
                                <input type="email" <?php echo "value='" . $Usuario->getCorreo() . "'"; ?> class="form-control" name="Correo" style='margin-left: 10%; width: 80%'>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group">
                                <label style='margin-left: 10%' >Teléfono</label>
                                <input type="tel" <?php echo "value='" . $Usuario->getTelefono() . "'"; ?>  class="form-control" name="Telefono" style='margin-left: 10%; width: 80%'>
                            </div>
                        </div>          
                    </div>
                    <div class="modal-split">             
                        <div class="row">
                            <div class='col-md-12'>
                                <label class='control-label'>Name on Card</label>
                                <input class='form-control' size='4' type='text'>
                            </div>
                        </div>
                        <div class='row'>
                            <div class='col-md-12'>
                                <label class='control-label'>Card Number</label>
                                <input name="Tarjeta" autocomplete='off' class='form-control card-number' size='20' type='text'>
                            </div>
                        </div>
                        <div class='row'>
                            <div class='col-md-4'>
                                <label class='control-label'>CVC</label>
                                <input autocomplete='off' class='form-control card-cvc' placeholder='ex. 311' size='4' type='text'>
                            </div>
                            <div class='col-md-4'>
                                <label class='control-label'>Expiration</label>
                                <input class='form-control card-expiry-month' placeholder='MM' size='2' type='text'>
                            </div>
                            <div class='col-md-4'>
                                <label class='control-label'> </label>
                                <input class='form-control card-expiry-year' placeholder='YYYY' size='4' type='text'>
                            </div>
                        </div>
                        <hr>
                        <div class='row'>
                            <div class='col-md-6'>
                                <div class='form-control total btn btn-info'>
                                    Total:
                                    <span class='amount'><?php echo $Actividad->getPrecio(); ?></span>
                                </div>
                            </div>
                            <div class='col-md-6'>
                                <button   type="submit" name="pay" class=' btn btn-block btn-primary ' >Pay »</button>
                            </div>
                        </div>
                        <div class='form-row'>
                            <div class='col-md-12 error form-group hide'>
                                <div class='alert-danger alert'>
                                    Please correct the errors and try again.
                                </div>
                            </div>
                        </div>           
                    </div>
                </form>

            </div>
            <div class="modal-footer">
                <!--Nothing Goes Here but is needed! -->
            </div>
        </div>
    </div>
</div>
<script>

    $(document).ready(function () {
        prep_modal();
    });

    function prep_modal()
    {
        $(".modal").each(function () {
            var element = this;
            var pages = $(this).find('.modal-split');
            if (pages.length != 0)
            {
                pages.hide();
                pages.eq(0).show();
                var b_button = document.createElement("button");
                b_button.setAttribute("type", "button");
                b_button.setAttribute("class", "btn btn-primary");
                b_button.setAttribute("style", "display: none;");
                b_button.innerHTML = "Back";
                var n_button = document.createElement("button");
                n_button.setAttribute("type", "button");
                n_button.setAttribute("class", "btn btn-primary");
                n_button.innerHTML = "Next";
                $(this).find('.modal-footer').append(b_button).append(n_button);
                var page_track = 0;
                $(n_button).click(function () {

                    this.blur();
                    if (page_track == 0)
                    {
                        $(b_button).show();
                        $(n_button).show();
                    }
                    if (page_track == pages.length - 2)
                    {
                        $(n_button).text("Submit");
                        $(n_button).hide();
                    }
                    if (page_track == pages.length - 1)
                    {
                        $(element).find("form").submit();
                    }
                    if (page_track < pages.length - 1)
                    {
                        page_track++;
                        pages.hide();
                        pages.eq(page_track).show();
                    }
                });
                $(b_button).click(function () {
                    if (page_track == 1)
                    {
                        $(b_button).hide();
                    }
                    if (page_track == pages.length - 1)
                    {
                        $(n_button).show();
                        $(n_button).text("Siguiente");
                    }
                    if (page_track > 0)
                    {
                        page_track--;
                        pages.hide();
                        pages.eq(page_track).show();
                    }
                });
            }
        });
    }
</script>