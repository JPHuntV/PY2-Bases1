<h3>Información general</h3>
<div class="row">
    <div class="col-md-4">
        <div class="form-group" id="Nombre">
            <label style='margin-left: 10%'>Nombre</label>
            <input name="Nombre" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="CedJur">
            <label style='margin-left: 10%'>Cedula juridica</label>
            <input name="CedJur" type="number" class="form-control" <?php $validador->showCedJur() ?>  style='margin-left: 10%; width: 80%'>
            <?php
            $validador->ShowErrorCedJur();
            ?>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="tipoHos">
            <label style='margin-left: 10%' for="tipo">Tipo de hospedaje</label>
            <select class="form-control" name="tipoHos" style='margin-left: 10%; width: 80%'>
                <option value="Hotel">Hotel</option>
                <option value="Hostal">Hostal</option>
                <option value="Casa">Casa</option>
                <option value="Departamento">Departamento</option>
                <option value="Cuarto compartido">Cuarto compartido</option>
                <option value="Cabaña">Cabaña</option>                        
            </select>
        </div>
    </div>
</div>
<h3>Servicios de recreación</h3>


<div class="row" style="margin-left: 15px"><br>
    <div class="col-md-2">
        <input type="checkbox" id="hasPool" name="hasPool" >
        <label for="hasPool"> Piscina</label>
    </div>
    <div class="col-md-2">
        <input type="checkbox" id="hasWifi" name="hasWifi" >
        <label for="hasWifi"> WiFi</label>
    </div>
    <div class="col-md-2">
        <input type="checkbox" id="hasRest" name="hasRest" >
        <label for="hasRest"> Restaurante</label>
    </div>
    <div class="col-md-2">
        <input type="checkbox" id="hasBar" name="hasBar" >
        <label for="hasBar"> Bar</label>
    </div>
    <div class="col-md-2">
        <input type="checkbox" id="hasRanch" name="hasRanch" >
        <label for="hasRanch"> Ranchos</label>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <br>
        <div class="form-group" id="hasOtros">
            <label style='margin-left: 3%'>otros</label>
            <input name="hasOtros" type="text" class="form-control" style='margin-left: 3%; width: 94%'>
        </div>
    </div>
</div>
<h3>Ubicación</h3>
<div class="row">
    <div class="col-md-4">
        <div class="form-group" id="Provincia">
            <label style='margin-left: 10%'>Provincia</label>
            <input name="Provincia" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="Canton">
            <label style='margin-left: 10%'>Cantón</label>
            <input name="Canton" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="Distrito">
            <label style='margin-left: 10%'>Distrito</label>
            <input name="Distrito" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <div class="form-group" id="Barrio">
            <label style='margin-left: 10%'>Barrio</label>
            <input  name="Barrio" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="Senias">
            <label style='margin-left: 10%'>Señas</label>
            <input name="Senias" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="GPS">
            <label style='margin-left: 10%'>GPS </label>
            <button type="button" class="btn btn-primary" style='margin-left: 10%; width: 80%;' data-toggle="modal" data-target="#exampleModal">
                Seleccionar Ubicación 
            </button>
            <?php
            $validador->ShowErrorUbicacion();
            ?>
        </div>

        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <h2 class="modal-title" id="exampleModalLabel" style="text-align: center;margin-top:10px">Seleccionar Ubicación</h2>
                    </div>
                    <div class="modal-body" style="justify-content: center">
                        <div id="map" style=" width: 100%;padding-top: 80%;"></div>
                    </div>
                    <div class="modal-footer">

                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" id="confirmPosition" data-dismiss="modal">Confirmar ubicación</button>

                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" class="form-control"  name="lat" id='lat'   >
        <input type="hidden"  class="form-control"   name="lng" id='lng'>

        <script src="\PY2\js\map.js"></script>

    </div>
</div>
<h3>Información de contacto</h3>
<div class="row">
    <div class="col-md-4">
        <div class="form-group" id="numeros">
            <label style='margin-left: 10%'>Numeros de telefono</label>
            <input name="numero1" type="number" class="form-control" style='margin-left: 10%; width: 80%' required>
            <input name="numero2" type="number" class="form-control" style='margin-left: 10%;margin-top: 5px; width: 80%'>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="Correo">
            <label style='margin-left: 10%'>Correo</label>
            <input name="Correo" type="email" class="form-control" <?php $validador->showCorreo() ?>  style='margin-left: 10%; width: 80%' required>
            <?php
            $validador->ShowErrorCorreo();
            ?>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="SitioWeb">
            <label style='margin-left: 10%'>Sito Web</label>
            <input name="SitioWeb" type="url" class="form-control" style='margin-left: 10%; width: 80%'>
        </div>
    </div>
</div>
<h4 >Redes sociales</h4>
<div class="row">
    <div class="col-md-4">
        <div class="form-group" id="Facebook">
            <label style='margin-left: 10%'>Facebook</label>
            <input name="Facebook" type="url" class="form-control" style='margin-left: 10%; width: 80%' >
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="Instagram">
            <label style='margin-left: 10%'>Instagram</label>
            <input name="Instagram" type="url" class="form-control" style='margin-left: 10%; width: 80%' >
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="Twitter">
            <label style='margin-left: 10%'>Twitter</label>
            <input name="Twitter" type="url" class="form-control" style='margin-left: 10%; width: 80%' >
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="YouTube">
            <label style='margin-left: 10%'>YouTube</label>
            <input name="YouTube" type="url" class="form-control" style='margin-left: 10%; width: 80%' >
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="AirBnB">
            <label style='margin-left: 10%'>AirBnB</label>
            <input name="Airbnb" type="url" class="form-control" style='margin-left: 10%; width: 80%' >
        </div>
    </div>
</div>
<br>
<br>
<br>
<div class="row" >
    <div class="col-md-4">
        <div class="form-group" id="clave1">
            <label style='margin-left: 10%'>Contraseña</label>
            <input name="clave1" type="password" class="form-control" style='margin-left: 10%; width: 80%' required>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group" id="clave2">
            <label style='margin-left: 10%'>Confirmar Contraseña</label>
            <input name="clave2" type="password" class="form-control" style='margin-left: 10%; width: 80%' required >
            <?php
            $validador->ShowErrorClave2();
            ?>
        </div>
    </div>
</div>
<div class="panel-footer"  style="background-color: white;" >

    <button type="submit"  name="send" class="btn btn-default btn-primary" style=' margin-left: 2%; background-color: #540094;border-color: #540094; margin-top: 20px'>
        Registrarse
    </button>
    <br><a href="LoginEmpresa.php" style='margin-left: 2%;'>¿Ya tienes una cuenta? Inicia sesión</a>  
</div>
