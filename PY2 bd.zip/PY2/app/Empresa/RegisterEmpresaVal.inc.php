<?php

class RegisterEmpresaVal{
    
    private $CedJur;
    private $Correo;
    private $Clave;
    private $lat;
    
    private $ERROR_CedJur;
    private $ERROR_Correo;
    private $ERROR_Clave2;
    private $ERROR_Lat;
    
    

    public function __construct($CedJur, $Correo, $Clave1, $Clave2,$lat,$connection){
        $this->AvisoInicio = "<br><div class='alert alert-danger' role = 'alert'>";
        $this->AvisoFin = "</div>";
        $this->Cedjur = "";
        $this->Correo = "";
        $this->Clave=$Clave1;
        $this->lat = "";

        $this->ERROR_CedJur= $this->validarCedJur($connection,$CedJur);
        $this->ERROR_Correo = $this->validarCorreo($connection,$Correo);
        $this->ERROR_Clave2 = $this->validarClave2($Clave1, $Clave2);
        $this->ERROR_Lat= $this->validarUbicacion($lat);
    }
    
    private function variableIniciada($variable) {
        if (isset($variable) && !empty($variable)) {
            return true;
        } else {
            return false;
        }
    }
    
    private function validarCedJur($connection,$CedJur){
        
        if(EmpresaRepo:: CedJurExists($connection,$CedJur)){
            return "Esta cedula ya está en uso";
        }
        return "";
    }
    
        
    private function validarCorreo($connection,$Correo){
        
        if(EmpresaRepo:: EmailExists($connection,$Correo)){
            return "Este correo ya está en uso";
        }
        return "";
    }
  
    private function validarClave2($Clave1, $Clave2) {
        if ($Clave1 !== $Clave2) {
            return "Ambas contraseñas deben de ser iguales";
        }
        return "";
    }
    
    
    private function validarUbicacion($lat) {
        if (!$this->variableIniciada($lat)) {
            return "Debe ingresar la ubicación de la empresa";
        } else {
            $this->lat = $lat;
        }
        return "";
    }

    
    public function showCedJur() {
        if ($this->CedJur !== "") {
            echo 'value="' . $this->CedJur. '"';
        }
    }

    public function showCorreo() {
        if ($this->Correo !== "") {
            echo 'value="' . $this->Correo. '"';
        }
    }
    
    
    public function ShowErrorCedJur() {
        if ($this->ERROR_CedJur !== "") {
            echo $this->AvisoInicio . $this->ERROR_CedJur. $this->AvisoFin;
        }
    }
    
    public function ShowErrorCorreo() {
        if ($this->ERROR_Correo !== "") {
            echo $this->AvisoInicio . $this->ERROR_Correo. $this->AvisoFin;
        }
    }
    public function ShowErrorUbicacion() {
        if ($this->ERROR_Lat !== "") {
            echo $this->AvisoInicio . $this->ERROR_Lat. $this->AvisoFin;
        }
    }
    public function ShowErrorClave2() {
        if ($this->ERROR_Clave2 !== "") {
            echo $this->AvisoInicio . $this->ERROR_Clave2. $this->AvisoFin;
        }
    }
    
    
    public function validAccount() {
        if ($this->ERROR_CedJur === "" &&
                $this->ERROR_Correo === "" &&
                $this->ERROR_Clave2 === "" &&
                $this->ERROR_Lat === "") {
            return true;
        }else{
            return false;
        }
    }
    
}
