<?php

class ControlSesion {

    public static function StartSesion($ID, $UserName,$Email, $SessionType) {
        if (session_id() == '') {
            session_start();
        }

        
        $_SESSION['ID'] = $ID;
        $_SESSION['UserName'] = $UserName;
        $_SESSION['Email'] = $Email;
        $_SESSION['SessionType'] = $SessionType;
    }

    public static function CloseSesion() {
        if (session_id() == '') {
            session_start();
        }
        if(isset($_SESSION['ID'])){
            unset($_SESSION['ID']);
        }
        if(isset($_SESSION['Email'])){
            unset($_SESSION['Email']);
        }
        if(isset($_SESSION['UserName'])){
            unset($_SESSION['UserName']);
        }
        if(isset($_SESSION['SessionType'])){
            unset($_SESSION['SessionType']);
        }
        session_destroy();
    }

    public static function SesionStarted(){
        if (session_id() == '') {
            session_start();
        }
        if(isset($_SESSION['ID']) && isset($_SESSION['Email']) && isset($_SESSION['UserName']) && isset($_SESSION['SessionType'])){
            return true;
        }else{
            return false;
        }
    }
}
