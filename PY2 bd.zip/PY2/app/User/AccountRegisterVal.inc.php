<?php

class AccountValidator {

    private $AvisoInicio;
    private $AvisoFin;
    private $nombre;
    private $correo;
    private $nacimiento;
    private $telefono;
    private $clave;
    private $ERROR_Nombre;
    private $ERROR_Telefono;
    private $ERROR_Correo;
    private $ERROR_Clave1;
    private $ERROR_Clave2;

    public function __construct($nombre, $nacimiento, $telefono, $correo, $clave1, $clave2, $connection) {

        $this->AvisoInicio = "<br><div class='alert alert-danger' role = 'alert'>";
        $this->AvisoFin = "</div>";
        $this->nombre = "";
        $this->correo = "";
        $this->telefono = "";
        $this->nacimiento = $nacimiento;
        $this->clave = $clave1;

        $this->ERROR_Nombre = $this->validarNombre($connection, $nombre);
        $this->ERROR_Telefono = $this->validarTelefono($telefono);
        $this->ERROR_Correo = $this->validarCorreo($connection, $correo);
        $this->ERROR_Clave1 = $this->validarClave1($clave1);
        $this->ERROR_Clave2 = $this->validarClave2($clave1, $clave2);
    }

    /* public function __construct($client, $Nombre,$Apellido1, $Apellido2,$tipoId,$numId,$selectPais,$otroPais,$Provincia,$Canton,$Distrito){

      }


      $validador = new ClientValidator($client,$_POST['Nombre'],$_POST['Apellido1'], $_POST['Apellido2'], $_POST['tipoId'], $_POST['numId'],
      $_POST['selectPais'], $_POST['otroPais'], $_POST['Provincia'],$_POST['Canton'],$_POST['Distrito']);

     */

    private function variableIniciada($variable) {
        if (isset($variable) && !empty($variable)) {
            return true;
        } else {
            return false;
        }
    }

    private function validarNombre($connection, $nombre) {
        if (!$this->variableIniciada($nombre)) {
            return "Ingrese un nombre de usurio.";
        } else {
            $this->nombre = $nombre;
        }
        if (strlen($nombre) < 6) {
            return "El nombre debe tener mas de 6 caracteres";
        }
        if (strlen($nombre) > 24) {
            return "El nombre debe tener menos de 24 caracteres";
        }
        if (UserRepo:: UserExists($connection, $nombre)) {
            return "Este nombre de usuario ya está en uso";
        }

        return "";
    }

    private function validarTelefono($telefono) {
        if (!$this->variableIniciada($telefono)) {
            return "Ingrese un telefono";
        }
        if (is_numeric($telefono)) {
            if (strlen($telefono) < 8) {
                return "Ingrese un numero de telefono valido1";
            } else {
                $this->telefono = $telefono;
            }
        } else {
            return "Ingrese un numero de telefono valido";
        }
        return "";
    }

    private function validarCorreo($connection, $Correo) {
         if (!$this->variableIniciada($Correo)) {
            return "Ingrese una dirección de correo electronico.";
        } else {
            $this->correo = $Correo;
        }
        if (UserRepo:: EmailExists($connection, $Correo)) {
            return "Este correo ya está en uso";
        }
        return "";
    }

    private function validarClave1($clave1) {
        if (!$this->variableIniciada($clave1)) {
            return "Ingrese una clave";
        } else {
            $this->clave1 = $clave1;
        }
        return "";
    }

    private function validarClave2($clave1, $clave2) {
        if (!$this->variableIniciada($clave1)) {
            return "profavor ingrese una contraseña";
        }
        if (!$this->variableIniciada($clave2)) {
            return "confirme su contraseña";
        }
        if ($clave1 !== $clave2) {
            return "Ambas contraseñas deben de ser iguales";
        }
        return "";
    }

    public function showName() {
        if ($this->nombre !== "") {
            echo 'value="' . $this->nombre . '"';
        }
    }

    public function showTelefono() {
        if ($this->telefono !== "") {
            echo 'value="' . $this->telefono . '"';
        }
    }

    public function showCorreo() {
        if ($this->correo !== "") {
            echo 'value="' . $this->correo . '"';
        }
    }

    public function showFecha() {
        if ($this->nacimiento !== "") {
            echo 'value="' . $this->nacimiento . '"';
        }
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getNacimiento() {
        return $this->nacimiento;
    }

    public function getTelefono() {
        return $this->telefono;
    }

    public function getCorreo() {
        return $this->correo;
    }

    public function getClave() {
        return $this->clave;
    }

    public function getERROR_Nombre() {
        return $this->ERROR_Nombre;
    }

    public function getERROR_Correo() {
        return $this->ERROR_Correo;
    }

    public function getERROR_Telefono() {
        return $this->ERROR_Telefono;
    }

    public function getERROR_Clave1() {
        return $this->ERROR_Clave1;
    }

    public function getERROR_Clave2() {
        return $this->ERROR_Clave2;
    }

    public function ShowErrorNombre() {
        if ($this->ERROR_Nombre !== "") {
            echo $this->AvisoInicio . $this->ERROR_Nombre . $this->AvisoFin;
        }
    }

    public function ShowErrorTelefono() {
        if ($this->ERROR_Telefono !== "") {
            echo $this->AvisoInicio . $this->ERROR_Telefono . $this->AvisoFin;
        }
    }

    public function ShowErrorCorreo() {
        if ($this->ERROR_Correo !== "") {
            echo $this->AvisoInicio . $this->ERROR_Correo . $this->AvisoFin;
        }
    }

    public function ShowErrorClave1() {
        if ($this->ERROR_Clave1 !== "") {
            echo $this->AvisoInicio . $this->ERROR_Clave1 . $this->AvisoFin;
        }
    }

    public function ShowErrorClave2() {
        if ($this->ERROR_Clave2 !== "") {
            echo $this->AvisoInicio . $this->ERROR_Clave2 . $this->AvisoFin;
        }
    }

    public function validAccount() {
        if ($this->ERROR_Nombre === "" &&
                $this->ERROR_Telefono === "" &&
                $this->ERROR_Correo === "" &&
                $this->ERROR_Clave1 === "" &&
                $this->ERROR_Clave2 === "") {
            return true;
        } else {
            return false;
        }
    }

}
