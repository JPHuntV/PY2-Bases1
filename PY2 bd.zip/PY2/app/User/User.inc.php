<?php

class User {

    private $ID_Usuario;
    private $Nombre;
    private $Apellido1;
    private $Apellido2;
    private $FechaNacimento;
    private $TipoId;
    private $NumeroID;
    private $PaisResidencia;
    private $Telefono;
    private $Correo;
    private $Usuario;
    private $Clave;
    private $ID_Direccion;


    public function __construct($ID_Usuario,$Usuario, $FechaNacimento, $Telefono, $Correo, $Clave,$Nombre,$Apellido1,$Apellido2,
        $TipoId,$NumeroId,$PaisResidencia,$ID_Direccion) {
        $this->ID_Usuario=$ID_Usuario;
        $this->Usuario = $Usuario;
        $this->FechaNacimento = $FechaNacimento;
        $this->Telefono = $Telefono;
        $this->Correo = $Correo;
        $this->Clave = $Clave;
        $this->Nombre = $Nombre;
        $this->Apellido1 = $Apellido1;
        $this->Apellido2 = $Apellido2;
        $this->TipoId = $TipoId;
        $this->NumeroID = $NumeroId;
        $this->PaisResidencia = $PaisResidencia;
        $this->ID_Direccion = $ID_Direccion;
    
    }

    public function getID_Usuario() {
        return $this->ID_Usuario;
    }

    public function getNombre() {
        return $this->Nombre;
    }

    public function getApellido1() {
        return $this->Apellido1;
    }

    public function getApellido2() {
        return $this->Apellido2;
    }

    public function getFechaNacimento() {
        return $this->FechaNacimento;
    }

    public function getTipoId() {
        return $this->TipoId;
    }

    public function getNumeroID() {
        return $this->NumeroID;
    }

    public function getPaisResidencia() {
        return $this->PaisResidencia;
    }

    public function getID_Direccion() {
        return $this->ID_Direccion;
    }

    public function getTelefono() {
        return $this->Telefono;
    }

    public function getCorreo() {
        return $this->Correo;
    }

    public function getUsuario() {
        return $this->Usuario;
    }

    public function getClave() {
        return $this->Clave;
    }

    public function setNombre($Nombre) {
        $this->Nombre = $Nombre;
    }

    public function setApellido1($Apellido1) {
        $this->Apellido1 = $Apellido1;
    }

    public function setApellido2($Apellido2) {
        $this->Apellido2 = $Apellido2;
    }

    public function setFechaNacimento($FechaNacimento) {
        $this->FechaNacimento = $FechaNacimento;
    }

    public function setTipoId($TipoId) {
        $this->TipoId = $TipoId;
    }

    public function setNumeroID($NumeroID) {
        $this->NumeroID = $NumeroID;
    }

    public function setPaisResidencia($PaisResidencia) {
        $this->PaisResidencia = $PaisResidencia;
    }

    public function setID_Direccion($ID_Direccion) {
        $this->ID_Direccion = $ID_Direccion;
    }

    public function setTelefono($Telefono) {
        $this->Telefono = $Telefono;
    }

    public function setCorreo($Correo) {
        $this->Correo = $Correo;
    }

    public function setUsuario($Usuario) {
        $this->Usuario = $Usuario;
    }

    public function setClave($Clave) {
        $this->Clave = $Clave;
    }



}
