<?php

include_once 'Actividad.inc.php';
include_once '../../app/Direccion/Direccion.inc.php';
class ActividadRepo {

    public static function InsertActividad($connection, $Actividad, $Direccion) {
        $inserted = null;
        if (isset($connection)) {
            try {
                $sql = "call InsertActividad(:Provincia,:Canton,:Distrito,:Senias,:Empresa,:Correo,:Telefono,:Contacto"
                        . ",:Descripcion,:Precio)";

                $EmpresaT = $Actividad->getEmpresa();
                $CorreoT = $Actividad->getCorreo();
                $TelefonoT = $Actividad->getTelefono();
                $ContactoT = $Actividad->getContacto();
                $DescripcionT = $Actividad->getDescripcion();
                $PrecioT = $Actividad->getPrecio();
                
                $ProvinciaT = $Direccion->getProvincia();
                $CantonT = $Direccion->getCanton();
                $DistritoT = $Direccion->getDistrito();
                $BarrioT = $Direccion->getBarrio();
                $SeniasT = $Direccion->getSenias();

                $statement = $connection->prepare($sql);
                $statement->bindParam(':Empresa', $EmpresaT, PDO::PARAM_STR);
                $statement->bindParam(':Correo', $CorreoT, PDO::PARAM_STR);
                $statement->bindParam(':Telefono', $TelefonoT, PDO::PARAM_STR);
                //$statement->bindParam(':ID_Direccion', $ID_Dir[0], PDO::PARAM_STR);
                $statement->bindParam(':Contacto', $ContactoT, PDO::PARAM_STR);
                $statement->bindParam(':Descripcion', $DescripcionT, PDO::PARAM_STR);
                $statement->bindParam(':Precio', $PrecioT, PDO::PARAM_STR);
                
                $statement->bindParam(':Provincia', $ProvinciaT, PDO::PARAM_STR);
                $statement->bindParam(':Canton', $CantonT, PDO::PARAM_STR);
                $statement->bindParam(':Distrito', $DistritoT, PDO::PARAM_STR);
                $statement->bindParam(':Senias', $SeniasT, PDO::PARAM_STR);
                $statement->execute();
                $inserted = $statement->fetchAll();
                
                
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $inserted;
    }
    public static function InsertActividadTipo($connection, $ID, $Tipo) {
        $inserted = false;
        if (isset($connection)) {
            try {
                $sql = "call InsertActividadTipo(:ID,:Tipo)";

                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID', $ID, PDO::PARAM_STR);
                $statement->bindParam(':Tipo', $Tipo, PDO::PARAM_STR);
               $result =  $statement->execute();
             
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $inserted;
    }
    public static function InsertContrato($connection, $Contrato) {
        $inserted = false;
        if (isset($connection)) {
            try {
                $sql = "call InsertContrato(:ID_Actividad, :Nombre, :Telefono ,:Correo, :Tarjeta, :Fecha)";

                $ID_Actividad = $Contrato->getID_Actividad();
                $Nombre = $Contrato->getNombre();
                $Correo = $Contrato->getCorreo();
                $Telefono = $Contrato->getTelefono();
                $Tarejta = $Contrato->getTarjeta();
                $Fecha = $Contrato->getFecha();
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Actividad', $ID_Actividad, PDO::PARAM_STR);
                $statement->bindParam(':Nombre', $Nombre, PDO::PARAM_STR);
                $statement->bindParam(':Telefono', $Telefono, PDO::PARAM_STR);
                $statement->bindParam(':Correo', $Correo, PDO::PARAM_STR);
                $statement->bindParam(':Tarjeta', $Tarejta, PDO::PARAM_STR);
                $statement->bindParam(':Fecha', $Fecha, PDO::PARAM_STR);
                
               $inserted =  $statement->execute();
             
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $inserted;
    }
    
    public static function getActividades($connection) {
        $Actividades = [];
        if (isset($connection)) {
            try {
                if (isset($_SESSION['SessionType']) && $_SESSION['SessionType'] == 0) {
                    $sql = "call getActividadesE(:ID_Hospedaje)";
                    $statement = $connection->prepare($sql);
                    $statement->bindParam(':ID_Hospedaje', $_SESSION['ID'], PDO::PARAM_STR);
                } else {
                    $sql = "call getActividadesByRandom()";
                    $statement = $connection->prepare($sql);
                }
                $statement->execute();
                $result = $statement->fetchAll();
                if (count($result)) {
                    foreach ($result as $valor) {
                        
                        $Actividades[] = new Actividad($valor['ID_Actividad'], $valor['Empresa'], $valor['Correo'], $valor['telefono'],
                                $valor['Contacto'],$valor['ID_Direccion'],$valor['Descripcion'],$valor['Precio']);
                    }
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $Actividades;
    }
    
    
    
    public static function getActividadesByFilter($connection, $lugar, $Tipo) {
        $Actividades = [];
        if (!isset($lugar)) {
            $lugar = '';
        }
        if ($Tipo=="Todos") {
            $Tipo = '';
        }
        if (isset($connection)) {
            try {
                if (isset($_SESSION['SessionType']) && $_SESSION['SessionType'] == 0) {
                    $sql = "call getActividadesE(:ID_Hospedaje)";
                    $statement = $connection->prepare($sql);
                    $statement->bindParam(':ID_Hospedaje', $_SESSION['ID'], PDO::PARAM_STR);
                } else {
                    $sql = "call getActividadesByFilter(:lugar,:tipo)";
                    $statement = $connection->prepare($sql);
                    $statement->bindParam(':lugar', $lugar, PDO::PARAM_STR);
                    $statement->bindParam(':tipo', $Tipo, PDO::PARAM_STR);
                }
                $statement->execute();
                $result = $statement->fetchAll();
                if (count($result)) {
                    echo "<div class='alert alert-success' role='alert' style='text-align: center'> ¡Estos son los resultados de tu busqueda! </div>";
                    foreach ($result as $valor) {
                        
                        $Actividades[] = new Actividad($valor['ID_Actividad'], $valor['Empresa'], $valor['Correo'], $valor['telefono'],
                                $valor['Contacto'],$valor['ID_Direccion'],$valor['Descripcion'],$valor['Precio']);
                    }
                } else {
                    Connection::closeConnection();
                    Connection::openConnection();
                    echo "<div class='alert alert-info' role='alert' style='text-align: center'> ¡Vaya! parece que no hay resultados para tu busqueda </div>";
                    $Actividades = ActividadRepo::getActividades(Connection::getConnection());
                    Connection::closeConnection();
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $Actividades;
    }


    
    
    
    public static function getTipos($connection, $ID) {
        $tipos = [];
        $result = null;
        if (isset($connection)) {
            try {
                    $sql = "call getTiposByActividad($ID)";
                    $statement = $connection->prepare($sql);
                    $statement->execute();
                    $result = $statement->fetchAll();
                    foreach ($result as $valor){
                        $tipos[]=$valor;
                    }
                
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $tipos;
    }
    
    
    public static function getActividadByID($connection, $ID) {
        $Actividad = null;
        if (isset($connection)) {
            try {
                $sql = "call getActividadByID(:ID)";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID', $ID, PDO::PARAM_STR);
                $statement->execute();
                $valor = $statement->fetch();
                if (!empty($valor)) {
                    $Actividad = new Actividad($valor['ID_Actividad'], $valor['Empresa'], $valor['Correo'], $valor['telefono'],
                                $valor['Contacto'],$valor['ID_Direccion'],$valor['Descripcion'],$valor['Precio']);
                    } else {
                    echo 'esto no deberia de pasar';
                }
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $Actividad;
    }
    
    
    public static function UpdateActividadByID($connection, $Actividad, $Direccion) {
        $inserted = null;
        if (isset($connection)) {
            try {
                $sql = "call UpdateDireccionByID(:ID_Direccion,:Provincia,:Canton,:Distrito,:Senias)";

               
                $ID_Direccion = $Actividad->getID_Direccion();
                $ProvinciaT = $Direccion->getProvincia();
                $CantonT = $Direccion->getCanton();
                $DistritoT = $Direccion->getDistrito();
                $SeniasT = $Direccion->getSenias();

                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Direccion', $ID_Direccion, PDO::PARAM_STR);               
                $statement->bindParam(':Provincia', $ProvinciaT, PDO::PARAM_STR);
                $statement->bindParam(':Canton', $CantonT, PDO::PARAM_STR);
                $statement->bindParam(':Distrito', $DistritoT, PDO::PARAM_STR);
                $statement->bindParam(':Senias', $SeniasT, PDO::PARAM_STR);
                $statement->execute();
                
                
                $sql = "call UpdateActividadByID(:ID_Actividad,:Empresa,:Correo,:Telefono,:Contacto ,:Descripcion,:Precio)";
                $ID_Actividad = $Actividad->getID_Actividad();
                $EmpresaT = $Actividad->getEmpresa();
                $CorreoT = $Actividad->getCorreo();
                $TelefonoT = $Actividad->getTelefono();
                $ContactoT = $Actividad->getContacto();
                $DescripcionT = $Actividad->getDescripcion();
                $PrecioT = $Actividad->getPrecio();
                    
                
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Actividad', $ID_Actividad, PDO::PARAM_STR);
                $statement->bindParam(':Empresa', $EmpresaT, PDO::PARAM_STR);
                $statement->bindParam(':Correo', $CorreoT, PDO::PARAM_STR);
                $statement->bindParam(':Telefono', $TelefonoT, PDO::PARAM_STR);
                $statement->bindParam(':Contacto', $ContactoT, PDO::PARAM_STR);
                $statement->bindParam(':Descripcion', $DescripcionT, PDO::PARAM_STR);
                $statement->bindParam(':Precio', $PrecioT, PDO::PARAM_STR);
                
                $inserted = $statement->execute();
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $inserted;
    }
    
    
     public static function DeleteActividadTipoByID($connection, $ID) {
        $Deleted = false;
        if (isset($connection)) {
            try {
                $sql = "call DeleteActividadTipoByID(:ID)";

                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID', $ID, PDO::PARAM_STR);
               $Deleted  =  $statement->execute();
             
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $Deleted ;
    }
}


                