<?php 
class Contrato{
    private $ID_Contrato;
    private $ID_Actividad;
    private $Nombre;
    private $Correo;
    private $Telefono;
    private $Tarjeta;
    private $Fecha;
    
    public function __construct($ID_Contrato, $ID_Actividad, $Nombre, $Correo, $Telefono, $Tarjeta, $Fecha) {
        $this->ID_Contrato = $ID_Contrato;
        $this->ID_Actividad = $ID_Actividad;
        $this->Nombre = $Nombre;
        $this->Correo = $Correo;
        $this->Telefono = $Telefono;
        $this->Tarjeta = $Tarjeta;
        $this->Fecha = $Fecha;
    }
    
    public function getID_Contrato() {
        return $this->ID_Contrato;
    }

    public function getID_Actividad() {
        return $this->ID_Actividad;
    }

    public function getNombre() {
        return $this->Nombre;
    }

    public function getCorreo() {
        return $this->Correo;
    }

    public function getTelefono() {
        return $this->Telefono;
    }

    public function getTarjeta() {
        return $this->Tarjeta;
    }

    public function getFecha() {
        return $this->Fecha;
    }



    
}
