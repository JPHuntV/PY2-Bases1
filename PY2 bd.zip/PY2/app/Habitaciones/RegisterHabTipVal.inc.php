<?php

include_once 'HabitacionRepo.inc.php';

class RegisterHabTipVal {

    private $AvisoInicio;
    private $AvisoFin;
    private $Nombre;
    private $Miniatura;
    private $ERROR_Nombre;
    private $ERROR_Miniatura;

    public function __construct($nombre, $Minuatura, $connection) {

        $this->AvisoInicio = "<br><div class='alert alert-danger' role = 'alert'>";
        $this->AvisoFin = "</div>";
        $this->Nombre = "";
        $this->Miniatura = "";

        $this->ERROR_Nombre = $this->validarNombre($connection, $nombre);
        $this->ERROR_Miniatura = $this->validarMiniatura($connection, $Minuatura);
    }

    private function variableIniciada($variable) {
        if (isset($variable) && !empty($variable)) {
            return true;
        } else {
            return false;
        }
    }

    private function validarNombre($connection, $nombre) {
        /* if (!$this->variableIniciada($nombre)) {
          return "Ingrese un nombre de usurio.";
          } else {
          $this->nombre = $nombre;
          }
          if (strlen($nombre) < 6) {
          return "El nombre debe tener mas de 6 caracteres";
          }
          if (strlen($nombre) > 24) {
          return "El nombre debe tener menos de 24 caracteres";
          } */
        if (HabitacionRepo:: TipoExists($connection, $nombre)) {
            return "Este tipo ya existe";
        }

        return "";
    }

    private function validarMiniatura($connection, $Miniatura) {
        if (!$this->variableIniciada($Miniatura)) {
            return "Ingrese una miniatura";
        } else {
            $this->nombre = $Miniatura;
        }
        /* if (strlen($nombre) < 6) {
          return "El nombre debe tener mas de 6 caracteres";
          }
          if (strlen($nombre) > 24) {
          return "El nombre debe tener menos de 24 caracteres";
          } */
        return "";
    }

    public function showName() {
        if ($this->Nombre !== "") {
            echo 'value="' . $this->Nombre . '"';
        }
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getERROR_Nombre() {
        return $this->ERROR_Nombre;
    }

    public function ShowErrorNombre() {
        if ($this->ERROR_Nombre !== "") {
            echo $this->AvisoInicio . $this->ERROR_Nombre . $this->AvisoFin;
        }
    }

    public function ShowErrorMiniatura() {
        if ($this->ERROR_Miniatura !== "") {
            echo $this->AvisoInicio . $this->ERROR_Miniatura . $this->AvisoFin;
        }
    }

    public function validAccount() {
        if ($this->ERROR_Nombre === "" && $this->ERROR_Miniatura === "") {
            return true;
        } else {
            return false;
        }
    }

}
