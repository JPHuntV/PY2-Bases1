<?php

class ClientRepo {

    public static function InsertClient($connection, $ID_Usuario, $ID_Empresa) {
        if (isset($connection)) {
            try {
                $sql = "call InsertCliente(:ID_Usuario,:ID_Empresa)";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Usuario', $ID_Usuario, PDO::PARAM_STR);
                $statement->bindParam(':ID_Empresa', $ID_Empresa, PDO::PARAM_STR);
                $statement->execute();

                $sql = "call getCliente(:ID_Usuario,:ID_Empresa)";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Usuario', $ID_Usuario, PDO::PARAM_STR);
                $statement->bindParam(':ID_Empresa', $ID_Empresa, PDO::PARAM_STR);
                $statement->execute();
                $result = $statement->fetchAll();
                return $result;
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
    }

    public static function getCliente($connection, $ID_Usuario, $ID_Empresa) {
        if (isset($connection)) {
            try {
                $sql = "call getCliente(:ID_Usuario,:ID_Empresa)";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Usuario', $ID_Usuario, PDO::PARAM_STR);
                $statement->bindParam(':ID_Empresa', $ID_Empresa, PDO::PARAM_STR);
                $statement->execute();
                $result = $statement->fetchAll();
                return $result;
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
    }

}
