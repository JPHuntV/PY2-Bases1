<?
echo 'in';
include_once 'Connection.inc.php';
Connection::openConnection();
$connection =Connection::getConnection();

$location = $_GET['term'];

$sql = "Call getLocations(:location)";
$statement = $connection->prepare($sql);
$statement->bindParam(':location', $location, PDO::PARAM_STR);
$result = $statement->execute();
$locationValues = array();
if($sql->num_rows > 0){ 
    while($row = $result->fetch_assoc()){ 
        $data['Provincia'] = $row['Provincia']; 
        $data['Canton'] = $row['Canton']; 
        $data['Distrito'] = $row['Distrito'];
        array_push($locationValues, $data); 
    } 
} 
echo 'aqui';
echo json_encode($locationValues);           
Connection::closeConnection();
?> 