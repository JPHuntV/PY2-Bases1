<?php
define('SERVER_NAME','localhost');
define('USER_NAME','root');
define('PASSWORD','sds6qKG0hcYXckzE');
define('DATA_BASE','gestionhotelera');

//sds6qKG0hcYXckzE