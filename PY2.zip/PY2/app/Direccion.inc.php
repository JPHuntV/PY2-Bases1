<?php

class Direccion{
    
    private $Provincia;
    private $Canton;
    private $Distrito;
    private $Barrio;
    private $Senias;
    
    public function __construct($Provincia, $Canton, $Distrito,$Barrio,$Senias) {
        $this->Provincia = $Provincia;
        $this->Canton = $Canton;
        $this->Distrito = $Distrito;
        $this->Barrio = $Barrio;
        $this->Senias = $Senias;
    }
    
    public function getProvincia() {
        return $this->Provincia;
    }

    public function getCanton() {
        return $this->Canton;
    }

    public function getDistrito() {
        return $this->Distrito;
    }

    public function getBarrio() {
        return $this->Barrio;
    }

    public function getSenias() {
        return $this->Senias;
    }

    public function setProvincia($Provincia) {
        $this->Provincia = $Provincia;
    }

    public function setCanton($Canton) {
        $this->Canton = $Canton;
    }

    public function setDistrito($Distrito) {
        $this->Distrito = $Distrito;
    }

    public function setBarrio($Barrio) {
        $this->Barrio = $Barrio;
    }

    public function setSenias($Senias) {
        $this->Senias = $Senias;
    }



}


