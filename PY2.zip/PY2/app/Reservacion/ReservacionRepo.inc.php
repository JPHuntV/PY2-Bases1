<?php

include_once 'Reservacion.inc.php'; //

class ReservacionRepo {

    public static function InsertReservacion($connection, $Reservacion) {
        $inserted = false;
        if (isset($connection)) {
            try {
                $sql = "call InsertReservacion(:ID_Cliente, :ID_Habitacion, :IdentificacionCliente, :cantPersonas,"
                        . " :hasCar,:fechaIngreso, :fechaSalida)";

                $ID_ClienteT = $Reservacion->getID_Cliente();
                $ID_HabitacionT = $Reservacion->getID_Habitacion();
                $IdentificacionclienteT = $Reservacion->getIdentificacionCliente();
                $cantPersonasT = $Reservacion->getCantPersonas();
                $hasCarT = $Reservacion->getHasCar();
                $fechaIngresoT = $Reservacion->getFechaIngreso();
                $fechaSalidaT = $Reservacion->getFechaSalida();
                echo $fechaIngresoT;
                echo $fechaSalidaTT;
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Cliente', $ID_ClienteT, PDO::PARAM_STR);
                $statement->bindParam(':ID_Habitacion', $ID_HabitacionT, PDO::PARAM_STR);
                $statement->bindParam(':IdentificacionCliente', $IdentificacionclienteT, PDO::PARAM_STR);
                $statement->bindParam(':cantPersonas', $cantPersonasT, PDO::PARAM_STR);
                $statement->bindParam(':hasCar', $hasCarT, PDO::PARAM_STR);
                $statement->bindParam(':fechaIngreso', $fechaIngresoT, PDO::PARAM_STR);
                $statement->bindParam(':fechaSalida', $fechaSalidaT, PDO::PARAM_STR);

                $inserted = $statement->execute();
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $inserted;
    }

    public static function getReservaciones($connection) {
        $reservaciones = [];
        if (isset($connection)) {
            try {
                if (isset($_SESSION['SessionType']) && $_SESSION['SessionType'] == 0) {
                    $sql = "call getReservacionesE(:ID_Hospedaje)";
                    $statement = $connection->prepare($sql);
                    $statement->bindParam(':ID_Hospedaje', $_SESSION['ID'], PDO::PARAM_STR);
                } else {
                    $sql = "call getResevaciones()";
                    $statement = $connection->prepare($sql);
                }
                $statement->execute();
                $result = $statement->fetchAll();
                if (count($result)) {
                    foreach ($result as $valor) {

                        $reservaciones[] = new Reservacion($valor['ID_Reserva'], $valor['ID_Cliente'], $valor['ID_Habitacion'], $valor['IdentificacionCliente'], $valor['CantidadPersonas'], $valor['hasCar'], $valor['FechaHoraIngreso'], $valor['FechaHoraSalida']);
                    }
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $reservaciones;
    }

    public static function getReservacionByID($connection, $Number) {
        $reservaciones = [];
        if (isset($connection)) {
            try {
                if (isset($_SESSION['SessionType']) && $_SESSION['SessionType'] == 0) {
                    $sql = "call getReservacionByID(:ID,:Empresa)";
                    $statement = $connection->prepare($sql);
                    $statement->bindParam(':ID', $Number, PDO::PARAM_STR);
                    $statement->bindParam(':Empresa', $_SESSION['ID'], PDO::PARAM_STR);
                } else {
                    $sql = "call getReservacionByID(:Empresa)";
                    $statement = $connection->prepare($sql);
                }
                $statement->execute();
                $result = $statement->fetchAll();
                if (count($result)) {
                    echo "<div class='alert alert-success' role='alert' style='text-align: center'> ¡Estos son los resultados de tu busqueda! </div>";
                    foreach ($result as $valor) {

                        $reservaciones[] = new Reservacion($valor['ID_Reserva'], $valor['ID_Cliente'], $valor['ID_Habitacion'], $valor['IdentificacionCliente'], $valor['CantidadPersonas'], $valor['hasCar'], $valor['FechaHoraIngreso'], $valor['FechaHoraSalida']);
                    }
                } else {

                    Connection::closeConnection();
                    Connection::openConnection();
                    echo "<div class='alert alert-info' role='alert' style='text-align: center'> ¡Vaya! parece que no hay resultados para tu busqueda </div>";
                    $reservaciones = ReservacionRepo::getReservaciones(Connection::getConnection());
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $reservaciones;
    }

}
