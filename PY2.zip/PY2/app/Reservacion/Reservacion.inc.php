<?php

class Reservacion {
    private $ID_Reservacion;
    private $ID_Cliente;
    private $ID_Habitacion;
    private $IdentificacionCliente;
    private $cantPersonas;
    private $hasCar;
    private $fechaIngreso;
    private $fechaSalida;

    public function __construct($ID_Reservacion, $ID_Cliente, $ID_Habitacion, $IdentificacionCliente, $cantPersonas, $hasCar, $fechaIngreso, $fechaSalida) {
        $this->ID_Reservacion = $ID_Reservacion;
        $this->ID_Cliente = $ID_Cliente;
        $this->ID_Habitacion = $ID_Habitacion;
        $this->IdentificacionCliente = $IdentificacionCliente;
        $this->cantPersonas = $cantPersonas;
        $this->hasCar = $hasCar;
        $this->fechaIngreso = $fechaIngreso;
        $this->fechaSalida = $fechaSalida;
    }
    public function getID_Reservacion() {
        return $this->ID_Reservacion;
    }

        public function getID_Cliente() {
        return $this->ID_Cliente;
    }

    public function getID_Habitacion() {
        return $this->ID_Habitacion;
    }

    public function getIdentificacionCliente() {
        return $this->IdentificacionCliente;
    }

    public function getCantPersonas() {
        return $this->cantPersonas;
    }

    public function getHasCar() {
        return $this->hasCar;
    }

    public function getFechaIngreso() {
        return $this->fechaIngreso;
    }

    public function getFechaSalida() {
        return $this->fechaSalida;
    }



}
