<?php

include_once 'UserRepo.inc.php';

class LoginUserVal{
    
    private $User;
    private $Error;
    
    public function __construct($Correo, $Clave, $connection){
        $this->Error="";
        if(!$this->variableIniciada($Correo) || !$this->variableIniciada($Clave) ){
            $this->User=null;
            $this->Error = "Porfavor Ingrese su correo y contraseña";
        }else{
            
            $this -> User = UserRepo::getUserByEmail($connection,$Correo);
            
            if(is_null($this->User)|| !password_verify($Clave, $this->User->getClave())){
                $this->Error = "Los datos ingresados son incorrectos";
            }
        }
    }
    
     private function variableIniciada($variable) {
        if (isset($variable) && !empty($variable)) {
            return true;
        } else {
            return false;
        }
    }
    
    public function getUser() {
        return $this->User;
    }

    public function getError() {
        return $this->Error;
    }

    

    public function showError(){
        if($this->Error !== ''){
            echo "<br><div class = 'alert alert-danger' role ='alert'>";
            echo $this->Error;
            echo "</div><br>";
        }
    }
}
