<?php

class ClientValidator {

    private $AvisoInicio;
    private $AvisoFin;
    private $client;
    private $ID;
    private $Nombre;
    private $Apellido1;
    private $Apellido2;
    private $tipoId;
    private $numId;
    private $PaisResidencia;
    private $Provincia;
    private $Canton;
    private $Distrito;
    private $ERROR_Nombre;
    private $ERROR_AP1;
    private $ERROR_AP2;
    private $ERROR_numId;
    private $ERROR_extranjero;
    private $ERROR_Provincia;
    private $ERROR_Canton;
    private $ERROR_Distrito;

    public function __construct($ID, $Nombre, $Apellido1, $Apellido2, $tipoId, $numId, $selectPais, $otroPais, $Provincia, $Canton, $Distrito) {
        $this->AvisoInicio = "<br><div class='alert alert-danger' role = 'alert'>";
        $this->AvisoFin = "</div>";
        if (!$ID === "x") {
            $this->ID = $ID;
        }
        $this->Nombre = "";
        $this->Apellido1 = "";
        $this->Apellido2 = "";
        $this->tipoId = $tipoId;
        $this->numId = "";
        if ($selectPais === "cr") {
            $this->PaisResidencia = "Costa Rica";
            $this->Provicia = "";
            $this->Canton = "";
            $this->Distrito = "";
            $this->ERROR_Provincia = $this->validarProvincia($Provincia);
            $this->ERROR_Canton = $this->validarCanton($Canton);
            $this->ERROR_Distrito = $this->validarDistrito($Distrito);
        } else {
            $this->PaisResidencia = "";
            $this->ERROR_extranjero = $this->validarPais($otroPais);
        }


        $this->ERROR_Nombre = $this->validarNombre($Nombre);
        $this->ERROR_AP1 = $this->validarAP1($Apellido1);
        $this->ERROR_AP2 = $this->validarAP2($Apellido2);
        $this->ERROR_numId = $this->validarNumId($numId);
    }

    private function variableIniciada($variable) {
        if (isset($variable) && !empty($variable)) {
            return true;
        } else {
            return false;
        }
    }

    private function validarNombre($Nombre) {
        if (!$this->variableIniciada($Nombre)) {
            return "Ingrese su nombre";
        } else {
            $this->Nombre = $Nombre;
        }

        return "";
    }

    private function validarAP1($Ap1) {
        if (!$this->variableIniciada($Ap1)) {
            return "Ingrese el primer apellido";
        } else {
            $this->Apellido1 = $Ap1;
        }

        return "";
    }

    private function validarAP2($Ap2) {
        if (!$this->variableIniciada($Ap2)) {
            return "Ingrese el segundo apellido";
        } else {
            $this->Apellido2 = $Ap2;
        }

        return "";
    }

    private function validarNumId($numId) {
        if (!$this->variableIniciada($numId)) {
            return "Ingrese su numero de identificación";
        }
        if (is_numeric($numId)) {
            if (strlen($numId) < 8) {
                return "Ingrese un numero de identificación valido";
            } else {
                $this->numId = $numId;
            }
        } else {
            return "Ingrese un numero de identificación valido";
        }
        return "";
    }

    private function validarPais($Pais) {
        if (!$this->variableIniciada($Pais)) {
            return "Ingrese el nombre del pais";
        } else {
            $this->PaisResidencia = $Pais;
        }

        return "";
    }

    private function validarProvincia($Provincia) {
        if (!$this->variableIniciada($Provincia)) {
            return "Ingrese el nombre de la provincia";
        } else {
            $this->Provincia = $Provincia;
        }

        return "";
    }

    private function validarCanton($Canton) {
        if (!$this->variableIniciada($Canton)) {
            return "Ingrese el nombre del cantón";
        } else {
            $this->Canton = $Canton;
        }

        return "";
    }

    private function validarDistrito($Distrito) {
        if (!$this->variableIniciada($Distrito)) {
            return "Ingrese el nombre del distrito";
        } else {
            $this->Distrito = $Distrito;
        }

        return "";
    }

    public function showName() {
        if ($this->Nombre !== "") {
            echo 'value="' . $this->Nombre . '"';
        }
    }

    public function showApellido1() {
        if ($this->Apellido1 !== "") {
            echo 'value="' . $this->Apellido1 . '"';
        }
    }

    public function showApellido2() {
        if ($this->Apellido2 !== "") {
            echo 'value="' . $this->Apellido2 . '"';
        }
    }

    public function showNumId() {
        if ($this->numId !== "") {
            echo 'value="' . $this->numId . '"';
        }
    }

    public function showPais() {
        if ($this->PaisResidencia !== "") {
            echo 'value="' . $this->PaisResidencia . '"';
        }
    }

    public function showProvincia() {
        if ($this->Provincia !== "") {
            echo 'value="' . $this->Provincia . '"';
        }
    }

    public function showCanton() {
        if ($this->Canton !== "") {
            echo 'value="' . $this->Canton . '"';
        }
    }

    public function showDistrito() {
        if ($this->Distrito !== "") {
            echo 'value="' . $this->Distrito . '"';
        }
    }

    public function getID() {
        return $this->ID;
    }

    public function getNombre() {
        return $this->Nombre;
    }

    public function getApellido1() {
        return $this->Apellido1;
    }

    public function getApellido2() {
        return $this->Apellido2;
    }

    public function getTipoId() {
        return $this->tipoId;
    }

    public function getNumId() {
        return $this->numId;
    }

    public function getPaisResidencia() {
        return $this->PaisResidencia;
    }

    public function getProvincia() {
        return $this->Provincia;
    }

    public function getCanton() {
        return $this->Canton;
    }

    public function getDistrito() {
        return $this->Distrito;
    }

    public function getERROR_Nombre() {
        return $this->ERROR_Nombre;
    }

    public function getERROR_AP1() {
        return $this->ERROR_AP1;
    }

    public function getERROR_AP2() {
        return $this->ERROR_AP2;
    }

    public function getERROR_numId() {
        return $this->ERROR_numId;
    }

    public function getERROR_extranjero() {
        return $this->ERROR_extranjero;
    }

    public function getERROR_Provincia() {
        return $this->ERROR_Provincia;
    }

    public function getERROR_Canton() {
        return $this->ERROR_Canton;
    }

    public function getERROR_Distrito() {
        return $this->ERROR_Distrito;
    }

    public function ShowErrorNombre() {
        if ($this->ERROR_Nombre !== "") {
            echo $this->AvisoInicio . $this->ERROR_Nombre . $this->AvisoFin;
        }
    }

    public function ShowErrorAP1() {
        if ($this->ERROR_AP1 !== "") {
            echo $this->AvisoInicio . $this->ERROR_AP1 . $this->AvisoFin;
        }
    }

    public function ShowErrorAP2() {
        if ($this->ERROR_AP2 !== "") {
            echo $this->AvisoInicio . $this->ERROR_AP2 . $this->AvisoFin;
        }
    }

    public function ShowErrorNumId() {
        if ($this->ERROR_numId !== "") {
            echo $this->AvisoInicio . $this->ERROR_numId . $this->AvisoFin;
        }
    }

    public function ShowErrorPais() {
        if ($this->ERROR_extranjero !== "") {
            echo $this->AvisoInicio . $this->ERROR_extranjero . $this->AvisoFin;
        }
    }

    public function ShowErrorProvincia() {
        if ($this->ERROR_Provincia !== "") {
            echo $this->AvisoInicio . $this->ERROR_Provincia . $this->AvisoFin;
        }
    }

    public function ShowErrorCanton() {
        if ($this->ERROR_Canton !== "") {
            echo $this->AvisoInicio . $this->ERROR_Canton . $this->AvisoFin;
        }
    }

    public function ShowErrorDistrito() {
        if ($this->ERROR_Distrito !== "") {
            echo $this->AvisoInicio . $this->ERROR_Distrito . $this->AvisoFin;
        }
    }

    public function validAccount() {
        if ($this->ERROR_Nombre === "" &&
                $this->ERROR_AP1 === "" &&
                $this->ERROR_AP2 === "" &&
                $this->ERROR_numId === "" &&
                $this->ERROR_extranjero === "" &&
                $this->ERROR_Provincia === "" &&
                $this->ERROR_Canton === "" &&
                $this->ERROR_Distrito === "") {
            return true;
        } else {
            return false;
        }
    }

}
