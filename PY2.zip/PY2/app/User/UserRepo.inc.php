<?php

include_once 'User.inc.php';
include_once '../../app/Direccion/Direccion.inc.php';

class UserRepo {

    public static function InsertUser($connection, $User, $direccion) {
        $inserted = false;

        if (isset($connection)) {
            try {
                $sql = "insert into direcciones(Provincia,Canton,Distrito)"
                        . "values(:Provincia,:Canton,:Distrito)";
                if ($direccion !== "x") {
                    $ProvinciaT = $direccion->getProvincia();
                    $CantonT = $direccion->getCanton();
                    $DistritoT = $direccion->getDistrito();

                    $statement = $connection->prepare($sql);
                    $statement->bindParam(':Provincia', $ProvinciaT, PDO::PARAM_STR);
                    $statement->bindParam(':Canton', $CantonT, PDO::PARAM_STR);
                    $statement->bindParam(':Distrito', $DistritoT, PDO::PARAM_STR);
                    $statement->execute();

                    $sql = "SELECT ID_Direccion FROM direcciones ORDER BY ID_Direccion DESC LIMIT 1";
                    $statement = $connection->prepare($sql);
                    $statement->execute();
                    $ID_Dir = $statement->fetch();
                }
                $sql = "insert into usuario(Nombre,Apellido1,Apellido2,FechaNacimiento,TipoId,NumeroId,PaisResidencia,ID_Direccion,telefono,Correo,Usuario,clave)"
                        . "values(:Nombre,:Apellido1,:Apellido2,:FechaNacimiento,:TipoId,:NumeroId,:PaisResidencia,:ID_Direccion,:telefono,:Correo,:Usuario,:clave)";

                $NombreT = $User->getNombre();
                $Apellido1T = $User->getApellido1();
                $Apellido2T = $User->getApellido2();
                $FechaT = $User->getFechaNacimento();
                $TipoIdT = $User->getTipoId();
                $NumeroIDT = $User->getNumeroId();
                $PaisResidenciaT = $User->getPaisResidencia();
                $TelefonoT = $User->getTelefono();
                $CorreoT = $User->getCorreo();
                $UserT = $User->getUsuario();
                $ClaveT = $User->getClave();


                $statement = $connection->prepare($sql);
                $statement->bindParam(':Nombre', $NombreT, PDO::PARAM_STR);
                $statement->bindParam(':Apellido1', $Apellido1T, PDO::PARAM_STR);
                $statement->bindParam(':Apellido2', $Apellido2T, PDO::PARAM_STR);
                $statement->bindParam(':FechaNacimiento', $FechaT, PDO::PARAM_STR);
                $statement->bindParam(':TipoId', $TipoIdT, PDO::PARAM_STR);
                $statement->bindParam(':NumeroId', $NumeroIDT, PDO::PARAM_STR);
                $statement->bindParam(':PaisResidencia', $PaisResidenciaT, PDO::PARAM_STR);
                $statement->bindParam(':ID_Direccion', $ID_Dir[0], PDO::PARAM_STR);
                $statement->bindParam(':telefono', $TelefonoT, PDO::PARAM_STR);
                $statement->bindParam(':Correo', $CorreoT, PDO::PARAM_STR);
                $statement->bindParam(':Usuario', $UserT, PDO::PARAM_STR);
                $statement->bindParam(':clave', $ClaveT, PDO::PARAM_STR);
                $inserted = $statement->execute();
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
            
        }return $inserted;
    }
    
    public static function EmailExists($connection, $Correo){
        $existe = true;
        if(isset($connection)){
            try{
                $sql = "Select * from usuario where Correo = :Correo";
                $statemet = $connection->prepare($sql);
                $statemet->bindParam(':Correo',$Correo,PDO::PARAM_STR);  
                $statemet->execute();
                $result = $statemet->fetchAll();
                if(count($result)){
                    $existe = true;
                }else{
                    $existe = false;
                }
            } catch (Exception $ex) {
                print 'ERROR'.$ex->getMessage();
            }
        }
        return $existe;
    }
    
    
    public static function UserExists($connection, $User){
        $existe = true;
        if(isset($connection)){
            try{
                $sql = "Select * from usuario where Usuario = :Usuario";
                $statemet = $connection->prepare($sql);
                $statemet ->bindParam(':Usuario',$User,PDO::PARAM_STR);  
                $statemet->execute();
                $result = $statemet->fetchAll();
                if(count($result)){
                    $existe = true;
                }else{
                    $existe = false;
                }
            } catch (Exception $ex) {
                print 'ERROR'.$ex->getMessage();
            }
        }
        return $existe;
    }
    
    public static function getUserByEmail($connection, $email) {
        $user = null;

        if (isset($connection)) {
            try {
                $sql = "select * from usuario where Correo = :email";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':email',$email, PDO::PARAM_STR);
                $statement->execute();
                $result=$statement->fetch();
                if(!empty($result)){
                    $user = new User($result['ID_Usuario'],$result['Usuario'],$result['FechaNacimiento'],$result['telefono'],$result['Correo'],
                            $result['clave'],$result['Nombre'],$result['Apellido1'],$result['Apellido2'],$result['TipoId'],$result['NumeroId'],$result['PaisResidencia']);
                   
                }
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $user;
    }

}
