<?php

class Actividad{
    private $ID;
    private $Empresa;
    private $Correo;
    private $Telefono;
    private $Contacto;
    private $ID_Direccion;
    private $Descripcion;
    private $Precio;
    
    public function __construct($ID,$Empresa, $Correo, $Telefono, $Contacto, $ID_Direccion, $Descripcion, $Precio) {
        $this->ID = $ID;
        $this->Empresa = $Empresa;
        $this->Correo = $Correo;
        $this->Telefono = $Telefono;
        $this->Contacto = $Contacto;
        $this->ID_Direccion = $ID_Direccion;
        $this->Descripcion = $Descripcion;
        $this->Precio = $Precio;
    }
    public function getID_Actividad() {
        return $this->ID;
    }

        public function getEmpresa() {
        return $this->Empresa;
    }

    public function getCorreo() {
        return $this->Correo;
    }

    public function getTelefono() {
        return $this->Telefono;
    }

    public function getContacto() {
        return $this->Contacto;
    }
    public function getID_Direccion() {
        return $this->ID_Direccion;
    }

        public function getDescripcion() {
        return $this->Descripcion;
    }

    public function getPrecio() {
        return $this->Precio;
    }



}
