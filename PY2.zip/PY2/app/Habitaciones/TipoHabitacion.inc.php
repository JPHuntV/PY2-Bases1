<?php

class TipoHabitacion {

    private $ID_Hospedaje;
    private $Nombre;
    private $Descripcion;
    private $Precio;
    private $hasAC;
    private $hasWiFi;
    private $hasHotWater;
    private $hasFan;
    private $Comodidades;
    private $imagen1;
    private $imagen2;
    private $imagen3;
    private $imagen4;
    private $imagenM;

    public function __construct($ID_Hospedaje, $Nombre, $Descripcion, $Precio, $hasAC, $hasWiFi, $hasHotWater,
                                $hasFan, $Comodidades, $imagen1, $imagen2, $imagen3, $imagen4, $imagenM) {
        $this->ID_Hospedaje = $ID_Hospedaje;
        $this->Nombre = $Nombre;
        $this->Descripcion = $Descripcion;
        $this->Precio = $Precio;
        $this->hasAC = $hasAC;
        $this->hasWiFi = $hasWiFi;
        $this->hasHotWater = $hasHotWater;
        $this->hasFan = $hasFan;
        $this->Comodidades = $Comodidades;
        $this->imagen1 = $imagen1;
        $this->imagen2 = $imagen2;
        $this->imagen3 = $imagen3;
        $this->imagen4 = $imagen4;
        $this->imagenM = $imagenM;
    }
    
    public function getID_Hospedaje() {
        return $this->ID_Hospedaje;
    }

    public function getNombre() {
        return $this->Nombre;
    }

    public function getDescripcion() {
        return $this->Descripcion;
    }

    public function getPrecio() {
        return $this->Precio;
    }

    public function getHasAC() {
        return $this->hasAC;
    }

    public function getHasWiFi() {
        return $this->hasWiFi;
    }

    public function getHasHotWater() {
        return $this->hasHotWater;
    }

    public function getHasFan() {
        return $this->hasFan;
    }

    public function getComodidades() {
        return $this->Comodidades;
    }

    public function getImagen1() {
        return $this->imagen1;
    }

    public function getImagen2() {
        return $this->imagen2;
    }

    public function getImagen3() {
        return $this->imagen3;
    }

    public function getImagen4() {
        return $this->imagen4;
    }

    public function getImagenM() {
        return $this->imagenM;
    }



}
