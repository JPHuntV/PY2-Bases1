<?php

include_once 'HabitacionRepo.inc.php';
class RegisterHabitacionVal {

    private $AvisoInicio;
    private $AvisoFin;
    private $Numero;
    private $ERROR_Numero;

    public function __construct($Numero,$connection) {

        $this->AvisoInicio = "<br><div class='alert alert-danger' role = 'alert'>";
        $this->AvisoFin = "</div>";
        $this->Numero = "";

        $this->ERROR_Numero = $this->validarNumero($connection, $Numero);
    }


    private function variableIniciada($variable) {
        if (isset($variable) && !empty($variable)) {
            return true;
        } else {
            return false;
        }
    }

    private function validarNumero($connection, $Numero) {
        if (!$this->variableIniciada($Numero)) {
            return "Ingrese un numero de habitación.";
        }/* else {
            $this->nombre = $nombre;
        }
        if (strlen($nombre) < 6) {
            return "El nombre debe tener mas de 6 caracteres";
        }
        if (strlen($nombre) > 24) {
            return "El nombre debe tener menos de 24 caracteres";
        }*/
        if (HabitacionRepo:: getHabitacionByNumber($connection, $Numero,$_SESSION['ID'])) {
            return "Ya se existe una habitacion con este numero";
        }

        return "";
    }

    public function showNumero() {
        if ($this->Numero !== "") {
            echo 'value="' . $this->Numero . '"';
        }
    }

    public function getNumero() {
        return $this->Numero;
        
    }


    public function getERROR_Number() {
        return $this->ERROR_Numero;
    }

    public function ShowErrorNumber() {
        if ($this->ERROR_Numero !== "") {
            echo $this->AvisoInicio . $this->ERROR_Numero . $this->AvisoFin;
        }
    }

    public function validAccount() {
        if ($this->ERROR_Numero === "") {
            return true;
        } else {
            return false;
        }
    }

}


