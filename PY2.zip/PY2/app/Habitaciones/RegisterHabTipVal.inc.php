<?php

include_once 'HabitacionRepo.inc.php';
class RegisterHabTipVal {

    private $AvisoInicio;
    private $AvisoFin;
    private $Nombre;
    private $ERROR_Nombre;

    public function __construct($nombre,$connection) {

        $this->AvisoInicio = "<br><div class='alert alert-danger' role = 'alert'>";
        $this->AvisoFin = "</div>";
        $this->Nombre = "";

        $this->ERROR_Nombre = $this->validarNombre($connection, $nombre);
    }


    private function variableIniciada($variable) {
        if (isset($variable) && !empty($variable)) {
            return true;
        } else {
            return false;
        }
    }

    private function validarNombre($connection, $nombre) {
       /* if (!$this->variableIniciada($nombre)) {
            return "Ingrese un nombre de usurio.";
        } else {
            $this->nombre = $nombre;
        }
        if (strlen($nombre) < 6) {
            return "El nombre debe tener mas de 6 caracteres";
        }
        if (strlen($nombre) > 24) {
            return "El nombre debe tener menos de 24 caracteres";
        }*/
        if (HabitacionRepo:: TipoExists($connection, $nombre)) {
            return "Este tipo ya existe";
        }

        return "";
    }

    public function showName() {
        if ($this->Nombre !== "") {
            echo 'value="' . $this->Nombre . '"';
        }
    }

    public function getNombre() {
        return $this->nombre;
        
    }


    public function getERROR_Nombre() {
        return $this->ERROR_Nombre;
    }

    public function ShowErrorNombre() {
        if ($this->ERROR_Nombre !== "") {
            echo $this->AvisoInicio . $this->ERROR_Nombre . $this->AvisoFin;
        }
    }

    public function validAccount() {
        if ($this->ERROR_Nombre === "") {
            return true;
        } else {
            return false;
        }
    }

}

