<?php

class Habitacion{
    
    private $ID_Hospedaje;
    private $Numero;
    private $Tipo;
    private $Estado;
    
    public function __construct($ID_Hospedaje, $Numero, $Tipo, $Estado) {
        $this->ID_Hospedaje = $ID_Hospedaje;
        $this->Numero = $Numero;
        $this->Tipo = $Tipo;
        $this->Estado = $Estado;
    }

    

    public function getID_Hospedaje() {
        return $this->ID_Hospedaje;
    }

        public function getNumero() {
        return $this->Numero;
    }

    public function getTipo() {
        return $this->Tipo;
    }

    public function getEstado() {
        return $this->Estado;
    }

}
