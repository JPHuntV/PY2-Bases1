<?php

include_once 'TipoHabitacion.inc.php';
include_once 'Habitacion.inc.php';

class HabitacionRepo {

    public static function InsertTipoHab($connection, $TipoHab) {
        $inserted = false;

        if (isset($connection)) {
            try {
                $sql = "CALL InsertTipoHabitacion(:ID_Hospedaje,:Nombre,:Descripcion,:Precio,:hasAC,:hasWifi,:hasHotWater,"
                        . ":hasFan,:Comodidades,:imagen1,:imagen2,:imagen3,:imagen4,:imagenM)";

                $ID_HospedajeT = $TipoHab->getID_Hospedaje();
                $NombreT = $TipoHab->getNombre();
                $DescripcionT = $TipoHab->getDescripcion();
                $PrecioT = $TipoHab->getPrecio();
                $hasACT = $TipoHab->getHasAC();
                $hasWiFiT = $TipoHab->getHasWiFi();
                $hasHotWaterT = $TipoHab->getHasHotWater();
                $hasFanT = $TipoHab->getHasFan();
                $ComodidadesT = $TipoHab->getComodidades();

                $imagen1T = $TipoHab->getImagen1();
                $target1 = "img/HabitacionesTipo/" . $ID_HospedajeT . "_" . $NombreT . "_1" . basename($imagen1T);

                $imagen2T = $TipoHab->getImagen2();
                $target2 = "img/HabitacionesTipo/" . $ID_HospedajeT . "_" . $NombreT . "_2" . basename($imagen2T);

                $imagen3T = $TipoHab->getImagen3();
                $target3 = "img/HabitacionesTipo/" . $ID_HospedajeT . "_" . $NombreT . "_3" . basename($imagen3T);

                $imagen4T = $TipoHab->getImagen4();
                $target4 = "img/HabitacionesTipo/" . $ID_HospedajeT . "_" . $NombreT . "_4" . basename($imagen4T);

                $imagenMT = $TipoHab->getImagenM();
                $targetM = "img/HabitacionesTipo/" . $ID_HospedajeT . "_" . $NombreT . "_M" . basename($imagenMT);

                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Hospedaje', $ID_HospedajeT, PDO::PARAM_STR);
                $statement->bindParam(':Nombre', $NombreT, PDO::PARAM_STR);
                $statement->bindParam(':Descripcion', $DescripcionT, PDO::PARAM_STR);
                $statement->bindParam(':Precio', $PrecioT, PDO::PARAM_STR);
                $statement->bindParam(':hasAC', $hasACT, PDO::PARAM_STR);
                $statement->bindParam(':hasWifi', $hasWiFiT, PDO::PARAM_STR);
                $statement->bindParam(':hasHotWater', $hasHotWaterT, PDO::PARAM_STR);
                $statement->bindParam(':hasFan', $hasFanT, PDO::PARAM_STR);
                $statement->bindParam(':Comodidades', $ComodidadesT, PDO::PARAM_STR);
                $statement->bindParam(':imagen1', $target1, PDO::PARAM_STR);
                $statement->bindParam(':imagen2', $target2, PDO::PARAM_STR);
                $statement->bindParam(':imagen3', $target3, PDO::PARAM_STR);
                $statement->bindParam(':imagen4', $target4, PDO::PARAM_STR);
                $statement->bindParam(':imagenM', $targetM, PDO::PARAM_STR);
                $inserted = $statement->execute();
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $inserted;
    }

    public static function InsertHabitacion($connection, $Habitacion) {
        $inserted = false;

        if (isset($connection)) {
            try {
                $sql = "insert into habitacion(ID_Hospedaje,Numero,ID_Tipo,Estado)"
                        . "values(:ID_Hospedaje,:Numero,:ID_Tipo,:Estado)";

                $ID_HospedajeT = $Habitacion->getID_Hospedaje();
                $NumeroT = $Habitacion->getNumero();
                $ID_TipoT = $Habitacion->getTipo();
                $EstadoT = $Habitacion->getEstado();

                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Hospedaje', $ID_HospedajeT, PDO::PARAM_STR);
                $statement->bindParam(':Numero', $NumeroT, PDO::PARAM_STR);
                $statement->bindParam(':ID_Tipo', $ID_TipoT, PDO::PARAM_STR);
                $statement->bindParam(':Estado', $EstadoT, PDO::PARAM_STR);

                $inserted = $statement->execute();
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $inserted;
    }

    public static function NumeroExists($connection, $Numero) {
        $existe = true;
        if (isset($connection)) {
            try {
                $sql = "Select * from habitacion where Numero = :Numero";
                $statemet = $connection->prepare($sql);
                $statemet->bindParam(':Numero', $Numero, PDO::PARAM_STR);
                $statemet->execute();
                $result = $statemet->fetchAll();
                if (count($result)) {
                    $existe = true;
                } else {
                    $existe = false;
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $existe;
    }

    public static function getHabitacionByNumber($connection, $Numero, $ID_Hospedaje) {
        if (isset($connection)) {
            try {
                $sql = "call getHabitacionByNumber(:Numero,:ID_Hospedaje)";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':Numero', $Numero, PDO::PARAM_STR);

                $statement->bindParam(':ID_Hospedaje', $ID_Hospedaje, PDO::PARAM_STR);

                $statement->execute();
                $result = $statement->fetchAll();
                return $result;
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
    }

    public static function TipoExists($connection, $Nombre) {
        $existe = true;
        if (isset($connection)) {
            try {
                $sql = "Select * from habitacion_tipo where Nombre = :Nombre and ID_Hospedaje = :ID_Hospedaje";
                $statemet = $connection->prepare($sql);
                $statemet->bindParam(':Nombre', $Nombre, PDO::PARAM_STR);
                $statemet->bindParam(':ID_Hospedaje', $_SESSION['ID'], PDO::PARAM_STR);
                $statemet->execute();
                $result = $statemet->fetchAll();
                if (count($result)) {
                    $existe = true;
                } else {
                    $existe = false;
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $existe;
    }

    public static function getTipos($connection, $Mode) {
        $Tipos = [];
        if (isset($connection)) {
            try {
                $sql = "call getTiposByID(:ID)";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID', $_SESSION['ID'], PDO::PARAM_STR);
                $statement->execute();
                $result = $statement->fetchAll();
                if (count($result)) {
                    foreach ($result as $valor) {
                        $Tipos [] = new TipoHabitacion($valor['ID_Hospedaje'], $valor['Nombre'], $valor['Descripcion'], $valor['Precio'], $valor['hasAC'], $valor['hasWifi'], $valor['hasHotWater'], $valor['hasFan'], $valor['Comodidades'], "", "", "", "", "");
                        if ($Mode) {
                            $ID_Tipo = $valor['ID_Tipo'];
                            $Nombre = $valor['Nombre'];
                            echo "<option value='$ID_Tipo'>$Nombre</option>";
                        }
                    }
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $Tipos;
    }

    public static function getInfoTipo($connection, $Tipo) {
        if (isset($connection)) {
            try {
                if (isset($_SESSION['SessionType']) && $_SESSION['SessionType'] == 0) {
                    $sql = "Select * from habitacion_tipo where Nombre = :Nombre and ID_Hospedaje = :ID_Hospedaje";
                    $statement = $connection->prepare($sql);
                    $statement->bindParam(':ID_Hospedaje', $_SESSION['ID'], PDO::PARAM_STR);
                } else {
                    $sql = "Select * from habitacion_tipo where Nombre = :Nombre";
                    $statement = $connection->prepare($sql);
                }
                $statement->bindParam(':Nombre', $Tipo, PDO::PARAM_STR);
                $statement->execute();
                $result = $statement->fetchAll();
                return $result;
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
    }

    public static function UpdateTipoHab($connection, $TipoHab, $target1, $target2, $target3, $target4, $targetM) {
        if (isset($connection)) {
            try {

                $sql = "call updateTipoByID(:Nombre,:ID,:Descripcion,:hasAC,:hasWifi,:hasHotWater,:hasFan,:Comodidades,:Precio,"
                        . ":img1,:img2,:img3,:img4,:imgM,:Path1,:Path2,:Path3,:Path4,:PathM)";
                
                $ID_HospedajeT = $TipoHab->getID_Hospedaje();
                $NombreT = $TipoHab->getNombre();
                $DescripcionT = $TipoHab->getDescripcion();
                $PrecioT = $TipoHab->getPrecio();
                $hasACT = $TipoHab->getHasAC();
                $hasWiFiT = $TipoHab->getHasWiFi();
                $hasHotWaterT = $TipoHab->getHasHotWater();
                $hasFanT = $TipoHab->getHasFan();
                $ComodidadesT = $TipoHab->getComodidades();

                $imagen1T = $TipoHab->getImagen1();
                $imagen2T = $TipoHab->getImagen2();               
                $imagen3T = $TipoHab->getImagen3();
                $imagen4T = $TipoHab->getImagen4();
                $imagenMT = $TipoHab->getImagenM();

                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID', $ID_HospedajeT, PDO::PARAM_STR);
                $statement->bindParam(':Nombre', $NombreT, PDO::PARAM_STR);
                $statement->bindParam(':Descripcion', $DescripcionT, PDO::PARAM_STR);
                $statement->bindParam(':Precio', $PrecioT, PDO::PARAM_STR);
                $statement->bindParam(':hasAC', $hasACT, PDO::PARAM_STR);
                $statement->bindParam(':hasWifi', $hasWiFiT, PDO::PARAM_STR);
                $statement->bindParam(':hasHotWater', $hasHotWaterT, PDO::PARAM_STR);
                $statement->bindParam(':hasFan', $hasFanT, PDO::PARAM_STR);
                $statement->bindParam(':Comodidades', $ComodidadesT, PDO::PARAM_STR);
                echo "<br>";
                echo "<br>";
                echo $imagen1T;
                $statement->bindParam(':img1', $imagen1T, PDO::PARAM_STR);
                $statement->bindParam(':img2', $imagen2T, PDO::PARAM_STR);
                $statement->bindParam(':img3', $imagen3T, PDO::PARAM_STR);
                $statement->bindParam(':img4', $imagen4T, PDO::PARAM_STR);
                $statement->bindParam(':imgM', $imagenMT, PDO::PARAM_STR);
                echo "<br>";
                echo  $target1;        
                $statement->bindParam(':Path1', $target1, PDO::PARAM_STR);
                $statement->bindParam(':Path2', $target2, PDO::PARAM_STR);
                $statement->bindParam(':Path3', $target3, PDO::PARAM_STR);
                $statement->bindParam(':Path4', $target4, PDO::PARAM_STR);
                $statement->bindParam(':PathM', $targetM, PDO::PARAM_STR);
                $result = $statement->execute();              
                return $result;
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
    }

    public static function getHabitaciones($connection) {
        $habitaciones = [];
        if (isset($connection)) {
            try {
                if (isset($_SESSION['SessionType']) && $_SESSION['SessionType'] == 0) {
                    $sql = "call getHabitacionesE(:ID_Hospedaje)";
                    $statement = $connection->prepare($sql);
                    $statement->bindParam(':ID_Hospedaje', $_SESSION['ID'], PDO::PARAM_STR);
                } else {
                    $sql = "call getHabitacionesByRandom()";
                    $statement = $connection->prepare($sql);
                }
                $statement->execute();
                $result = $statement->fetchAll();
                if (count($result)) {
                    foreach ($result as $valor) {
                        if ($valor['Estado']) {
                            $Estado = "Disponible";
                        } else {
                            $Estado = "Ocupada";
                        }
                        $habitaciones[] = new Habitacion($valor['ID_Hospedaje'], $valor['Numero'], $valor['Tipo'], $Estado);
                    }
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $habitaciones;
    }

    public static function getHabitacionesByFilter($connection, $lugar, $llegada, $salida, $Tipo) {
        $habitaciones = [];
        if (!isset($lugar)) {
            $lugar = '';
        }
        if (!isset($llegada)) {
            $llegada = '';
        }
        if (!isset($salida)) {
            $salida = '';
        }
        if (!isset($Tipo)) {
            $Tipo = '';
        }
        if (isset($connection)) {
            try {
                if (isset($_SESSION['SessionType']) && $_SESSION['SessionType'] == 0) {
                    $sql = "call getHabitacionesE(:ID_Hospedaje)";
                    $statement = $connection->prepare($sql);
                    $statement->bindParam(':ID_Hospedaje', $_SESSION['ID'], PDO::PARAM_STR);
                } else {
                    $sql = "call getHabitacionesByFilter(:tipo,:llegada,:salida,:lugar)";
                    $statement = $connection->prepare($sql);
                    $statement->bindParam(':lugar', $lugar, PDO::PARAM_STR);
                    $statement->bindParam(':llegada', $llegada, PDO::PARAM_STR);
                    $statement->bindParam(':salida', $salida, PDO::PARAM_STR);
                    $statement->bindParam(':tipo', $Tipo, PDO::PARAM_STR);
                }
                $statement->execute();
                $result = $statement->fetchAll();
                if (count($result)) {
                    echo "<div class='alert alert-success' role='alert' style='text-align: center'> ¡Estos son los resultados de tu busqueda! </div>";
                    foreach ($result as $valor) {
                        if ($valor['Estado']) {
                            $Estado = "Disponible";
                        } else {
                            $Estado = "Ocupada";
                        }
                        $habitaciones[] = new Habitacion($valor['ID_Hospedaje'], $valor['Numero'], $valor['Tipo'], $Estado);
                    }
                } else {
                    Connection::closeConnection();
                    Connection::openConnection();
                    echo "<div class='alert alert-info' role='alert' style='text-align: center'> ¡Vaya! parece que no hay resultados para tu busqueda </div>";
                    $habitaciones = HabitacionRepo::getHabitaciones(Connection::getConnection());
                    Connection::closeConnection();
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $habitaciones;
    }

    public static function getMiniatura($connection, $tipo, $ID) {

        if (isset($_SESSION['SessionType']) && $_SESSION['SessionType'] == 0) {
            $target = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $tipo . "_M";
        } else {
            $target = "img/HabitacionesTipo/" . $ID . "_" . $tipo . "_M";
        }
        $result = null;
        if (isset($connection)) {
            try {
                $sql = "select imagen from habitacion_fotos where imagen like'" . $target . "%'  LIMIT 1";
                $statement = $connection->prepare($sql);
                $statement->execute();
                $result = $statement->fetchAll();

                /* foreach ($result as $valor){
                  echo $valor['imagen'];
                  echo "<br>";
                  } */
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $result;
    }

    public static function getImagenes($connection, $tipo, $ID) {
        if (isset($_SESSION['SessionType']) && $_SESSION['SessionType'] == 0) {
            $target = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $tipo . "_";
        } else {
            $target = "img/HabitacionesTipo/" . $ID . "_" . $tipo . "_";
        }
        //$target = "img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $tipo . "_";
        $imagenes = [];
        $result = null;
        if (isset($connection)) {
            try {
                for ($i = 1; $i <= 4; $i++) {
                    $sql = "select imagen from habitacion_fotos where imagen like'" . $target . $i . "%'  LIMIT 1";
                    $statement = $connection->prepare($sql);
                    $statement->execute();
                    $result = $statement->fetchAll();
                    $imagenes[] = $result[0]['imagen'];
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $imagenes;
    }

}
