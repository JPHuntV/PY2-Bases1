<?php

include_once 'TipoHabitacion.inc.php';

class HabitacionRepo {

    public static function InsertTipoHab($connection, $TipoHab) {
        $inserted = false;

        if (isset($connection)) {
            try {
                $sql = "CALL InsertTipoHabitacion(:ID_Hospedaje,:Nombre,:Descripcion,:Precio,:hasAC,:hasWifi,:hasHotWater,"
                        . ":hasFan,:Comodidades,:imagen1,:imagen2,:imagen3,:imagen4)";

                $ID_HospedajeT = $TipoHab->getID_Hospedaje();
                $NombreT = $TipoHab->getNombre();
                $DescripcionT = $TipoHab->getDescripcion();
                $PrecioT = $TipoHab->getPrecio();
                $hasACT = $TipoHab->getHasAC();
                $hasWiFiT = $TipoHab->getHasWiFi();
                $hasHotWaterT = $TipoHab->getHasHotWater();
                $hasFanT = $TipoHab->getHasFan();
                $ComodidadesT = $TipoHab->getComodidades();

                $imagen1T = $TipoHab->getImagen1();
                $target1 = "img/HabitacionesTipo/" . $ID_HospedajeT . "_" . $NombreT . "_1" . basename($imagen1T);

                $imagen2T = $TipoHab->getImagen2();
                $target2 = "img/HabitacionesTipo/" . $ID_HospedajeT . "_" . $NombreT . "_2" . basename($imagen2T);

                $imagen3T = $TipoHab->getImagen3();
                $target3 = "img/HabitacionesTipo/" . $ID_HospedajeT . "_" . $NombreT . "_3" . basename($imagen3T);

                $imagen4T = $TipoHab->getImagen4();
                $target4 = "img/HabitacionesTipo/" . $ID_HospedajeT . "_" . $NombreT . "_4" . basename($imagen4T);

                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Hospedaje', $ID_HospedajeT, PDO::PARAM_STR);
                $statement->bindParam(':Nombre', $NombreT, PDO::PARAM_STR);
                $statement->bindParam(':Descripcion', $DescripcionT, PDO::PARAM_STR);
                $statement->bindParam(':Precio', $PrecioT, PDO::PARAM_STR);
                $statement->bindParam(':hasAC', $hasACT, PDO::PARAM_STR);
                $statement->bindParam(':hasWifi', $hasWiFiT, PDO::PARAM_STR);
                $statement->bindParam(':hasHotWater', $hasHotWaterT, PDO::PARAM_STR);
                $statement->bindParam(':hasFan', $hasFanT, PDO::PARAM_STR);
                $statement->bindParam(':Comodidades', $ComodidadesT, PDO::PARAM_STR);
                $statement->bindParam(':imagen1', $target1, PDO::PARAM_STR);
                $statement->bindParam(':imagen2', $target2, PDO::PARAM_STR);
                $statement->bindParam(':imagen3', $target3, PDO::PARAM_STR);
                $statement->bindParam(':imagen4', $target4, PDO::PARAM_STR);
                $inserted = $statement->execute();
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $inserted;
    }
    public static function InsertHabitacion($connection, $Habitacion) {
        $inserted = false;

        if (isset($connection)) {
            try {
                $sql = "insert into habitacion(ID_Hospedaje,Numero,ID_Tipo,Estado)"
                        . "values(:ID_Hospedaje,:Numero,:ID_Tipo,:Estado)";

                $ID_HospedajeT = $Habitacion->getID_Hospedaje();
                $NumeroT = $Habitacion->getNumero();
                $ID_TipoT = $Habitacion->getTipo();
                $EstadoT = $Habitacion->getEstado();
               
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Hospedaje', $ID_HospedajeT, PDO::PARAM_STR);
                $statement->bindParam(':Numero', $NumeroT, PDO::PARAM_STR);
                $statement->bindParam(':ID_Tipo', $ID_TipoT, PDO::PARAM_STR);
                $statement->bindParam(':Estado', $EstadoT, PDO::PARAM_STR);
                
                $inserted = $statement->execute();
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $inserted;
    }
    public static function NumeroExists($connection, $Numero) {
        $existe = true;
        if (isset($connection)) {
            try {
                $sql = "Select * from habitacion where Numero = :Numero";
                $statemet = $connection->prepare($sql);
                $statemet->bindParam(':Numero', $Numero, PDO::PARAM_STR);
                $statemet->execute();
                $result = $statemet->fetchAll();
                if (count($result)) {
                    $existe = true;
                } else {
                    $existe = false;
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $existe;
    }
    public static function TipoExists($connection, $Nombre) {
        $existe = true;
        if (isset($connection)) {
            try {
                $sql = "Select * from habitacion_tipo where Nombre = :Nombre";
                $statemet = $connection->prepare($sql);
                $statemet->bindParam(':Nombre', $Nombre, PDO::PARAM_STR);
                $statemet->execute();
                $result = $statemet->fetchAll();
                if (count($result)) {
                    $existe = true;
                } else {
                    $existe = false;
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $existe;
    }

    public static function getTipos($connection) {
        if (isset($connection)) {
            try {
                $sql = "Select ID_Tipo,Nombre from habitacion_tipo where ID_Hospedaje = :ID_Hospedaje";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Hospedaje', $_SESSION['ID'], PDO::PARAM_STR);
                $statement->execute();
                $result = $statement->fetchAll();
                if (count($result)) {
                    foreach ($result as $valor) {
                        $ID_Tipo = $valor['ID_Tipo'];
                        $Nombre = $valor['Nombre'];
                        echo "<option value='$ID_Tipo'>$Nombre</option>";
                        return true;
                    }
                } else {
                    return false;
                }              
                return $result;
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
    }
    
    public static function getHabitaciones($connection){
        $habitaciones = [];       
        if(isset($connection)){
            try{
                $sql = "call getHabitacionesE(:ID_Hospedaje)";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID_Hospedaje', $_SESSION['ID'], PDO::PARAM_STR);
                $statement->execute();
                $result = $statement->fetchAll();
                if(count($result)){
                    foreach($result as $valor){
                        if($valor['Estado']){
                            $Estado = "Disponible";
                        }else{
                            $Estado= "Ocupada";
                        }
                        $habitaciones[]= new Habitacion($valor['ID_Hospedaje'],$valor['Numero'],$valor['Tipo'],$Estado);
                        
                    }
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $habitaciones;
    }
    
    public static function getMiniatura($connection,$tipo){
        $target = "../../img/HabitacionesTipo/". $_SESSION['ID'] . "_" . $tipo;
        $result = null;
        if(isset($connection)){
            try{
              $sql = "select imagen from habitacion_fotos limit 1 where imagen like" . $target ."%";
              $statement = prepare($sql);
              $statement -> execute();
              $result = $statement->fetchAll();
              $result= $result['imagen'];       
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $result;
    }

}