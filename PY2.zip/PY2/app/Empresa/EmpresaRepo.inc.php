<?php

include_once 'Empresa.inc.php';
include_once 'UserEmpresa.inc.php';
include_once '../../app/Direccion/Direccion.inc.php';

class EmpresaRepo {

    public static function InsertEmpresa($connection, $Empresa, $Direccion, $clave) {
        $inserted = false;

        if (isset($connection)) {
            try {
                $sql = "call InsertHospedajes(:Nombre,:Ced_Jur,:Tipo,:Correo,:Telefono1,"
                        . ":Telefono2,:URL_pag,:latitud,:longitud,:facebook,:instagram,"
                        . ":twitter,:youtube,:airbnb,:hasPool,:hasWiFi,:hasRest,:hasBar,"
                        . " :hasRanch,:serviciosExtra, :Provincia,:Canton,:Distrito,:Barrio,:Senias,:Clave)";

                $NombreT = $Empresa->getNombre();
                $Ced_JurT = $Empresa->getCed_Jur();
                $TipoT = $Empresa->getTipo();
                $CorreoT = $Empresa->getCorreo();
                $Telefono1T = $Empresa->getTelefono1();
                if ($Empresa->getTelefono2() == 0) {
                    $Telefono2T = Null;
                } else {
                    $Telefono2T = $Empresa->getTelefono2();
                }
                $URL_pagT = $Empresa->getURL_pag();
                $latitudT = $Empresa->getLatitud();
                $longitudT = $Empresa->getLongitud();
                $facebookT = $Empresa->getFacebook();
                $instagramT = $Empresa->getInstagram();
                $twitterT = $Empresa->getTwitter();
                $youtubeT = $Empresa->getYoutube();
                $airbnbT = $Empresa->getAirbnb();
                $hasPoolT = $Empresa->getHasPool();
                $hasWiFiT = $Empresa->getHasWiFi();
                $hasRestT = $Empresa->getHasRest();
                $hasBarT = $Empresa->getHasBar();
                $hasRanchT = $Empresa->getHasRanch();
                $serviciosExtraT = $Empresa->getHasOtros();

                $ProvinciaT = $Direccion->getProvincia();
                $CantonT = $Direccion->getCanton();
                $DistritoT = $Direccion->getDistrito();
                $BarrioT = $Direccion->getBarrio();
                $SeniasT = $Direccion->getSenias();

                $statement = $connection->prepare($sql);
                $statement = $connection->prepare($sql);
                $statement->bindParam(':Nombre', $NombreT, PDO::PARAM_STR);
                $statement->bindParam(':Ced_Jur', $Ced_JurT, PDO::PARAM_STR);
                $statement->bindParam(':Tipo', $TipoT, PDO::PARAM_STR);
                //$statement->bindParam(':ID_Direccion', $ID_Dir[0], PDO::PARAM_STR);
                $statement->bindParam(':Correo', $CorreoT, PDO::PARAM_STR);
                $statement->bindParam(':Telefono1', $Telefono1T, PDO::PARAM_STR);
                $statement->bindParam(':Telefono2', $Telefono2T, PDO::PARAM_STR);
                $statement->bindParam(':URL_pag', $URL_pagT, PDO::PARAM_STR);
                $statement->bindParam(':latitud', $latitudT, PDO::PARAM_STR);
                $statement->bindParam(':longitud', $longitudT, PDO::PARAM_STR);
                $statement->bindParam(':facebook', $facebookT, PDO::PARAM_STR);
                $statement->bindParam(':instagram', $instagramT, PDO::PARAM_STR);
                $statement->bindParam(':twitter', $twitterT, PDO::PARAM_STR);
                $statement->bindParam(':youtube', $youtubeT, PDO::PARAM_STR);
                $statement->bindParam(':airbnb', $airbnbT, PDO::PARAM_STR);
                $statement->bindParam(':hasPool', $hasPoolT, PDO::PARAM_STR);
                $statement->bindParam(':hasWiFi', $hasWiFiT, PDO::PARAM_STR);
                $statement->bindParam(':hasRest', $hasRestT, PDO::PARAM_STR);
                $statement->bindParam(':hasBar', $hasBarT, PDO::PARAM_STR);
                $statement->bindParam(':hasRanch', $hasRanchT, PDO::PARAM_STR);
                $statement->bindParam(':serviciosExtra', $serviciosExtraT, PDO::PARAM_STR);
                $statement->bindParam(':Provincia', $ProvinciaT, PDO::PARAM_STR);
                $statement->bindParam(':Canton', $CantonT, PDO::PARAM_STR);
                $statement->bindParam(':Distrito', $DistritoT, PDO::PARAM_STR);
                $statement->bindParam(':Barrio', $BarrioT, PDO::PARAM_STR);
                $statement->bindParam(':Senias', $SeniasT, PDO::PARAM_STR);
                $Clave = password_hash($clave, PASSWORD_DEFAULT);
                $statement->bindParam(':Clave', $Clave, PDO::PARAM_STR);
                $inserted = $statement->execute();
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $inserted;
    }

    public static function EmailExists($connection, $Correo) {
        $existe = true;
        if (isset($connection)) {
            try {
                $sql = "Select * from usuarioempresa where Correo = :Correo";
                $statemet = $connection->prepare($sql);
                $statemet->bindParam(':Correo', $Correo, PDO::PARAM_STR);
                $statemet->execute();
                $result = $statemet->fetchAll();
                if (count($result)) {
                    $existe = true;
                } else {
                    $existe = false;
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $existe;
    }

    public static function CedJurExists($connection, $CedJur) {
        $existe = true;
        if (isset($connection)) {
            try {
                $sql = "Select * from hospedajes where Ced_Jur = :CedJur";
                $statemet = $connection->prepare($sql);
                $statemet->bindParam(':CedJur', $CedJur, PDO::PARAM_STR);
                $statemet->execute();
                $result = $statemet->fetchAll();
                if (count($result)) {
                    $existe = true;
                } else {
                    $existe = false;
                }
            } catch (Exception $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $existe;
    }

    public static function getUserByEmail($connection, $email) {
        $user = null;

        if (isset($connection)) {
            try {
                $sql = "select * from usuarioempresa where Correo = :email";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':email', $email, PDO::PARAM_STR);
                $statement->execute();
                $result = $statement->fetch();
                if (!empty($result)) {
                    $user = new UserEmpresa($result['ID_userEmpresa'], $result['ID_Hospedaje'], $result['Nombre'], $result['Correo'], $result['Clave']);
                }
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $user;
    }

    public static function getEmpresaByID($connection) {
        $Empresa = null;
        if (isset($connection)) {
            try {
                $sql = "call getEmpresaByID(:ID)";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID', $_SESSION['ID'], PDO::PARAM_STR);
                $statement->execute();
                $result = $statement->fetch();
                if (!empty($result)) {
                    $Empresa = new Empresa($result['Nombre'], $result['Ced_Jur'], $result['Tipo'], $result['ID_Direccion'], $result['Correo'], $result['Telefono1'], $result['Telefono2'], $result['URL_pag'], $result['latitud'], $result['longitud'], $result['Facebook'], $result['Instagram'], $result['Twitter'], $result['YouTube'], $result['Airbnb'], $result['hasPool'], $result['hasWifi'], $result['hasRest'], $result['hasBar'], $result['hasRanch'], $result['serviciosExtra']);
                } else {
                    echo 'esto no deberia de pasar';
                }
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $Empresa;
    }

    public static function updateEmpresaByID($connection, $Empresa) {
        $inserted = false;
        if (isset($connection)) {
            try {
                $sql = "call updateEmpresaByID(:ID,:hasPool,:hasWifi,:hasRest,:hasBar,:hasRanch,:serviciosExtra,"
                        . ":numero2,:URL_pag,:Facebook,:Instagram,:Twitter,:Youtube,:Airbnb)";
                
               if ($Empresa->getTelefono2() == 0) {
                    $Telefono2T = Null;
                } else {
                    $Telefono2T = $Empresa->getTelefono2();
                }
                $URL_pagT = $Empresa->getURL_pag();
                $facebookT = $Empresa->getFacebook();
                $instagramT = $Empresa->getInstagram();
                $twitterT = $Empresa->getTwitter();
                $youtubeT = $Empresa->getYoutube();
                $airbnbT = $Empresa->getAirbnb();
                $hasPoolT = $Empresa->getHasPool();
                $hasWiFiT = $Empresa->getHasWiFi();
                $hasRestT = $Empresa->getHasRest();
                $hasBarT = $Empresa->getHasBar();
                $hasRanchT = $Empresa->getHasRanch();
                $serviciosExtraT = $Empresa->getHasOtros();
              
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID', $_SESSION['ID'], PDO::PARAM_STR);
                $statement->bindParam(':hasPool',$hasPoolT , PDO::PARAM_STR);
                $statement->bindParam(':hasWifi', $hasWiFiT , PDO::PARAM_STR);
                $statement->bindParam(':hasRest',$hasRestT, PDO::PARAM_STR);
                $statement->bindParam(':hasBar',$hasBarT  , PDO::PARAM_STR);
                $statement->bindParam(':hasRanch',$hasRanchT , PDO::PARAM_STR);
                $statement->bindParam(':serviciosExtra',$serviciosExtraT , PDO::PARAM_STR);
                $statement->bindParam(':numero2',$Telefono2T, PDO::PARAM_STR);
                $statement->bindParam(':URL_pag', $URL_pagT , PDO::PARAM_STR);
                $statement->bindParam(':Facebook',  $facebookT, PDO::PARAM_STR);
                $statement->bindParam(':Instagram', $instagramT, PDO::PARAM_STR);
                $statement->bindParam(':Twitter', $twitterT, PDO::PARAM_STR);
                $statement->bindParam(':Youtube', $youtubeT, PDO::PARAM_STR);
                $statement->bindParam(':Airbnb', $airbnbT, PDO::PARAM_STR);
                $inserted = $statement->execute();
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $inserted;
    }

}
