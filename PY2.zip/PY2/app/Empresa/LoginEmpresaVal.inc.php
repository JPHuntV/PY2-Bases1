<?php

include_once 'EmpresaRepo.inc.php';

class LoginEmpresaVal{
    
    private $UserEmpresa;
    private $Error;
    
    public function __construct($Correo, $Clave, $connection){
        $this->Error="";
        if(!$this->variableIniciada($Correo) || !$this->variableIniciada($Clave) ){
            $this->UserEmpresa=null;
            $this->Error = "Porfavor Ingrese su correo y contraseña";
        }else{
            
            $this -> UserEmpresa = EmpresaRepo::getUserByEmail($connection,$Correo);
            
            if(is_null($this->UserEmpresa)|| !password_verify($Clave, $this->UserEmpresa->getClave())){
                $this->Error = "Los datos ingresados son incorrectos";
            }
        }
    }
    
     private function variableIniciada($variable) {
        if (isset($variable) && !empty($variable)) {
            return true;
        } else {
            return false;
        }
    }
    
    public function getUserEmpresa() {
        return $this->UserEmpresa;
    }

    public function getError() {
        return $this->Error;
    }

    

    public function showError(){
        if($this->Error !== ''){
            echo "<br><div class = 'alert alert-danger' role ='alert'>";
            echo $this->Error;
            echo "</div><br>";
        }
    }
}
