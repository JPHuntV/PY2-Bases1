<?php

class Empresa {
    private $Nombre;
    private $Ced_Jur;
    private $Tipo;
    private $ID_Direccion;
    private $Correo;
    private $Telefono1;
    private $Telefono2;
    private $URL_pag;
    private $latitud;
    private $longitud;
    private $facebook;
    private $instagram;
    private $twitter;
    private $youtube;
    private $airbnb;
    private $hasPool;
    private $hasWiFi;
    private $hasRest;
    private $hasBar;
    private $hasRanch;
    private $hasOtros;


    public function __construct($Nombre, $Ced_Jur, $Tipo,$ID_Direccion, $Correo, $Telefono1, $Telefono2, 
                                $URL_pag, $latitud, $longitud, $facebook, $instagram, $twitter, $youtube, $airbnb,
                                $hasPool, $hasWiFi, $hasRest, $hasBar, $hasRanch,$hasOtros) {
        $this->Nombre = $Nombre;
        $this->Ced_Jur = $Ced_Jur;
        $this->Tipo = $Tipo;
        $this->ID_Direccion = $ID_Direccion;
        $this->Correo = $Correo;
        $this->Telefono1 = $Telefono1;
        $this->Telefono2 = $Telefono2;
        $this->URL_pag = $URL_pag;
        $this->latitud = $latitud;
        $this->longitud = $longitud;
        $this->facebook = $facebook;
        $this->instagram = $instagram;
        $this->twitter = $twitter;
        $this->youtube = $youtube;
        $this->airbnb = $airbnb;
        $this->hasPool = $hasPool;
        $this->hasWiFi = $hasWiFi;
        $this->hasRest = $hasRest;
        $this->hasBar = $hasBar;
        $this->hasRanch = $hasRanch;
        $this->hasOtros = $hasOtros;
    }

    
    public function getNombre() {
        return $this->Nombre;
    }

    public function getCed_Jur() {
        return $this->Ced_Jur;
    }

    public function getTipo() {
        return $this->Tipo;
    }

    public function getID_Direccion() {
        return $this->ID_Direccion;
    }

        public function getCorreo() {
        return $this->Correo;
    }

    public function getTelefono1() {
        return $this->Telefono1;
    }

    public function getTelefono2() {
        return $this->Telefono2;
    }

    public function getURL_pag() {
        return $this->URL_pag;
    }

    public function getLatitud() {
        return $this->latitud;
    }

    public function getLongitud() {
        return $this->longitud;
    }

    public function getFacebook() {
        return $this->facebook;
    }

    public function getInstagram() {
        return $this->instagram;
    }

    public function getTwitter() {
        return $this->twitter;
    }

    public function getYoutube() {
        return $this->youtube;
    }

    public function getAirbnb() {
        return $this->airbnb;
    }
    
    public function getHasPool() {
        return $this->hasPool;
    }

    public function getHasWiFi() {
        return $this->hasWiFi;
    }

    public function getHasRest() {
        return $this->hasRest;
    }

    public function getHasBar() {
        return $this->hasBar;
    }

    public function getHasRanch() {
        return $this->hasRanch;
    }
    public function getHasOtros() {
        return $this->hasOtros;
    }

        
    public function setNombre($Nombre) {
        $this->Nombre = $Nombre;
    }

    public function setCed_Jur($Ced_Jur) {
        $this->Ced_Jur = $Ced_Jur;
    }

    public function setTipo($Tipo) {
        $this->Tipo = $Tipo;
    }

    public function setCorreo($Correo) {
        $this->Correo = $Correo;
    }

    public function setTelefono1($Telefono1) {
        $this->Telefono1 = $Telefono1;
    }

    public function setTelefono2($Telefono2) {
        $this->Telefono2 = $Telefono2;
    }

    public function setURL_pag($URL_pag) {
        $this->URL_pag = $URL_pag;
    }

    public function setLatitud($latitud) {
        $this->latitud = $latitud;
    }

    public function setLongitud($longitud) {
        $this->longitud = $longitud;
    }

    public function setFacebook($facebook) {
        $this->facebook = $facebook;
    }

    public function setInstagram($instagram) {
        $this->instagram = $instagram;
    }

    public function setTwitter($twitter) {
        $this->twitter = $twitter;
    }

    public function setYoutube($youtube) {
        $this->youtube = $youtube;
    }

    public function setAirbnb($airbnb) {
        $this->airbnb = $airbnb;
    }

    public function setHasPool($hasPool) {
        $this->hasPool = $hasPool;
    }

    public function setHasWiFi($hasWiFi) {
        $this->hasWiFi = $hasWiFi;
    }

    public function setHasRest($hasRest) {
        $this->hasRest = $hasRest;
    }

    public function setHasBar($hasBar) {
        $this->hasBar = $hasBar;
    }

    public function setHasRanch($hasRanch) {
        $this->hasRanch = $hasRanch;
    }

    public function setHasOtros($hasOtros) {
        $this->hasOtros = $hasOtros;
    }



}
