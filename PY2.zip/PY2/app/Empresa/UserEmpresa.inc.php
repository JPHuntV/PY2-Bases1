<?php

class UserEmpresa {

    private $ID_User_Empresa;
    private $ID_Hospedaje;
    private $Nombre;
    private $Correo;
    private $Clave;

    public function __construct($ID_User_Empresa, $ID_Hospedaje, $Nombre, $Correo, $Clave) {
        $this->ID_User_Empresa = $ID_User_Empresa;
        $this->ID_Hospedaje = $ID_Hospedaje;
        $this->Nombre = $Nombre;
        $this->Correo = $Correo;
        $this->Clave = $Clave;
    }

    public function getID_User_Empresa() {
        return $this->ID_User_Empresa;
    }

    public function getID_Hospedaje() {
        return $this->ID_Hospedaje;
    }
    public function getNombre() {
        return $this->Nombre;
    }

        public function getCorreo() {
        return $this->Correo;
    }

    public function getClave() {
        return $this->Clave;
    }

    public function setID_User_Empresa($ID_User_Empresa) {
        $this->ID_User_Empresa = $ID_User_Empresa;
    }

    public function setID_Hospedaje($ID_Hospedaje) {
        $this->ID_Hospedaje = $ID_Hospedaje;
    }

    public function setCorreo($Correo) {
        $this->Correo = $Correo;
    }

    public function setClave($Clave) {
        $this->Clave = $Clave;
    }

}
