<?php
include_once 'ReservationRepo.inc.php';
class ReservationVal {

    private $AvisoInicio;
    private $AvisoFin;
    private $numeroIdentificacion;
    private $ERROR_Identificacion;

    public function __construct($numeroIdentificacion,$connection) {

        $this->AvisoInicio = "<br><div class='alert alert-danger' role = 'alert'>";
        $this->AvisoFin = "</div>";
        $this->numeroIdentificacion = "";

        $this->ERROR_Identificacion= $this->validarIdentificacion($connection, $numeroIdentificacion);
    }


    private function variableIniciada($variable) {
        if (isset($variable) && !empty($variable)) {
            return true;
        } else {
            return false;
        }
    }

    private function validarNumero($connection, $Numero) {
        if (!$this->variableIniciada($numeroIdentificacion)) {
            return "Ingrese un numero de habitación.";
        }/* else {
            $this->nombre = $nombre;
        }
        if (strlen($nombre) < 6) {
            return "El nombre debe tener mas de 6 caracteres";
        }
        if (strlen($nombre) > 24) {
            return "El nombre debe tener menos de 24 caracteres";
        }*/
        if (ReservationRepo:: IdentificacionExists($connection, $numeroIdentificacion)) {
            return "Ya se existe una habitacion con este numero";
        }

        return "";
    }

    public function showNumero() {
        if ($this->Numero !== "") {
            echo 'value="' . $this->Numero . '"';
        }
    }

    public function getNumero() {
        return $this->Numero;
        
    }


    public function getERROR_Number() {
        return $this->ERROR_Numero;
    }

    public function ShowErrorNumber() {
        if ($this->ERROR_Numero !== "") {
            echo $this->AvisoInicio . $this->ERROR_Numero . $this->AvisoFin;
        }
    }

    public function validAccount() {
        if ($this->ERROR_Numero === "") {
            return true;
        } else {
            return false;
        }
    }

}



