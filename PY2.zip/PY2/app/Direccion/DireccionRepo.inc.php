 <?php
 class DireccionRepo{
     
     public static function getDireccionByID($connection, $ID) {
        $Direccion = null;
        if (isset($connection)) {
            try {
                $sql = "call getDireccionByID(:ID)";
                $statement = $connection->prepare($sql);
                $statement->bindParam(':ID', $ID, PDO::PARAM_STR);
                $statement->execute();
                $result = $statement->fetch();
                if (!empty($result)) {
                    $Direccion = new Direccion($result['Provincia'], $result['Canton'], $result['Distrito'], $result['Barrio'], $result['Senias']);
                }
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }
        return $Direccion;
    }

 }