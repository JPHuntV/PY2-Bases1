    <script src="\PY2\js\jquery.min.js"></script>
   
     <script src="\PY2\js\bootstrap.min.js"></script>
     
   <! script src="\PY2\js\bootstrap.bundle.min.js" type="text/javascript">
    <script src="\PY2\js\moment.min.js" type="text/javascript"></script>
    <script src="\PY2\js\bootstrap-datetimepicker.min.js" type="text/javascript"></script>

</body>
</html>