<?php
include_once ($_SERVER['DOCUMENT_ROOT'] . '/PY2/app/ControlSesion.inc.php');

include_once ($_SERVER['DOCUMENT_ROOT'] . '/PY2/app/config.inc.php');
?>
<nav class="navbar-default  navbar-static-top" >
    <div class="container-fluid"  style="background-color: #2b2b2b" >
        <div class="navbar-header">
            <a class="navbar-brand"  href=" \PY2\index.php">          
                <img class="img-responsive" src="https://logoipsum.com/logo/logo-12.svg" style="width: 80%;position:relative;top:-250%" alt="logo" title="XYZ Home">
            </a>
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>


        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
                <?php if (ControlSesion::SesionStarted()) { ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <span class='glyphicon glyphicon-user' aria-hidden="true"></span>
                            <?php echo ' ' . $_SESSION['UserName']; ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="#">
                                    Configuracion
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Reservaciones
                                </a>
                            </li>
                            <li>
                                <a href="\PY2\Main\LogOutUser.php">
                                    <span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>
                                    Cerrar sesión
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php } else {
                    ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <span class='glyphicon glyphicon-bed' aria-hidden="true"></span>
                            Hospedajes
                        </a>
                        <ul class="dropdown-menu">
                            <li>      
                                <a href="\PY2\Main\Empresa\LoginEmpresa.php" >
                                    <span class="glyphicon glyphicon-log-in" aria-hidden="true"></span>
                                    Inicio de sesión
                                </a>

                            </li>
                            <li>
                                <a href="\PY2\Main\Empresa\RegisterEmpresa.php">
                                    <span class="glyphicon glyphicon-bed" aria-hidden="true"></span>
                                    Registra tu empresa
                                </a>
                            </li>

                        </ul>
                    </li>
                    <li>
                        <a href="\PY2\Main\User\LoginUser.php">
                            <span class="glyphicon glyphicon-log-in" aria-hidden="true"></span>
                            Inicia sesión</a>
                    </li>
                    <li>
                        <a href="\PY2\Main\User\RegisterInfoCuenta.php">
                            <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                            Registrate</a>
                    </li>
                <?php }
                ?>
            </ul>
        </div>
    </div>
</nav>
