<!DOCTYPE html>
<html lang="es">
    <head>
        <link rel="icon" href="https://cdn.icon-icons.com/icons2/1363/PNG/512/travel-holiday-vacation-327_89074.png">
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="with=d3vice-with, initial-scale=1">
        <?php
            echo "<title>$tittle</title>";
        ?>
        
    <link href="\PY2\CSS\bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="\PY2\CSS\font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <link href="\PY2\CSS\fontawesome.min.css" rel="stylesheet" type="text/css"/>
    <link href="\PY2\CSS\bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css"/>
    
    </head>
    <body style="background-color: whitesmoke">
    