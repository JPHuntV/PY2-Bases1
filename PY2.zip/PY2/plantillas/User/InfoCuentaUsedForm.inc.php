<div class="form-group">
    <label style='margin-left: 10%' >Nombre de usuario</label>
    <input type="text" class="form-control" name="nombre" <?php $validador->showName()?> style='margin-left: 10%; width: 80%'>
    <?php
    $validador->ShowErrorNombre();
    ?>
</div>
<div class="form-group">
    <label style='margin-left: 10%' >Fecha de nacimiento</label>
    <input type="date" class="form-control" name="nacimiento" style='margin-left: 10%; width: 80%'  <?php $validador->showFecha()?>  min="1900-01-01" max="2002-12-31" required>
</div>
<div class="form-group">
    <label style='margin-left: 10%' >Teléfono</label>
    <input type="tel" class="form-control" name="telefono" <?php $validador->showTelefono()?> style='margin-left: 10%; width: 80%'>
    <?php
    $validador->ShowErrorTelefono();
    ?>
</div>
<div class="form-group" >
    <label style='margin-left: 10%' >Correo</label>
    <input type="email" class="form-control" name="Correo" <?php $validador->showCorreo()?> style='margin-left: 10%; width: 80%' >
    <?php
    $validador->ShowErrorCorreo();
    ?>
</div>
<div class="form-group">
    <label style='margin-left: 10%' >Contraseña</label>
    <input type="password" class="form-control" name="clave1" style='margin-left: 10%; width: 80%'>
    <?php
    $validador->ShowErrorClave1();
    ?>
</div>
<div class="form-group">
    <label style='margin-left: 10%' >Confirmar contraseña</label>
    <input type="password" class="form-control" name="clave2" style='margin-left: 10%; width: 80%'>
    <?php
    $validador->ShowErrorClave2();
    ?>
</div>
<div class="panel-footer" style="background-color: white;">
    <button type="submit"  name="send" class="btn btn-block btn-primary" style='margin-left: 10%; width: 80%; background-color: #540094;border-color: #540094; margin-top: 20px'>
        Continuar
    </button>
    <br><a href="LoginUser.php" style='margin-left: 10%;'>¿Ya tienes una cuenta? Inicia sesión</a>  
</div>
