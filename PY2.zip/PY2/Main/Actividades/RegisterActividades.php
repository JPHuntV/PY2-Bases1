<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/Direccion/Direccion.inc.php';
include_once '../../app/Empresa/EmpresaRepo.inc.php';
include_once '../../app/Actividad/Actividad.inc.php';
include_once '../../app/Actividad/ActividadRepo.inc.php';
$tittle = "Habitaciones";
include_once '../../app/ControlSesion.inc.php';
if (!ControlSesion::SesionStarted() || $_SESSION['SessionType'] === 1) {
    header('Location:  \PY2\index.php', true, 301);
    exit();
}

Connection::openConnection();
$Empresa = EmpresaRepo::getEmpresaByID(Connection::getConnection());

Connection::closeConnection();
if (isset($_POST['send'])) {
    Connection::openConnection();

    $Direccion = new Direccion($_POST['Provincia'], $_POST['Canton'], $_POST['Distrito'], "", $_POST['Senias']);
    $Actividad = new Actividad("", $Empresa->getNombre(), $_POST['Correo'], $_POST['Telefono'], $_POST['Contacto'], "", $_POST['Descripcion'], $_POST['Precio']);
    $ID = ActividadRepo::InsertActividad(Connection::getConnection(), $Actividad, $Direccion);

    if (isset($_POST['bote'])) {


        ActividadRepo::InsertActividadTipo(Connection::getConnection(), $ID[0]['ID_Actividad'], "Tour en Bote");
    }
    if (isset($_POST['lancha'])) {

        ActividadRepo::InsertActividadTipo(Connection::getConnection(), $ID[0]['ID_Actividad'], "Tour en lancha");
    }
    if (isset($_POST['cata'])) {
        ActividadRepo::InsertActividadTipo(Connection::getConnection(), $ID[0]['ID_Actividad'], "Tour en catamarán");
    }
    if (isset($_POST['kayak'])) {
        ActividadRepo::InsertActividadTipo(Connection::getConnection(), $ID[0]['ID_Actividad'], "Kayak");
    }
    if (isset($_POST['Trans'])) {

        ActividadRepo::InsertActividadTipo(Connection::getConnection(), $ID[0]['ID_Actividad'], "Transporte");
    }
    Connection::closeConnection();
}

/* if ($valor) {
  header('Location: ../../index.php', true, 301);
  exit();
  }
 */
include_once '../../plantillas/declaracion.inc.php';

include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
?>

<nav class="navbar-default navbar-static" style="background-color: whitesmoke" >
    <div class="container" style='background-color: whitesmoke; margin-top:50px'>
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>
        <div id="navbar2" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="../../Main/Actividades/ActividadesEmpresa.php">Actividades de recreación</a></</li>            
                <li><a href="Habitaciones.php">Registrar actividades</a></li>
            </ul>
            <ul class="nav navbar-right">
                <li>
                    <a  href="RegisterActividades.php">
                        <span class="glyphicon glyphicon-plus-sign"></span>
                        Registrar Actividades
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <div class="panel panel-default">
        <div class="panel-heading">
            Registrar actividad de Recreacion

        </div>
        <div class="panel panel-body">
            <form autocomplete="off" role="form" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
                <div class="row">
                    <h4>Informacion general</h4>
                    <label>Tipo De actividad</label><br>
                    <div class="col-md-2">
                        <input type="checkbox" id="bote" name="bote" >
                        <label for="bote"> Tour en bote</label>
                    </div>
                    <div class="col-md-2">
                        <input type="checkbox" id="lancha" name="lancha" >
                        <label for="lancha"> Tour en lancha</label>
                    </div>
                    <div class="col-md-3">
                        <input type="checkbox" id="cata" name="cata" >
                        <label for="cata">  Tour en catamarán</label>
                    </div>
                    <div class="col-md-2">
                        <input type="checkbox" id="kayak" name="kayak" >
                        <label for="kayak"> Kayak</label>
                    </div>
                    <div class="col-md-2">
                        <input type="checkbox" id="Trans" name="Trans" >
                        <label for="Trans"> Transporte</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-10">
                        <div class="form-group" id="Descripcion">
                            <label >Descripcion</label>
                            <input name="Descripcion" type="Text" class="form-control"  required>
                        </div>
                    </div>
                </div> 
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group" id="Precio">
                            <label style='margin-left: 10%'>Precio</label>
                            <input name="Precio" type="Number" class="form-control"  required>
                        </div>
                    </div>
                </div> 
                <hr>
                <h4>Informacion de contacto</h4>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group" id="Clave">
                            <label style='margin-left: 10%'>Empresa</label>
                            <label><?php echo $Empresa->getNombre(); ?></label>
                            <input name="Empresa" type="text" class="form-control"  <?php echo "value='" . $Empresa->getNombre() . "'" ?> readonly>
                        </div>
                    </div> 
                    <div class="col-md-4">
                        <div class="form-group" id="Clave">
                            <label style='margin-left: 10%'>Correo</label>
                            <input name="Correo" type="email" class="form-control"  required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group" id="Clave">
                            <label style='margin-left: 10%'>Telefono</label>
                            <input name="Telefono" type="Number" class="form-control"  required>
                        </div>
                    </div> 
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group" id="Clave">
                            <label style='margin-left: 10%'>Persona a contactar</label>
                            <input name="Contacto" type="text" class="form-control"  required>
                        </div>
                    </div> 
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group" id="Provincia">
                            <label style='margin-left: 10%'>Provincia</label>
                            <input name="Provincia" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group" id="Canton">
                            <label style='margin-left: 10%'>Cantón</label>
                            <input name="Canton" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group" id="Distrito">
                            <label style='margin-left: 10%'>Distrito</label>
                            <input name="Distrito" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-4">
                        <div class="form-group" id="Senias">
                            <label style='margin-left: 10%'>Señas</label>
                            <input name="Senias" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
                        </div>
                    </div>
                </div>
                <button type="submit"  name="send" class="btn btn-default btn-primary" style='float: right'>
                    Registrarse
                </button>
            </form>
        </div>
    </div>
</div>
