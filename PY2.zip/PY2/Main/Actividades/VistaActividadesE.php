<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/Actividad/ActividadRepo.inc.php';
include_once '../../app/Direccion/DireccionRepo.inc.php';
include_once '../../app/ControlSesion.inc.php';
if (ControlSesion::SesionStarted() && $_SESSION['SessionType'] == 1) {
    header('Location: \PY2\index.php', true, 301);
    exit();
}
Connection::openConnection();
$ID_Actividad = $_GET['ID'];
$Actividad = ActividadRepo::getActividadByID(Connection::getConnection(), $ID_Actividad);
$Direccion = DireccionRepo::getDireccionByID(Connection::getConnection(), $Actividad->getID_Direccion());
$Tipos = ActividadRepo::getTipos(Connection::getConnection(), $ID_Actividad);
Connection::closeConnection();


if (isset($_POST['send'])) {
    Connection::openConnection();

    $Direccion = new Direccion($_POST['Provincia'], $_POST['Canton'], $_POST['Distrito'], "", $_POST['Senias']);
    $Actividad = new Actividad($ID_Actividad, $Actividad->getEmpresa(), $_POST['Correo'], $_POST['Telefono'], $_POST['Contacto'], "", $_POST['Descripcion'], $_POST['Precio']);
    $ID = ActividadRepo::UpdateActividadByID(Connection::getConnection(), $Actividad, $Direccion);
    ActividadRepo::DeleteActividadTipoByID(Connection::getConnection(),$ID_Actividad);
    if (isset($_POST['bote'])) {
        ActividadRepo::InsertActividadTipo(Connection::getConnection(), $ID_Actividad, "Tour en Bote");
    }
    if (isset($_POST['lancha'])) {

        ActividadRepo::InsertActividadTipo(Connection::getConnection(), $ID_Actividad, "Tour en lancha");
    }
    if (isset($_POST['cata'])) {
        ActividadRepo::InsertActividadTipo(Connection::getConnection(), $ID_Actividad, "Tour en catamarán");
    }
    if (isset($_POST['kayak'])) {
        ActividadRepo::InsertActividadTipo(Connection::getConnection(), $ID_Actividad, "Kayak");
    }
    if (isset($_POST['Trans'])) {

        ActividadRepo::InsertActividadTipo(Connection::getConnection(), $ID_Actividad, "Transporte");
    }
    Connection::closeConnection();
}


$tittle = "Inicio";
include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
?>

<nav class="navbar-default navbar-static" style="background-color: whitesmoke" >
    <div class="container" style='background-color: whitesmoke; margin-top:50px'>
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>
        <div id="navbar2" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="../../Main/Actividades/ActividadesEmpresa.php">Actividades de recreación</a></</li>
                <li><a href="#">Actividad</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <div class="panel panel-default">
        <div class="panel panel-heading">
            <h4>Detalles de la actividad</h4>
        </div>
        <form autocomplete="off" role="form" enctype="multipart/form-data" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
            <div class="panel panel-body">
                <div class="row">
                    <div class="col-md-4">
                        <label>Empresa:</label>

                    </div>
                    <div class="col-md-6">
                        <?php echo $Actividad->getEmpresa() ?>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-4">
                        <label>Correo:</label>

                    </div>
                    <div class="col-md-6">
                        <input class="form-control" name="Correo" id="Correo" type="email" <?php echo "value='" . $Actividad->getCorreo() . "'" ?> disabled/>
                    </div>
                    <div class="col-md-2">
                        <a class="btn btn-primary" onclick="enable('Correo');" style="float:right">Editar</a>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-4">
                        <label> Teléfono:</label>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control" name="Telefono" id="Telefono" type="number" <?php echo "value='" . $Actividad->getTelefono() . "'" ?> disabled/>
                    </div>
                    <div class="col-md-2">
                        <a class="btn btn-primary" onclick="enable('Telefono');" style="float:right">Editar</a>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-4">
                        <label>Contacto:</label>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control" name="Contacto" id="Contacto" type="text"<?php echo "value='" . $Actividad->getContacto() . "'" ?> disabled/>
                    </div>
                    <div class="col-md-2">
                        <a class="btn btn-primary" onclick="enable('Contacto');" style="float:right">Editar</a>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-4">
                        <label>Direccion</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Provincia</label>
                            <input class="form-control" type="text" name="Provincia" id="Provincia"<?php echo "value='" . $Direccion->getProvincia() . "'" ?> disabled />
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Canton</label>
                            <input class="form-control" type="text" name="Canton" id="Canton" <?php echo "value='" . $Direccion->getCanton() . "'" ?> disabled/>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Distrito</label>
                            <input class="form-control" type="text" name="Distrito" id="Distrito" <?php echo "value='" . $Direccion->getDistrito() . "'" ?> disabled />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-10">
                        <div class="form-group">
                            <label>Señas</label>
                            <input class="form-control" type="text" name="Senias" id="Senias" id="Senias" <?php echo "value='" . $Direccion->getSenias() . "'" ?> disabled/>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <br><a class="btn btn-primary" onclick="enableDir();" style="float:right">Editar</a> 
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <label>Tipo De actividad</label><br>
                        <div class="col-md-2">
                            <input 
                            <?php
                            foreach ($Tipos as $tipo) {
                                if ($tipo['Nombre'] == "Tour en Bote") {
                                    echo "checked";
                                    break;
                                }
                            }
                            ?> type="checkbox" id="bote" name="bote" >
                            <label for="bote"> Tour en bote</label>
                        </div>
                        <div class="col-md-2">
                            <input 
                            <?php
                            foreach ($Tipos as $tipo) {
                                if ($tipo['Nombre'] == "Tour en lancha") {
                                    echo "checked";
                                    break;
                                }
                            }
                            ?> type="checkbox" id="lancha" name="lancha" >
                            <label for="lancha"> Tour en lancha</label>
                        </div>
                        <div class="col-md-3">
                            <input
                            <?php
                            foreach ($Tipos as $tipo) {
                                if ($tipo['Nombre'] == "Tour en catamarán") {
                                    echo "checked";
                                    break;
                                }
                            }
                            ?> type="checkbox" id="cata" name="cata" >
                            <label for="cata">  Tour en catamarán</label>
                        </div>
                        <div class="col-md-2">
                            <input 
                            <?php
                            foreach ($Tipos as $tipo) {
                                if ($tipo['Nombre'] == "Kayak") {
                                    echo "checked";
                                    break;
                                }
                            }
                            ?> type="checkbox" id="kayak" name="kayak" >
                            <label for="kayak"> Kayak</label>
                        </div>
                        <div class="col-md-2">
                            <input
                            <?php
                            foreach ($Tipos as $tipo) {
                                if ($tipo['Nombre'] == "Transporte") {
                                    echo "checked";
                                    break;
                                }
                            }
                            ?> type="checkbox" id="Trans" name="Trans" >
                            <label for="Trans"> Transporte</label>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-2">
                        <label>Descripcion:</label>
                    </div>
                    <div class="col-md-8">
                        <input class="form-control" type="text" name="Descripcion" id="Descripcion" <?php echo "value='" . $Actividad->getDescripcion() . "'"; ?> disabled/>
                    </div>
                    <div class="col-md-2">
                         <a class="btn btn-primary" onclick="enable('Descripcion');" style="float:right">Editar</a>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-4">
                        <label>Precio:</label>
                    </div>
                    <div class="col-md-6">
                        <input type="number" name="Precio" id="Precio" class="form-control" <?php echo "value='" . $Actividad->getPrecio() . "'" ?> disabled/>
                    </div>
                    <div class="col-md-2">
                         <a class="btn btn-primary" onclick="enable('Precio');" style="float:right">Editar</a>
                    </div>
                </div>
            </div>
            <div class="panel panel-footer" style="background-color: white">
                <div class="row">
                    <div class="col-md-12">
                        <button onclick="enableAll()" type="submit"  name="send" class="btn btn-default btn-primary" style='float: right'>
                            GuardarCambios
                        </button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>


<script>
    function disable() {
        document.getElementById("name").disabled = true;
    }
    function enable($element) {
        document.getElementById($element).disabled = false;
    }
    
    function enableDir(){
        
        document.getElementById('Provincia').disabled = false
        document.getElementById('Canton').disabled = false
        document.getElementById('Distrito').disabled = false
        document.getElementById('Senias').disabled = false
    }
    function enableAll() {
        document.getElementById('numero2').disabled = false;
        document.getElementById('SitioWeb').disabled = false;
        document.getElementById('Facebook').disabled = false;
        document.getElementById('Twitter').disabled = false;
        document.getElementById('YouTube').disabled = false;
        document.getElementById('Airbnb').disabled = false;
        document.getElementById('Instagram').disabled = false;
        document.getElementById('hasOtros').disabled = false;
    }
</script>