<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/ControlSesion.inc.php';
include_once '../../app/Habitaciones/HabitacionRepo.inc.php';
include_once '../../app/Reservacion/Reservacion.inc.php';
include_once '../../app/Reservacion/ReservacionRepo.inc.php';
include_once '../../app/Cliente/ClientRepo.inc.php';
$tittle = " Reservacion";
session_start();
Connection::openConnection();
$ID_Habitacion = $_GET['ID'];
$ID_Hospedaje = $_GET['h'];
$Habitacion = HabitacionRepo::getHabitacionByNumber(Connection::getConnection(), $ID_Habitacion,$ID_Hospedaje);
$infoTipo = HabitacionRepo::getInfoTipo(Connection::getConnection(), $Habitacion[0]['Tipo']);
Connection::closeConnection();
if (isset($_POST['send'])) {
    Connection::openConnection();
    if (isset($_POST['hasCar'])) {
        $hasCar = 1;
    } else {
        $hasCar = 0;
    }
    $ID_Cliente = ClientRepo::getCliente(Connection::getConnection(), $_SESSION['ID'], $infoTipo[0]['ID_Hospedaje']);
    if (!count($ID_Cliente)) {
        $ID_Cliente = ClientRepo::InsertClient(Connection::getConnection(), $_SESSION['ID'], $infoTipo[0]['ID_Hospedaje']);
    }
    $Reservacion = new Reservacion("",$ID_Cliente[0]['ID_Cliente'], $Habitacion[0]['ID_Habitacion'], $_POST['numeroID'], $_POST['cantPersonas'], $hasCar, $_POST['fechaIngreso'], $_POST['fechaSalida']);
    $valor = ReservacionRepo::InsertReservacion(Connection::getConnection(), $Reservacion);
    if ($valor) {
        header('Location:\PY2\index.php', true, 301);
        exit();
    } else {
        echo "faisl";
    }
    Connection::closeConnection();
}

include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
?>

<div class="container">
    <div class="panel-default" style="background-color: white;">
        <div class="panel-body" >
            <div class="row">
                <div class="col-md-3" >
                    <?php
                    Connection::openConnection();
                    $target = HabitacionRepo::getMiniatura(Connection::getConnection(), $Habitacion[0]['Tipo'], $infoTipo[0]['ID_Hospedaje']);
                    $target = $target[0]['imagen'];
                    echo "<img src='../../" . $target . "' id = 'imagen2' name = 'imagen2' style = 'padding:0; width: 200px; height: 200px;' />";
                    Connection::closeConnection();
                    ?>
                </div>
                <div class="col-md-9" >
                    <div class="row">
                        <span><h3>Numero:<?php echo $Habitacion[0]['Numero']; ?></h3></span>
                        <span><h3>Tipo: <?php echo $Habitacion[0]['Tipo']; ?></h3></span>
                        <span><h3>Estado: <?php echo $Habitacion[0]['Estado']; ?></h3></span>
                    </div>
                    <div class="row">                           
                        <span>Descripcion:<br>&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $infoTipo[0]['Descripcion'] ?></span>
                    </div>                   
                </div>
            </div>
        </div>
        <hr>
        <div class="panel-body">
            <h3>Reservacion</h3>
            <span><h4>Numero:<?php echo $Habitacion[0]['Numero']; ?></h4></span>
            <form autocomplete="off" role="form" enctype="multipart/form-data" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label id="numeroID">Cedula o identificacion</label>
                            <input  name="numeroID" type="number" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label id="cantPer">Cantidad de personas</label>
                            <input name="cantPersonas" id="cantPersonas"  type="number" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" id="hasCar" name="hasCar" >
                        <label for="hasCar">Posee vehiculo</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <div class='input-group date' id='fechaIngreso'>
                                <input name="fechaIngreso" type='datetime' class="form-control" required/>
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>

                        </div>
                    </div>
                    <div class='col-md-4'>
                        <div class="form-group">
                            <div class='input-group date' id='fechaSalida'>
                                <input name="fechaSalida" type='datetime' class="form-control" required/>
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <script type="text/javascript">
                        $(function () {
                            $('#fechaIngreso').datetimepicker({
                                minDate: moment(),
                                format:  ' YYYY-MM-DD hh:mm'
                            });
                            $('#fechaSalida').datetimepicker({
                                useCurrent: false,
                               format:  ' YYYY-MM-DD hh:mm'
                            });
                            $("#fechaIngreso").on("dp.change", function (e) {
                                $('#fechaSalida').data("DateTimePicker").minDate(e.date);
                                
                            });
                            $("#fechaSalida").on("dp.change", function (e) {
                                $('#fechaIngreso').data("DateTimePicker").maxDate(e.date);
                            });
                        });
                    </script>                  
                </div>  
                <div class="row">
                    <div class="col-md-4">
                        <button class="btn btn-block bg-primary" type="submit" name="send" style='margin-left: 10%; width: 80%'>Reservar</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

