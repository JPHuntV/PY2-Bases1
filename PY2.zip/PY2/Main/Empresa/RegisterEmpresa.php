<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/Empresa/EmpresaRepo.inc.php';
include_once '../../app/Empresa/RegisterEmpresaVal.inc.php';
include_once '../../app/Direccion.inc.php';
include_once '../../app/ControlSesion.inc.php';
$tittle = "Inicio";
include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';

if (ControlSesion::SesionStarted()) {
    if ($_SESSION['SessionType'] === 1) {
        header('Location: \PY2\index.php', true, 301);
        exit();
    }else{
        header('Location: ../Habitaciones/Habitaciones.php', true, 301);
        exit();
    }
}

if (isset($_POST['send'])) {
    Connection::openConnection();
    $validador = new RegisterEmpresaVal($_POST['CedJur'],$_POST['Correo'],$_POST['clave1'],$_POST['clave2'],$_POST['lat'],Connection::getConnection());
    
    if($validador->validAccount()){
        if(isset($_POST['hasPool'])){$hasPool = 1;}else{$hasPool = 0;}
        if(isset($_POST['hasWifi'])){$hasWifi= 1;}else{$hasWifi= 0;}
        if(isset($_POST['hasRest'])){$hasRest= 1;}else{$hasRest= 0;}
        if(isset($_POST['hasBar'])){$hasBar = 1;}else{$hasBar = 0;}
        if(isset($_POST['hasRanch'])){$hasRanch= 1;}else{$hasRanch= 0;}

        $Direccion = new Direccion($_POST['Provincia'], $_POST['Canton'], $_POST['Distrito'],$_POST['Barrio'],$_POST['Senias']);
        $Empresa = new Empresa($_POST['Nombre'],$_POST['CedJur'],$_POST['tipoHos'],$_POST['Correo'],$_POST['numero1'],$_POST['numero2'],
                                $_POST['SitioWeb'],$_POST['lat'],$_POST['lng'],$_POST['Facebook'],$_POST['Instagram'],$_POST['Twitter'],$_POST['YouTube'],$_POST['Airbnb'],
                                $hasPool,$hasWifi,$hasRest,$hasBar,$hasRanch,$_POST['hasOtros']);


        $valor = EmpresaRepo::InsertEmpresa(Connection::getConnection(), $Empresa, $Direccion,$_POST['clave1']);
       
        if ($valor) {
            header('Location: ../../index.php', true, 301);
            exit();
        } 
    Connection::closeConnection();
    }
}
?>
<script type="text/javascript"
src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBJsDLaIChZoMPlQVWT-Eh-sc1aZ6m5OCQ"></script>
<script src="https://unpkg.com/location-picker/dist/location-picker.min.js"></script>

<div class="container-fluid">
    <div class="panel" style="margin-top: 20px">
        <div class="panel panel-heading">
            <h2>Registro de empresas</h2>
        </div>
        <div class="panel panel-body">
            <form autocomplete="off" role="form" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
               <?php
               if(isset($_POST['send'])){
                   include_once '../../plantillas/Empresa/RegisterEmpresaUsedForm.inc.php';
               }else{
                   include_once '../../plantillas/Empresa/RegisterEmpresaEmptyForm.inc.php';
               }
               ?>
            </form>
        </div>
    </div>

</div>
