<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/User/UserRepo.inc.php';
include_once '../../app/Direccion.inc.php';
$tittle = "Inicio";
include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';

if (isset($_GET['nombre']) && !empty($_GET['nombre']) && isset($_GET['fecha']) && !empty($_GET['fecha']) &&
        isset($_GET['telefono']) && !empty($_GET['telefono']) && isset($_GET['correo']) && !empty($_GET['correo']) &&
        isset($_GET['pss']) && !empty($_GET['pss'])) {
    $client = $_GET['nombre'];
    $user = $_GET['nombre'];
    $fecha = $_GET['fecha'];
    $Telefono = $_GET['telefono'];
    $Correo = $_GET['correo'];
    $pss = $_GET['pss'];
} else {
    header('Location: RegisterInfoCuenta.php', true, 301);
    exit();
}
if (isset($_POST['send'])) {

    if ($_POST['selectPais'] === "cr") {
        $PaisResidencia = "Costa Rica";
        $Direccion = new Direccion($_POST['Provincia'], $_POST['Canton'], $_POST['Distrito'], "", "");
    } else {
        $PaisResidencia = $_POST['otroPais'];
        $Direccion = "x";
    }
    $User = new User("x", $_GET['nombre'], $_GET['fecha'], $_GET['telefono'], $_GET['correo'], $_GET['pss'], $_POST['Nombre'], $_POST['Apellido1'], $_POST['Apellido2'], $_POST['tipoId'], $_POST['numId'], $PaisResidencia);

    Connection::openConnection();
    $valor = UserRepo::InsertUser(Connection::getConnection(), $User, $Direccion);
    Connection::closeConnection();
    if ($valor) {
        header('Location: ../../index.php', true, 301);
        exit();
    }
}
?>

<div class='container'>
    <div class='row' style="margin-top: 20px">
        <div class='col-md-6 col-md-offset-3'>
            <div class="panel panel-default" >
                <div class="panel-heading text-center" style="background-color: white">
                    <h1 class="panel-title w-100 font-weight-bold" style="font-size: 28px ">Registrarse</h1>
                </div>

                <form autocomplete="off" role="form" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">

                    <div class="form-group" id="Nombre">
                        <label style='margin-left: 10%'>Nombre</label>
                        <input name="Nombre" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
                    </div>

                    <div class="form-group" id="Appelido1">
                        <label style='margin-left: 10%'>Primer apellido</label>
                        <input name="Apellido1" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
                    </div>

                    <div class="form-group" id="Apellido2">
                        <label style='margin-left: 10%'>Segundo apellido</label>
                        <input name="Apellido2" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
                    </div>

                    <div class="form-group">
                        <label style='margin-left: 10%' for="tipoId">Tipo de identificación</label>
                        <select class="form-control" name="tipoId" style='margin-left: 10%; width: 80%'>
                            <option value="Nacional">Nacional</option>
                            <option value="Extranjero">Extranjero</option>
                        </select>
                    </div>

                    <div class="form-group" id="numId">
                        <label style='margin-left: 10%' >Número de identificación</label>
                        <input name="numId" type="number" class="form-control" min="100000000" max="1000000000" style='margin-left: 10%; width: 80%' required>
                    </div>

                    <div class="form-group">
                        <label style='margin-left: 10%' for="selectPais">Pais de residencia</label>
                        <select class="form-control" id="selectPais" name="selectPais" style='margin-left: 10%; width: 80%'>
                            <option value="cr">Costa Rica</option>
                            <option value="otro">Otro</option>
                        </select>
                    </div>


                    <div class="form-group" id="otroPaisG">
                        <label style='margin-left: 10%' for="otroPais"  >Indique el pais</label>
                        <input id="otroPais" name="otroPais" type="text" class="form-control" style='margin-left: 10%; width: 80%'>
                    </div>

                    <div class="form-group" id="ProvinciaG">
                        <label style='margin-left: 10%' for="Provincia"  >Provincia</label>
                        <input id="Provincia" name="Provincia" type="text" class="form-control" style='margin-left: 10%; width: 80%'>
                    </div>

                    <div class="form-group" id="CantonG">
                        <label  style='margin-left: 10%' for="Canton"  >Cantón</label>
                        <input id="Canton" name="Canton" type="text" class="form-control" style='margin-left: 10%; width: 80%'>
                    </div>

                    <div class="form-group" id="DistritoG">
                        <label style='margin-left: 10%' for="Distrito"  >Distrito</label>
                        <input id="Distrito" name="Distrito" type="text" class="form-control" style='margin-left: 10%; width: 80%'>
                    </div>

                    <div class="panel-footer" style="background-color: white;">
                        <button type="submit"  name="send" class="btn btn-block btn-primary" style='margin-left: 10%; width: 80%; background-color: #540094;border-color: #540094; margin-top: 20px'>
                            Continuar
                        </button>
                        <br><a href="LoginUser.php" style='margin-left: 10%;'>¿Ya tienes una cuenta? Inicia sesión</a>  
                    </div>
                </form>

            </div>  
        </div>
    </div>

</div>

<?php
include_once '../../plantillas/cierre.inc.php';
?>
<script>
    $("#selectPais").change(function () {
        if ($(this).val() == "otro") {
            $('#otroPaisG').show();
            $('#otroPais').attr('required', '');
            $('#otroPais').attr('data-error', 'This field is required.');

            $('#ProvinciaG').hide();
            document.getElementById("Provincia").value = "";
            $('#Provincia').removeAttr('required');
            $('#Provincia').removeAttr('data-error');

            $('#CantonG').hide();
            document.getElementById("Canton").value = "";
            $('#Canton').removeAttr('required');
            $('#Canton').removeAttr('data-error');

            $('#DistritoG').hide();
            document.getElementById("Distrito").value = "";
            $('#Distrito').removeAttr('required');
            $('#Distrito').removeAttr('data-error');
        } else {
            $('#ProvinciaG').show();
            $('#Provincia').attr('required', '');
            $('#Provincia').attr('data-error', 'This field is required.');

            $('#CantonG').show();
            $('#Canton').attr('required', '');
            $('#Canton').attr('data-error', 'This field is required.');

            $('#DistritoG').show();
            $('#Distrito').attr('required', '');
            $('#Distrito').attr('data-error', 'This field is required.');


            $('#otroPaisG').hide();
            document.getElementById("otroPais").value = "";
            $('#otroPais').removeAttr('required');
            $('#otroPais').removeAttr('data-error');


        }
    });
    $("#selectPais").trigger("change");

</script>
