<?php

include_once '../../app/Connection.inc.php';
include_once '../../app/User/UserRepo.inc.php';
include_once '../../app/User/AccountRegisterVal.inc.php';
$tittle = "Registro";
include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
include_once '../../app/ControlSesion.inc.php';


if (ControlSesion::SesionStarted()) {
    if ($_SESSION['SessionType'] === 1) {
        header('Location: \PY2\index.php', true, 301);
        exit();
    }else{
        header('Location: ../Habitaciones/Habitaciones.php', true, 301);
        exit();
    }
}
if (isset($_POST['send'])) {
    Connection::openConnection();
    $validador = new AccountValidator($_POST['nombre'], $_POST['nacimiento'], $_POST['telefono'], $_POST['Correo'], $_POST['clave1'], $_POST['clave2'],Connection::getConnection());
    Connection::closeConnection();
    if ($validador->validAccount()) {
         
        //echo 'Todo correcto';
        header('Location: RegisterInfoUser.php?nombre=' . $validador->getNombre() . '&fecha=' . $validador->getNacimiento() . '&telefono=' . $validador->getTelefono()
                . '&correo=' . $validador->getCorreo() . '&pss=' . password_hash($validador->getClave(),PASSWORD_DEFAULT), true, 301);
        exit();
    }
}
?>

<div class='container'>
    <div class='row' style="margin-top: 20px">
        <div class='col-md-6 col-md-offset-3'>
            <div class="panel panel-default" >
                <div class="panel-heading text-center" style="background-color: white">
                    <h1 class="panel-title w-100 font-weight-bold" style="font-size: 28px ">Registrarse</h1>
                </div>

                <form autocomplete="off" role="form" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                    <?php
                    if (isset($_POST['send'])) {
                        include_once '../../plantillas/User/InfoCuentaUsedForm.inc.php';
                    } else {
                        include_once '../../plantillas/User/InfoCuentaEmptyForm.inc.php';
                    }
                    ?>
                </form>

            </div>  
        </div>
    </div>

</div>
