<?php

include_once '../app/ControlSesion.inc.php';
include_once '../app/config.inc.php';

ControlSesion::CloseSesion();
header('Location: \PY2\index.php', true, 301);
exit();