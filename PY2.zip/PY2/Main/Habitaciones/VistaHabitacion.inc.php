
<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/Habitaciones/HabitacionRepo.inc.php';
$tittle = " Habitacion";
include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
Connection::openConnection();
$ID_Habitacion = $_GET['ID'];
$ID_Hospedaje = $_GET['h'];
$Habitacion = HabitacionRepo::getHabitacionByNumber(Connection::getConnection(), $ID_Habitacion,$ID_Hospedaje);
/* if (isset($_POST['send'])) {

  if ($_POST['selectPais'] === "cr") {
  $PaisResidencia = "Costa Rica";
  $Direccion = new Direccion($_POST['Provincia'], $_POST['Canton'], $_POST['Distrito'], "", "");
  } else {
  $PaisResidencia = $_POST['otroPais'];
  $Direccion = "x";
  }
  $User = new User("x", $_GET['nombre'], $_GET['fecha'], $_GET['telefono'], $_GET['correo'], $_GET['pss'], $_POST['Nombre'], $_POST['Apellido1'], $_POST['Apellido2'], $_POST['tipoId'], $_POST['numId'], $PaisResidencia);

  Connection::openConnection();
  $valor = UserRepo::InsertUser(Connection::getConnection(), $User, $Direccion);
  Connection::closeConnection();
  if ($valor) {
  header('Location: ../../index.php', true, 301);
  exit();
  }
  } */
?>

<nav class="navbar-default navbar-static" >
    <div class="container-fluid" style='background-color: white; margin-top:50px'>
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>
        <div id="navbar2" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="Habitaciones.php">Habitaciones</a></li>
                <li><a href="#"><?php echo ">Habitacion:" . $ID_Habitacion; ?> </a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container">
    <div class="panel-default">
        <div class="panel-body" style="background-color: white">
            <div class="row">
                <div class="col-md-3" >
                    <?php
                    $infoTipo = HabitacionRepo::getInfoTipo(Connection::getConnection(), $Habitacion[0]['Tipo']);
                    $target = HabitacionRepo::getMiniatura(Connection::getConnection(), $Habitacion[0]['Tipo'], $infoTipo[0]['ID_Hospedaje']);
                    $target = $target[0]['imagen'];
                    /* $target = HabitacionRepo::getMiniatura(Connection::getConnection(), $Habitacion[0]['Tipo'], $_SESSION['ID']);
                      $target = $target[0]['imagen']; */
                    echo "<img src='../../" . $target . "' id = 'imagen2' name = 'imagen2' style = 'padding:0; width: 200px; height: 200px;' />"
                    ?>
                </div>
                <div class="col-md-3">
                    <span><h4>Numero:<?php echo $Habitacion[0]['Numero']; ?></h4></span>
                    <span><h4>Tipo: <?php echo $Habitacion[0]['Tipo']; ?></h4></span>
                    <span>
                        <h4>Estado: 
                            <?php
                            if (!$Habitacion[0]['Estado']) {
                                echo "Ocupada";
                            } else {
                                echo "Disponible";
                            }
                            ?>
                        </h4>
                    </span>
                    <span><h4>Precio: $ <?php echo $Habitacion[0]['Precio']; ?></h4></span>
                </div>
                <div class="col-md-3" style="text-align: left">
                    <?php
                    if ($Habitacion[0]['wifi']) {
                        echo "<i class = 'fa fa-wifi fa-2x' aria-hidden = 'true'></i>:Wifi<br>";
                    }
                    if ($Habitacion[0]['ac']) {
                        echo "<i class = 'fa fa-snowflake-o fa-2x' aria-hidden = 'true'></i>:Aire acondicionado<br>";
                    }
                    if ($Habitacion[0]['HotWater']) {
                        echo "<i class = 'fa fa-thermometer-three-quarters fa-2x' aria-hidden = 'true'></i>:Agua caliente<br>";
                    }
                    if ($Habitacion[0]['Fan']) {
                        echo "<i class = 'fa fa-dot-circle-o fa-2x' aria-hidden = 'true'></i>:Ventilador<br>";
                    }
                    ?>
                </div>
                <div class = "col-md-3">
                    <?php
                    if (ControlSesion::SesionStarted() && $_SESSION['SessionType'] === 1) {
                        $path = "\PY2\Main\Reservaciones\Reservacion.php?ID=" . $ID_Habitacion ."&h=". $ID_Hospedaje ;
                    } else {
                        $path = "\PY2\Main\User\LoginUser.php?ID=" . $ID_Habitacion ."&h=". $ID_Hospedaje;
                    }
                    ?>
                    <a class="btn btn-primary" <?php echo "href=" . $path; ?>>Reservar</a>           
                </div>
            </div>
            <div class="row">
                <h3>Descripcion</h3><br>
                <p><?php echo $Habitacion[0]['Descripcion']; ?></p>
            </div>
            <div class="row">
                <h3>Comodidades</h3>
                <?php
                if ($Habitacion[0]['wifi']) {
                    echo "<i class = 'fa fa-wifi fa-2x' aria-hidden = 'true'></i>:Wifi &nbsp;&nbsp;&nbsp;&nbsp;";
                }
                if ($Habitacion[0]['ac']) {
                    echo "<i class = 'fa fa-snowflake-o fa-2x' aria-hidden = 'true'></i>:Aire acondicionado&nbsp;&nbsp;&nbsp;&nbsp;";
                }
                if ($Habitacion[0]['HotWater']) {
                    echo "<i class = 'fa fa-thermometer-three-quarters fa-2x' aria-hidden = 'true'></i>:Agua caliente &nbsp;&nbsp;&nbsp;&nbsp;";
                }
                if ($Habitacion[0]['Fan']) {
                    echo "<i class = 'fa fa-dot-circle-o fa-2x' aria-hidden = 'true'></i>:Ventilador &nbsp;&nbsp;&nbsp;&nbsp;";
                }
                ?>
                <br>
                <p><?php echo $Habitacion[0]['Comodidades']; ?></p>
            </div>
            <div class="row">

                <?php
                $target = HabitacionRepo::getImagenes(Connection::getConnection(), $Habitacion[0]['Tipo'], $infoTipo[0]['ID_Hospedaje']);
                foreach ($target as $imagen) {
                    echo "<div class='col-md-3'>";
                    echo "<img src='../../" . $imagen . "' id = 'imagen' name = 'imagen' style = 'padding:0; width: 200px; height: 200px;' />";
                    echo "</div>";
                }
                ?>
            </div>
        </div>
    </div>
</div>