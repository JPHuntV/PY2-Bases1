<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/ControlSesion.inc.php';
include_once '../../app/Habitaciones/RegisterHabTipVal.inc.php';
$tittle = "Habitaciones";
if (!ControlSesion::SesionStarted()) {
    header('Location:  \PY2\index.php', true, 301);
    exit();
}

if (isset($_POST['send'])) {
    Connection::openConnection();
    $validador = new RegisterHabTipVal($_POST['Nombre'], Connection::getConnection());
    if ($validador->validAccount()) {
        if (isset($_POST['hasAC'])) {
            $hasAC = 1;
        } else {
            $hasAC= 0 ;
        }
        if (isset($_POST['hasWifi'])) {
            $hasWifi = 1;
        } else {
            $hasWifi = 0;
        }
        if (isset($_POST['hasHotWater'])) {
            $hasHotWater = 1;
        } else {
            $hasHotWater= 0;
        }
        if (isset($_POST['hasFan'])) {
            $hasFan = 1;
        } else {
            $hasFan = 0;
        }
        $image1T=$_FILES['uploadImage1']['name'];
        $image2T=$_FILES['uploadImage2']['name'];
        $image3T=$_FILES['uploadImage3']['name'];
        $image4T=$_FILES['uploadImage4']['name'];
        $TipoHab = new TipoHabitacion($_SESSION['ID'], $_POST['Nombre'], $_POST['Descripcion'], $_POST['Precio'],$hasAC,$hasWifi,
                                        $hasHotWater,$hasFan,$_POST['Comodidades'],$image1T,$image2T,$image3T,$image4T);
        $valor = HabitacionRepo::InsertTipoHab(Connection::getConnection(), $TipoHab);

        if ($valor) {

            $target1 = "../../img/HabitacionesTipo/".  $_SESSION['ID'] . "_" . $_POST['Nombre'] . "_1". basename($image1T);

            $target2 = "../../img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $_POST['Nombre'] . "_2" . basename($image2T);

            $target3 = "../../img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $_POST['Nombre'] . "_3" . basename($image3T);

            $target4 = "../../img/HabitacionesTipo/" . $_SESSION['ID'] . "_" . $_POST['Nombre'] . "_4" . basename($image4T);
            move_uploaded_file($_FILES['uploadImage1']['tmp_name'], $target1);
            move_uploaded_file($_FILES['uploadImage2']['tmp_name'], $target2);
            move_uploaded_file($_FILES['uploadImage3']['tmp_name'], $target3);
            move_uploaded_file($_FILES['uploadImage4']['tmp_name'], $target4);
            /*header('Location: index.php', true, 301);
            exit();*/
        } else {
            echo "fail";
        }
    }
    Connection::closeConnection();
}
include_once '../../plantillas/declaracion.inc.php';
include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
?>

<nav class="navbar-default navbar-static" >
    <div class="container-fluid" style='background-color: white; margin-top:50px'>
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>
        <div id="navbar2" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="Habitaciones.php"><span class="glyphicon glyphicon-chevron-left"></span>Volver</a></li>
                <li><a href="#">Registrar habitacion</a></li>

            </ul>
        </div>
    </div>
</nav>
<div class="container-fluid">
    <div class="panel panel-default">
        <div class="panel panel-heading">
            <h2>Registrar habitación</h2>
        </div>
        <form autocomplete="off" role="form" enctype="multipart/form-data" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
            <div class="panel panel-body">
                <h3>Información general</h3>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group" id="Nombre">
                            <label style='margin-left: 10%'>Nombre</label>
                            <?php if (isset($_POST['send'])) { ?>
                                <input name="Nombre" type="text" class="form-control"  <?php $validador->showName() ?>  style='margin-left: 10%; width: 80%' required>
                                <?php $validador->showErrornombre() ?>                           

                            <?php } else { ?>
                                <input name = "Nombre" type = "text" class = "form-control" style = 'margin-left: 10%; width: 80%' required>
                            <?php } ?>
                        </div>
                    </div>                                   
                </div>
                <div class="row">
                    <div class="col-md-10" >
                        <div class="form-group" id="Descripcion">
                            <label >Descripción</label> 
                            <textarea class="form-control" id="Descripcion" name="Descripcion" style='margin-left: 10%; width: 100%' ;resize: none;' rows="5" cols="100"></textarea>    
                        </div>
                    </div>


                </div>
                <h3>Comodidades</h3>
                <div class="row">
                    <div class="col-md-4" >
                        <div class="row " style='margin-left: 10%'>
                            <div class="col-md-6" >
                                <input type="checkbox" id="hasAC" name="hasAC" >
                                <label for="hasAC">A/C</label>
                            </div>
                            <div class="col-md-6">
                                <input type="checkbox" id="hasWifi" name="hasWifi" >
                                <label for="hasWifi"> WiFi</label>
                            </div><br>
                        </div>
                        <div class="row" style='margin-left: 10%'>
                            <div class="col-md-6">
                                <input type="checkbox" id="hasHotWater" name="hasHotWater" >
                                <label for="hasHotWater"> Agua caliente</label>
                            </div>
                            <div class="col-md-6">
                                <input type="checkbox" id="hasFan" name="hasFan" >
                                <label for="hasFan">Ventilador</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="form-group">
                            <label style='margin-left: 4%'>Otras</label> 
                            <textarea class="form-control" id="Comodidades" name="Comodidades" style='margin-left: 4%; width: 92%;resize: none;' rows="5" cols="100"></textarea>    
                        </div>
                    </div>
                </div>
                <div class="row" >
                    <div class="col-md-3" >
                        <img id="imagen1" name="imagen1" style="width: 250px; height: 250px; margin-left: 10%" />
                        <input  id="uploadImage1" name="uploadImage1" type="file"  onchange="PreviewImage('uploadImage1', 'imagen1');" />

                    </div>
                    <div class="col-md-3">
                        <img id="imagen2" name="imagen2" style="width: 250px; height: 250px; margin-left: 10% " />
                        <input id="uploadImage2" name="uploadImage2" type="file"  onchange="PreviewImage('uploadImage2', 'imagen2');" />

                    </div>
                    <div class="col-md-3">                           
                        <img id="imagen3" name="imagen3" style="width: 250px; height: 250px; margin-left: 10% " />
                        <input  id="uploadImage3" name="uploadImage3" type="file"  onchange="PreviewImage('uploadImage3', 'imagen3');" />

                    </div>
                    <div class="col-md-3">                          
                        <img id="imagen4" name="imagen4" style="width: 250px; height: 250px; margin-left: 10% " />
                        <input id="uploadImage4" name="uploadImage4" type="file" onchange="PreviewImage('uploadImage4', 'imagen4');" />

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group" id="precio">


                        </div>
                        <div class="form-group" id="precio">
                            <label style='margin-left: 10%'>Precio</label>
                            <input name="Precio" type="number" class="form-control" style='margin-left: 10%; width: 80%' required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <button class="btn btn-block bg-primary" type="submit" name="send" style='margin-left: 10%; width: 80%'>Registrar habitación</button>
                    </div>
                </div>
            </div>
        </form>
            <script type="text/javascript">

                function PreviewImage($boton, $imagen) {
                    var oFReader = new FileReader();
                    oFReader.readAsDataURL(document.getElementById($boton).files[0]);

                    oFReader.onload = function (oFREvent) {
                        document.getElementById($imagen).src = oFREvent.target.result;
                    };
                }
                ;

            </script>
        </div>
    </div>
</div>
