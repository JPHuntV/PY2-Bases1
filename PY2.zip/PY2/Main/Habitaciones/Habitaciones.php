<?php
include_once '../../app/Connection.inc.php';
include_once '../../app/Habitaciones/HabitacionRepo.inc.php';
include_once '../../app/Habitaciones/Habitacion.inc.php';
include_once '../../app/Habitaciones/RegisterHabitacionVal.inc.php';
$tittle = "Habitaciones";
include_once '../../app/ControlSesion.inc.php';
if (!ControlSesion::SesionStarted() || $_SESSION['SessionType'] === 1) {
    header('Location:  \PY2\index.php', true, 301);
    exit();
}
if (isset($_POST['sendHab'])) {


    Connection::openConnection();
    $validador = new RegisterHabitacionVal($_POST['Numero'], Connection::getConnection());
    if ($validador->validAccount()) {
        $Habitacion = new Habitacion($_SESSION['ID'], $_POST['Numero'], $_POST['Tipo'], $_POST['Estado']);
        $valor = HabitacionRepo::InsertHabitacion(Connection::getConnection(), $Habitacion);
    }

    Connection::closeConnection();
    /* if ($valor) {
      header('Location: ../../index.php', true, 301);
      exit(); */
}

include_once '../../plantillas/declaracion.inc.php';

include_once '../../plantillas/navbar.inc.php';
include_once '../../plantillas/cierre.inc.php';
?>


<nav class="navbar-default navbar-static" >
    <div class="container-fluid" style='background-color: white; margin-top:50px'>
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>
        <div id="navbar2" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="#">Habitaciones</a></li>
                <li><a href="#">Clientes</a></li>
                <li><a href="#">Reservaciones</a></li>
                <li><a href="#">Facturación</a></li>

            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid">
    <div class="panel-default">
        <div class="panel-heading" style="float: center">
            <div class="row">
                <form autocomplete="off" role="form" enctype="multipart/form-data" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
                    <div class="col-md-2">                       
                        <div class="form-group" id="Numero">
                            <label style='margin-left: 10%'>Numero</label>
                            <?php if (isset($_POST['sendHab'])) { ?>
                                <input name="Numero" type="number" class="form-control"  <?php $validador->showNumero() ?>  style='margin-left: 10%; width: 80%' required>
                                <?php $validador->showErrorNumber() ?>                           

                            <?php } else { ?>
                                <input name="Numero" type = "text" class = "form-control" style = 'margin-left: 10%; width: 80%' required>
                            <?php } ?>
                        </div>                    
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label style='margin-left: 10%'>Tipo</label>
                            <select class="form-control" name="Tipo" required oninvalid="this.setCustomValidity('Debe registrar un tipo primero')">
                                <?php
                                Connection::openConnection();
                                $result = HabitacionRepo::getTipos(Connection::getConnection());
                                Connection::closeConnection();
                                ?>
                            </select>
                            <?php if (!$result) { ?>
                                <br>
                                <a  href="RegisterHabitaciontipo.php" class="btn btn-block btn-danger" >
                                    <span class="glyphicon glyphicon-plus-sign"></span>
                                    Registrar tipos
                                </a>
                            <?php } ?>    

                        </div> 
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="Estado">Estado</label>
                            <select class="form-control" id="Estado" name="Estado" >
                                <option value=0>Disponible</option>
                                <option value=1>Ocupada</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <br>
                        <button class="btn bg-primary" type="submit" name="sendHab" >
                            <span class="glyphicon glyphicon-plus-sign"></span>
                            Registrar habitación
                        </button>
                    </div>
                </form>
                <div class="col-md-2">
                    <br>
                    <a  href="RegisterHabitaciontipo.php" class="btn btn-primary" >
                        <span class="glyphicon glyphicon-plus-sign"></span>
                        Registrar tipos
                    </a> 
                </div>

            </div>         
        </div>
        <div class="panel-body">
            <?php
            Connection::openConnection();
            $result = HabitacionRepo::getHabitaciones(Connection::getConnection());
            if (!empty($result)) {
                for ($i = 0; $i<count($result); $i++) {
                    $target = HabitacionRepo::getMiniatura(Connection::getConnection(),$result[$i]['Tipo']);
                    
                    echo "<img id = 'imagen2' name = 'imagen2' style = 'width: 200px; height: 200px; margin-left: 10%' />";
                    //echp "<input id = 'uploadImage2' name = 'uploadImage2' type = 'file" onchange = "PreviewImage('uploadImage2', 'imagen2');" />
                }
            }
            Connection::closeConnection();
            ?>
        </div>   

    </div>

</div>

<script type="text/javascript">

    function PreviewImage($boton, $imagen) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById($boton).files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById($imagen).src = oFREvent.target.result;
        };
    }
    ;

</script>