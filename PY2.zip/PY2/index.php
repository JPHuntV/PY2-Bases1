<?php
include_once 'app/Connection.inc.php';
/*include_once 'app/User/UserRepo.inc.php';*/
include_once 'app/ControlSesion.inc.php';
if(ControlSesion::SesionStarted() && $_SESSION['SessionType']==0){
    header('Location: Main/Habitaciones/Habitaciones.php', true, 301);
    exit();
}
$tittle = "Inicio";
include_once 'plantillas/declaracion.inc.php';
include_once 'plantillas/navbar.inc.php';
include_once 'plantillas/cierre.inc.php';
?>

<nav class="navbar-default navbar-static" >
    <div class="container-fluid" style='background-color: white; margin-top:50px'>
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">despliega la barra</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>  
            </button>
        </div>
        <div id="navbar2" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="#">Sitios de hospedaje</a></li>
                <li><a href="#">Actividades de recreación</a></li>

            </ul>
        </div>
    </div>
</nav>
<body>
    <div class="container-fluid" style="background-color: whitesmoke">
        <div class="square rounded p-5">
            <div class='row'>
                <div class='col-md-4'>
                    <div class="form-group" id="Nombre">
                        <label style='margin-left: 10%'>Nombre</label>
                        <input name="Nombre" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
                    </div>

                </div>
                <div class='col-md-2'>
                    <div class="form-group" id="Nombre">
                        <label style='margin-left: 10%'>Nombre</label>
                        <input name="Nombre" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
                    </div>

                </div>
                <div class='col-md-2'>
                    <div class="form-group" id="Nombre">
                        <label style='margin-left: 10%'>Nombre</label>
                        <input name="Nombre" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
                    </div>

                </div>
                <div class='col-md-4'>
                    <div class="form-group" id="Nombre">
                        <label style='margin-left: 10%'>Nombre</label>
                        <input name="Nombre" type="text" class="form-control" style='margin-left: 10%; width: 80%' required>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="jumbotron">

        </div>
        <div class="jumbotron">

        </div>
        <div class="jumbotron">

        </div>
        <div class="jumbotron">

        </div>
        <div class="jumbotron">

        </div>
        <div class="jumbotron">

        </div>
        <div class="jumbotron">

        </div>

    </div>

